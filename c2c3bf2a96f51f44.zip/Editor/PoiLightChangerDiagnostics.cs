using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using nadena.dev.ndmf;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;
using VRC.SDK3.Avatars.Components;

namespace io.github.m8pix.poi_light_changer
{
    internal enum PoiLightChangerDiagnosticPlacement
    {
        Global = 0,
        Ssao = 1,
        ContactShadow = 2,
        Parameters = 3,
        TextureBake = 4,
    }

    internal enum PoiLightChangerInspectorDisableScope
    {
        None = 0,
        All = 1,
        Ssao = 2,
        ContactShadow = 3,
    }

    internal enum PoiLightChangerPoiyomiVariant
    {
        Unknown = 0,
        Toon = 1,
        Pro = 2,
    }

    internal enum PoiLightChangerDiagnosticId
    {
        ProjectPoiyomiMissing,
        ComponentOutsideAvatar,
        DuplicateInstall,
        DuplicateObjectNames,
        AvatarUnsupportedGuaranteedPoiyomiVersion,
        ProjectSupportedVersionMissing,
        AvatarMixedPoiyomiVariants,
        AvatarUnsupportedPoiyomiMaterials,
        AvatarNoSupportedPoiyomiMaterials,
        AvatarHasNonPoiyomiMaterials,
        SsaoPoiyomiProMissing,
        ContactShadowPoiyomiV10Missing,
        ParameterCompressionIneffective,
        TextureBakeShaderMissing,
        TextureBakePoiyomiV10Unavailable,
        TextureBakeGenerationFailed,
        UnimplementedEnabledControls,
        MaterialDrawerApplyFailed,
        MaterialUnlockFailed,
        MaterialRelockFailed,
        MaterialStillLockedAfterUnlock,
        BuildException,
        LicenseUnlicensed,
        LicenseOfflineGraceExpired,
    }

    internal sealed class PoiLightChangerDiagnosticEntry
    {
        public PoiLightChangerDiagnosticId Id { get; set; }

        public MessageType InspectorMessageType { get; set; } = MessageType.Warning;

        public PoiLightChangerDiagnosticPlacement InspectorPlacement { get; set; } = PoiLightChangerDiagnosticPlacement.Global;

        public PoiLightChangerInspectorDisableScope DisableScope { get; set; } = PoiLightChangerInspectorDisableScope.None;

        public ErrorSeverity? NdmfSeverity { get; set; }

        public string InspectorJapanese { get; set; }

        public string InspectorEnglish { get; set; }

        public string NdmfMessage { get; set; }

        public bool StopsBuild { get; set; }

        public List<string> InspectorListItems { get; } = new();

        public List<string> Paths { get; } = new();

        public List<UnityEngine.Object> References { get; } = new();

        public string GetInspectorMessage(PoiLightChangerInspectorLanguageMode languageMode)
        {
            var builder = new StringBuilder();
            builder.Append(languageMode == PoiLightChangerInspectorLanguageMode.English
                ? (InspectorEnglish ?? string.Empty)
                : (InspectorJapanese ?? InspectorEnglish ?? string.Empty));

            if (Paths.Count > 0)
            {
                builder.AppendLine();
                builder.AppendLine();
                builder.AppendLine(languageMode == PoiLightChangerInspectorLanguageMode.English ? "Detected paths:" : "検出パス:");

                foreach (var path in Paths)
                {
                    builder.Append("- ");
                    builder.AppendLine(path);
                }
            }

            if (InspectorListItems.Count > 0)
            {
                builder.AppendLine();
                builder.AppendLine();

                foreach (var item in InspectorListItems)
                {
                    builder.Append("- ");
                    builder.AppendLine(item);
                }
            }

            return builder.ToString().TrimEnd();
        }
    }

    internal sealed class PoiLightChangerProjectPoiyomiStatus
    {
        public bool HasAnyPoiyomiShader { get; set; }

        public bool HasPoiyomiProShader { get; set; }

        public bool HasPoiyomiV10OrNewerProShader { get; set; }
    }

    internal readonly struct PoiLightChangerPoiyomiShaderInfo
    {
        public PoiLightChangerPoiyomiShaderInfo(
            bool isPoiyomiShader,
            int majorVersion,
            int minorVersion,
            PoiLightChangerPoiyomiVariant variant)
        {
            IsPoiyomiShader = isPoiyomiShader;
            MajorVersion = majorVersion;
            MinorVersion = minorVersion;
            Variant = variant;
        }

        public bool IsPoiyomiShader { get; }

        public int MajorVersion { get; }

        public int MinorVersion { get; }

        public PoiLightChangerPoiyomiVariant Variant { get; }
    }

    internal static class PoiLightChangerDiagnostics
    {
        private const int MinimumGuaranteedPoiyomiMajorVersion = 9;
        private const int MinimumGuaranteedPoiyomiMinorVersion = 3;
        private const string GeneratedRootName = "__PoiLightChanger.Generated";
        private static PoiLightChangerProjectPoiyomiStatus cachedProjectPoiyomiStatus;

        public static void InvalidateCaches()
        {
            cachedProjectPoiyomiStatus = null;
        }

        public static IReadOnlyList<PoiLightChangerComponent> FindDuplicateInstalledComponents(GameObject avatarRootObject)
        {
            if (avatarRootObject == null)
            {
                return Array.Empty<PoiLightChangerComponent>();
            }

            var components = avatarRootObject
                .GetComponentsInChildren<PoiLightChangerComponent>(true)
                .Where(component => component != null)
                .ToArray();

            return components.Length > 1 ? components : Array.Empty<PoiLightChangerComponent>();
        }

        public static IReadOnlyList<Transform> FindDuplicateNamedTransforms(
            Transform root,
            PoiLightChangerComponent component)
        {
            if (root == null || component == null)
            {
                return Array.Empty<Transform>();
            }

            var duplicates = new List<Transform>();
            Visit(root, component, duplicates);
            return duplicates;
        }

        public static GameObject FindAvatarRootObject(GameObject source)
        {
            if (source == null)
            {
                return null;
            }

            var descriptors = source.GetComponentsInParent<VRCAvatarDescriptor>(true);
            if (descriptors == null || descriptors.Length == 0)
            {
                return null;
            }

            return descriptors[descriptors.Length - 1]?.gameObject;
        }

        public static string GetTransformPathRelativeTo(Transform root, Transform target)
        {
            if (target == null)
            {
                return string.Empty;
            }

            if (root == null || target == root)
            {
                return target.name;
            }

            var names = new List<string>();
            var current = target;
            while (current != null && current != root)
            {
                names.Add(current.name);
                current = current.parent;
            }

            if (current == root)
            {
                names.Add(root.name);
            }

            names.Reverse();
            return string.Join("/", names);
        }

        public static PoiLightChangerProjectPoiyomiStatus GetProjectPoiyomiStatus()
        {
            if (cachedProjectPoiyomiStatus != null)
            {
                return cachedProjectPoiyomiStatus;
            }

            var status = new PoiLightChangerProjectPoiyomiStatus();
            foreach (var guid in AssetDatabase.FindAssets("t:Shader"))
            {
                var path = AssetDatabase.GUIDToAssetPath(guid);
                var shader = AssetDatabase.LoadAssetAtPath<Shader>(path);
                var info = GetPoiyomiShaderInfo(shader);
                if (!info.IsPoiyomiShader)
                {
                    continue;
                }

                status.HasAnyPoiyomiShader = true;
                if (info.Variant == PoiLightChangerPoiyomiVariant.Pro)
                {
                    status.HasPoiyomiProShader = true;
                    if (info.MajorVersion >= 10)
                    {
                        status.HasPoiyomiV10OrNewerProShader = true;
                    }
                }
            }

            cachedProjectPoiyomiStatus = status;
            return status;
        }

        public static bool HasPoiyomiProInProject()
        {
            return GetProjectPoiyomiStatus().HasPoiyomiProShader;
        }

        public static bool HasPoiyomiV10OrNewerProInProject()
        {
            return GetProjectPoiyomiStatus().HasPoiyomiV10OrNewerProShader;
        }

        public static IReadOnlyList<PoiLightChangerDiagnosticEntry> CollectComponentDiagnostics(
            PoiLightChangerComponent component,
            GameObject avatarRootOverride = null,
            PoiLightChangerLicenseSnapshot licenseSnapshot = null)
        {
            var diagnostics = new List<PoiLightChangerDiagnosticEntry>();
            if (component == null)
            {
                return diagnostics;
            }

            component.EnsureInitialized();
            licenseSnapshot ??= PoiLightChangerLicenseService.GetCurrentSnapshot();
            var projectStatus = GetProjectPoiyomiStatus();
            var avatarRootObject = avatarRootOverride ?? FindAvatarRootObject(component.gameObject);

            if (!projectStatus.HasAnyPoiyomiShader)
            {
                diagnostics.Add(new PoiLightChangerDiagnosticEntry
                {
                    Id = PoiLightChangerDiagnosticId.ProjectPoiyomiMissing,
                    InspectorMessageType = MessageType.Warning,
                    InspectorPlacement = PoiLightChangerDiagnosticPlacement.Global,
                    DisableScope = PoiLightChangerInspectorDisableScope.All,
                    NdmfSeverity = ErrorSeverity.NonFatal,
                    InspectorJapanese = "プロジェクト内にPoiyomi Shaderが見つからないため使用できません。Poiyomiを導入してください。",
                    InspectorEnglish = "Poiyomi Shader was not found in the project, so PLC cannot be used. Install Poiyomi.",
                    NdmfMessage = "[Poi Light Changer] Poiyomi Shader was not found in the project, so PLC cannot be used. Install Poiyomi.",
                    StopsBuild = true,
                    References = { component },
                });
            }
            if (avatarRootObject == null)
            {
                diagnostics.Add(new PoiLightChangerDiagnosticEntry
                {
                    Id = PoiLightChangerDiagnosticId.ComponentOutsideAvatar,
                    InspectorMessageType = MessageType.Warning,
                    InspectorPlacement = PoiLightChangerDiagnosticPlacement.Global,
                    DisableScope = PoiLightChangerInspectorDisableScope.All,
                    NdmfSeverity = null,
                    InspectorJapanese = "このギミックを使用するにはアバター内に配置する必要があります。",
                    InspectorEnglish = "This gimmick must be placed inside an avatar to be used.",
                    StopsBuild = false,
                    References = { component },
                });
                return diagnostics;
            }

            diagnostics.AddRange(CreateLicenseDiagnostics(component, licenseSnapshot));

            var duplicateComponents = FindDuplicateInstalledComponents(avatarRootObject);
            if (duplicateComponents.Count > 1)
            {
                var entry = new PoiLightChangerDiagnosticEntry
                {
                    Id = PoiLightChangerDiagnosticId.DuplicateInstall,
                    InspectorMessageType = MessageType.Warning,
                    InspectorPlacement = PoiLightChangerDiagnosticPlacement.Global,
                    DisableScope = PoiLightChangerInspectorDisableScope.None,
                    NdmfSeverity = ErrorSeverity.NonFatal,
                    InspectorJapanese = "同じアバター内にPLCが複数導入されています。",
                    InspectorEnglish = "Multiple PLC installs were found in the same avatar.",
                    NdmfMessage = "[Poi Light Changer] Multiple PLC installs were found in the same avatar.",
                    StopsBuild = true,
                };

                foreach (var duplicateComponent in duplicateComponents)
                {
                    entry.Paths.Add(GetTransformPathRelativeTo(avatarRootObject.transform, duplicateComponent.transform));
                    entry.References.Add(duplicateComponent);
                }

                diagnostics.Add(entry);
            }

            var duplicateNames = FindDuplicateNamedTransforms(avatarRootObject.transform, component);
            if (duplicateNames.Count > 0)
            {
                var entry = new PoiLightChangerDiagnosticEntry
                {
                    Id = PoiLightChangerDiagnosticId.DuplicateObjectNames,
                    InspectorMessageType = MessageType.Warning,
                    InspectorPlacement = PoiLightChangerDiagnosticPlacement.Global,
                    DisableScope = PoiLightChangerInspectorDisableScope.None,
                    NdmfSeverity = ErrorSeverity.NonFatal,
                    InspectorJapanese = "アバター階層内に同名オブジェクトがあります。マテリアルAnimationのPath解決が曖昧になるため、名前を重複しないように変更してください。",
                    InspectorEnglish = "Duplicate object names were found in the avatar hierarchy. Material Animation path resolution becomes ambiguous, so rename the duplicates.",
                    NdmfMessage = "[Poi Light Changer] Duplicate object names were found in the avatar hierarchy. Material Animation path resolution becomes ambiguous, so rename the duplicates.",
                    StopsBuild = true,
                };

                foreach (var duplicate in duplicateNames)
                {
                    entry.Paths.Add(GetTransformPathRelativeTo(avatarRootObject.transform, duplicate));
                    entry.References.Add(duplicate);
                }

                diagnostics.Add(entry);
            }

            var unsupportedGuaranteedVersionMaterials = new HashSet<string>(StringComparer.Ordinal);
            var detectedPoiyomiVariants = new HashSet<string>(StringComparer.Ordinal);
            foreach (var renderer in avatarRootObject.GetComponentsInChildren<Renderer>(component.Target.IncludeInactiveRenderers))
            {
                if (ShouldSkipRenderer(component, renderer))
                {
                    continue;
                }

                foreach (var material in renderer.sharedMaterials)
                {
                    if (material == null || material.shader == null)
                    {
                        continue;
                    }

                    var info = GetPoiyomiShaderInfo(material.shader);
                    if (!info.IsPoiyomiShader)
                    {
                        continue;
                    }

                    detectedPoiyomiVariants.Add(FormatPoiyomiVariantLabel(info));
                    if (!IsVersionBelowGuaranteedRange(info))
                    {
                        continue;
                    }

                    unsupportedGuaranteedVersionMaterials.Add(material.name);
                }
            }

            if (detectedPoiyomiVariants.Count > 1)
            {
                var variants = string.Join(", ", detectedPoiyomiVariants.OrderBy(variant => variant, StringComparer.Ordinal));
                diagnostics.Add(new PoiLightChangerDiagnosticEntry
                {
                    Id = PoiLightChangerDiagnosticId.AvatarMixedPoiyomiVariants,
                    InspectorJapanese = string.Empty,
                    InspectorEnglish = string.Empty,
                    NdmfMessage = $"[Poi Light Changer] Poiyomi variants are mixed in the avatar. Detected: {variants}",
                    NdmfSeverity = ErrorSeverity.Information,
                    StopsBuild = false,
                });
            }

            if (unsupportedGuaranteedVersionMaterials.Count > 0)
            {
                var entry = new PoiLightChangerDiagnosticEntry
                {
                    Id = PoiLightChangerDiagnosticId.AvatarUnsupportedGuaranteedPoiyomiVersion,
                    InspectorMessageType = MessageType.Warning,
                    InspectorPlacement = PoiLightChangerDiagnosticPlacement.Global,
                    DisableScope = PoiLightChangerInspectorDisableScope.None,
                    NdmfSeverity = null,
                    InspectorJapanese = "v9.3未満はサポート対象外です。意図しない不具合が発生する可能性があります。",
                    InspectorEnglish = "Versions below v9.3 are outside the support range, so unintended bugs may occur.",
                    StopsBuild = false,
                };

                foreach (var materialName in unsupportedGuaranteedVersionMaterials.OrderBy(name => name, StringComparer.Ordinal).Take(8))
                {
                    entry.InspectorListItems.Add(materialName);
                }

                diagnostics.Add(entry);
            }

            if (component.Sync.UseParameterCompression)
            {
                var directLayout = PoiLightChangerParameterProvider.GetDirectParameterLayout(component);
                var maxUsefulChannelCount = PoiLightChangerParameterCompression.GetMaxUsefulChannelCount(directLayout);
                var compressionPlan = PoiLightChangerParameterCompression.BuildPlanFromSlots(
                    directLayout,
                    component.Sync.CompressionChannelCount);
                if (!compressionPlan.IsEffective)
                {
                    diagnostics.Add(new PoiLightChangerDiagnosticEntry
                    {
                        Id = PoiLightChangerDiagnosticId.ParameterCompressionIneffective,
                        InspectorMessageType = MessageType.Warning,
                        InspectorPlacement = PoiLightChangerDiagnosticPlacement.Parameters,
                        DisableScope = PoiLightChangerInspectorDisableScope.None,
                        NdmfSeverity = null,
                        InspectorJapanese = "PLCで有効のパラメーターが圧縮で使用されるパラメーターより少ない為に圧縮を行いません。",
                        InspectorEnglish = "Compression will not run because the number of parameters enabled in PLC is less than the number of parameters used for compression.",
                        StopsBuild = false,
                    });
                }

            }

            if (component.Bake.EnableColorBake && Shader.Find("Hidden/PoiLightChanger/ColorBaker") == null)
            {
                diagnostics.Add(new PoiLightChangerDiagnosticEntry
                {
                    Id = PoiLightChangerDiagnosticId.TextureBakeShaderMissing,
                    InspectorMessageType = MessageType.Warning,
                    InspectorPlacement = PoiLightChangerDiagnosticPlacement.TextureBake,
                    DisableScope = PoiLightChangerInspectorDisableScope.None,
                    NdmfSeverity = null,
                    InspectorJapanese = "Color Bake用shaderが存在しないため、Texture Bakeをスキップします。",
                    InspectorEnglish = "Color Bake shader does not exist, so Texture Bake will be skipped.",
                    NdmfMessage = "[Poi Light Changer] Color Bake shader does not exist, so Texture Bake will be skipped.",
                    StopsBuild = false,
                    References = { component },
                });
            }

            return diagnostics;
        }

        private static IEnumerable<PoiLightChangerDiagnosticEntry> CreateLicenseDiagnostics(
            PoiLightChangerComponent component,
            PoiLightChangerLicenseSnapshot licenseSnapshot)
        {
            if (component == null || licenseSnapshot == null)
            {
                yield break;
            }

            switch (licenseSnapshot.ValidationState)
            {
                case PoiLightChangerLicenseValidationState.Unlicensed:
                    if (string.IsNullOrWhiteSpace(PoiLightChangerLicenseStore.Load().storedLicenseCode))
                    {
                        yield break;
                    }

                    goto case PoiLightChangerLicenseValidationState.SignatureInvalid;

                case PoiLightChangerLicenseValidationState.SignatureInvalid:
                case PoiLightChangerLicenseValidationState.PolicyInvalid:
                case PoiLightChangerLicenseValidationState.LicenseExpired:
                    yield return new PoiLightChangerDiagnosticEntry
                    {
                        Id = PoiLightChangerDiagnosticId.LicenseUnlicensed,
                        InspectorMessageType = MessageType.Warning,
                        InspectorPlacement = PoiLightChangerDiagnosticPlacement.Global,
                        DisableScope = PoiLightChangerInspectorDisableScope.None,
                        NdmfSeverity = ErrorSeverity.Information,
                        InspectorJapanese = BuildLicenseRestrictedInspectorMessageJapanese(licenseSnapshot),
                        InspectorEnglish = BuildLicenseRestrictedInspectorMessageEnglish(licenseSnapshot),
                        NdmfMessage =
                            $"[Poi Light Changer] {NormalizeDiagnosticSentence(licenseSnapshot.StatusMessageEnglish, "No valid license is active.")} Without a valid license, the build will only keep Lighting and Light Direction.",
                        StopsBuild = false,
                        References = { component },
                    };
                    yield break;

                case PoiLightChangerLicenseValidationState.PolicyExpired:
                    yield return new PoiLightChangerDiagnosticEntry
                    {
                        Id = PoiLightChangerDiagnosticId.LicenseOfflineGraceExpired,
                        InspectorMessageType = MessageType.Warning,
                        InspectorPlacement = PoiLightChangerDiagnosticPlacement.Global,
                        DisableScope = PoiLightChangerInspectorDisableScope.None,
                        NdmfSeverity = ErrorSeverity.NonFatal,
                        InspectorJapanese = BuildOfflineGraceExpiredInspectorMessageJapanese(licenseSnapshot),
                        InspectorEnglish = BuildOfflineGraceExpiredInspectorMessageEnglish(licenseSnapshot),
                        NdmfMessage =
                            $"[Poi Light Changer] {NormalizeDiagnosticSentence(licenseSnapshot.StatusMessageEnglish, "The offline grace period has expired and the policy must be refreshed.")} Until the policy is refreshed, the build will only keep Lighting and Light Direction.",
                        StopsBuild = false,
                        References = { component },
                    };
                    yield break;
            }
        }

        private static string BuildOfflineGraceExpiredInspectorMessageJapanese(PoiLightChangerLicenseSnapshot licenseSnapshot)
        {
            return BuildLicenseRestrictedInspectorMessageJapanese(licenseSnapshot);
        }

        private static string BuildOfflineGraceExpiredInspectorMessageEnglish(PoiLightChangerLicenseSnapshot licenseSnapshot)
        {
            return BuildLicenseRestrictedInspectorMessageEnglish(licenseSnapshot);
        }

        private static string BuildLicenseRestrictedInspectorMessageJapanese(PoiLightChangerLicenseSnapshot licenseSnapshot)
        {
            return $"{licenseSnapshot.StatusMessageJapanese}\n現在は無料版の機能のみに制限されます。";
        }

        private static string BuildLicenseRestrictedInspectorMessageEnglish(PoiLightChangerLicenseSnapshot licenseSnapshot)
        {
            return $"{licenseSnapshot.StatusMessageEnglish}\nOnly the free-version feature set is currently available.";
        }

        private static string NormalizeDiagnosticSentence(string value, string fallback)
        {
            var text = string.IsNullOrWhiteSpace(value) ? fallback : value.Trim();
            return text.EndsWith(".", StringComparison.Ordinal) ? text : $"{text}.";
        }

        public static bool HasBlockingBuildDiagnostic(IEnumerable<PoiLightChangerDiagnosticEntry> diagnostics)
        {
            return diagnostics != null && diagnostics.Any(diagnostic => diagnostic != null && diagnostic.StopsBuild);
        }

        public static bool ShouldDisableInspector(IEnumerable<PoiLightChangerDiagnosticEntry> diagnostics)
        {
            return diagnostics != null && diagnostics.Any(diagnostic => diagnostic != null && diagnostic.DisableScope == PoiLightChangerInspectorDisableScope.All);
        }

        public static bool ShouldDisableInspectorScope(
            IEnumerable<PoiLightChangerDiagnosticEntry> diagnostics,
            PoiLightChangerInspectorDisableScope scope)
        {
            return diagnostics != null && diagnostics.Any(diagnostic => diagnostic != null && diagnostic.DisableScope == scope);
        }

        public static IEnumerable<PoiLightChangerDiagnosticEntry> FilterByPlacement(
            IEnumerable<PoiLightChangerDiagnosticEntry> diagnostics,
            PoiLightChangerDiagnosticPlacement placement)
        {
            return diagnostics?.Where(diagnostic => diagnostic != null && diagnostic.InspectorPlacement == placement)
                   ?? Enumerable.Empty<PoiLightChangerDiagnosticEntry>();
        }

        public static PoiLightChangerNdmfMessage CreateNdmfMessage(PoiLightChangerDiagnosticEntry diagnostic)
        {
            if (diagnostic == null || diagnostic.NdmfSeverity == null || string.IsNullOrWhiteSpace(diagnostic.NdmfMessage))
            {
                return null;
            }

            var message = new PoiLightChangerNdmfMessage(
                diagnostic.NdmfSeverity.Value,
                BuildNdmfMessageText(diagnostic));
            foreach (var reference in diagnostic.References.Where(reference => reference != null))
            {
                message.AddReference(ObjectRegistry.GetReference(reference));
            }

            return message;
        }

        private static string BuildNdmfMessageText(PoiLightChangerDiagnosticEntry diagnostic)
        {
            if (diagnostic == null)
            {
                return string.Empty;
            }

            if (diagnostic.Paths.Count == 0)
            {
                return diagnostic.NdmfMessage;
            }

            var builder = new StringBuilder();
            builder.Append(diagnostic.NdmfMessage);

            foreach (var path in diagnostic.Paths)
            {
                builder.AppendLine();
                builder.Append("- ");
                builder.Append(path);
            }

            return builder.ToString();
        }

        public static void ReportNdmfDiagnostic(PoiLightChangerDiagnosticEntry diagnostic)
        {
            var message = CreateNdmfMessage(diagnostic);
            if (message != null)
            {
                ErrorReport.ReportError(message);
            }
        }

        public static void ReportNdmfDiagnostics(IEnumerable<PoiLightChangerDiagnosticEntry> diagnostics)
        {
            foreach (var diagnostic in diagnostics ?? Enumerable.Empty<PoiLightChangerDiagnosticEntry>())
            {
                ReportNdmfDiagnostic(diagnostic);
            }
        }

        public static PoiLightChangerDiagnosticEntry CreateProcessorDiagnostic(
            PoiLightChangerDiagnosticId id,
            string inspectorJapanese,
            string inspectorEnglish,
            string ndmfMessage,
            ErrorSeverity ndmfSeverity,
            bool stopsBuild,
            params UnityEngine.Object[] references)
        {
            var diagnostic = new PoiLightChangerDiagnosticEntry
            {
                Id = id,
                InspectorJapanese = inspectorJapanese,
                InspectorEnglish = inspectorEnglish,
                NdmfMessage = ndmfMessage,
                NdmfSeverity = ndmfSeverity,
                StopsBuild = stopsBuild,
                InspectorPlacement = PoiLightChangerDiagnosticPlacement.Global,
            };

            foreach (var reference in references ?? Array.Empty<UnityEngine.Object>())
            {
                if (reference != null)
                {
                    diagnostic.References.Add(reference);
                }
            }

            return diagnostic;
        }

        public static PoiLightChangerPoiyomiShaderInfo GetPoiyomiShaderInfo(Shader shader)
        {
            if (shader == null)
            {
                return default;
            }

            var shaderName = shader.name ?? string.Empty;
            if (!shaderName.Contains("poiyomi", StringComparison.OrdinalIgnoreCase) &&
                !shaderName.Contains("PCSS4Poi", StringComparison.Ordinal))
            {
                return default;
            }

            var variant = shaderName.Contains("Poiyomi Pro", StringComparison.OrdinalIgnoreCase)
                ? PoiLightChangerPoiyomiVariant.Pro
                : PoiLightChangerPoiyomiVariant.Toon;

            TryGetPoiyomiVersion(shader, out var majorVersion, out var minorVersion);
            return new PoiLightChangerPoiyomiShaderInfo(true, majorVersion, minorVersion, variant);
        }

        public static bool TryGetPoiyomiMajorVersion(Shader shader, out int majorVersion)
        {
            var success = TryGetPoiyomiVersion(shader, out majorVersion, out _);
            return success;
        }

        public static bool TryGetPoiyomiVersion(Shader shader, out int majorVersion, out int minorVersion)
        {
            majorVersion = 0;
            minorVersion = 0;

            try
            {
                var index = shader.FindPropertyIndex("shader_master_label");
                if (index == -1)
                {
                    return false;
                }

                var description = shader.GetPropertyDescription(index);
                if (string.IsNullOrWhiteSpace(description))
                {
                    return false;
                }

                var startTagIndex = description.IndexOf('>');
                var endTagIndex = description.LastIndexOf("</", StringComparison.Ordinal);
                if (startTagIndex >= 0 && endTagIndex > startTagIndex)
                {
                    description = description[(startTagIndex + 1)..endTagIndex];
                }

                var versionStart = -1;
                for (var indexInDescription = 0; indexInDescription < description.Length; indexInDescription++)
                {
                    if (!char.IsDigit(description[indexInDescription]))
                    {
                        continue;
                    }

                    versionStart = indexInDescription;
                    break;
                }

                if (versionStart == -1)
                {
                    return false;
                }

                var versionEnd = versionStart;
                while (versionEnd < description.Length &&
                       (char.IsDigit(description[versionEnd]) || description[versionEnd] == '.'))
                {
                    versionEnd++;
                }

                var versionText = description[versionStart..versionEnd];
                var segments = versionText.Split('.');
                if (segments.Length == 0 || !int.TryParse(segments[0], out majorVersion))
                {
                    return false;
                }

                if (segments.Length > 1)
                {
                    int.TryParse(segments[1], out minorVersion);
                }

                return true;
            }
            catch
            {
                majorVersion = 0;
                minorVersion = 0;
                return false;
            }
        }

        private static bool IsVersionBelowGuaranteedRange(PoiLightChangerPoiyomiShaderInfo shaderInfo)
        {
            if (!shaderInfo.IsPoiyomiShader || shaderInfo.MajorVersion <= 0)
            {
                return false;
            }

            if (shaderInfo.MajorVersion < MinimumGuaranteedPoiyomiMajorVersion)
            {
                return true;
            }

            return shaderInfo.MajorVersion == MinimumGuaranteedPoiyomiMajorVersion &&
                   shaderInfo.MinorVersion < MinimumGuaranteedPoiyomiMinorVersion;
        }

        private static string FormatPoiyomiVariantLabel(PoiLightChangerPoiyomiShaderInfo shaderInfo)
        {
            var versionLabel = shaderInfo.MajorVersion <= 0
                ? "Unknown"
                : $"v{shaderInfo.MajorVersion}.{Mathf.Max(0, shaderInfo.MinorVersion)}";
            var variantLabel = shaderInfo.Variant switch
            {
                PoiLightChangerPoiyomiVariant.Pro => "Pro",
                PoiLightChangerPoiyomiVariant.Toon => "Toon",
                _ => "Unknown",
            };

            return $"{versionLabel} {variantLabel}";
        }

        public static PoiLightChangerNdmfMessage CreateNonFatalMessage(string message)
        {
            return new PoiLightChangerNdmfMessage(ErrorSeverity.NonFatal, message);
        }

        public static PoiLightChangerNdmfMessage CreateInfoMessage(string message)
        {
            return new PoiLightChangerNdmfMessage(ErrorSeverity.Information, message);
        }

        private static bool ShouldSkipRenderer(PoiLightChangerComponent component, Renderer renderer)
        {
            if (component == null || renderer == null)
            {
                return true;
            }

            if (component.Target.IsGameObjectExcluded(renderer.gameObject))
            {
                return true;
            }

            if (!component.Target.IncludeInactiveRenderers && !renderer.gameObject.activeInHierarchy)
            {
                return true;
            }

            return component.General.ExcludeParticleSystem && renderer is ParticleSystemRenderer;
        }

        private static void Visit(
            Transform parent,
            PoiLightChangerComponent component,
            ICollection<Transform> duplicates)
        {
            if (parent == null || component == null || duplicates == null || IsGeneratedTransform(parent))
            {
                return;
            }

            var names = new HashSet<string>(StringComparer.Ordinal);
            for (var index = 0; index < parent.childCount; index++)
            {
                var child = parent.GetChild(index);
                if (IsGeneratedTransform(child))
                {
                    continue;
                }

                if (!child.TryGetComponent<Renderer>(out var renderer) || ShouldSkipRenderer(component, renderer))
                {
                    continue;
                }

                if (!names.Add(child.name))
                {
                    duplicates.Add(child);
                }
            }

            for (var index = 0; index < parent.childCount; index++)
            {
                Visit(parent.GetChild(index), component, duplicates);
            }
        }

        private static bool IsGeneratedTransform(Transform transform)
        {
            if (transform == null)
            {
                return false;
            }

            return string.Equals(transform.name, GeneratedRootName, StringComparison.Ordinal);
        }
    }

    internal sealed class PoiLightChangerNdmfMessage : IError
    {
        private readonly List<ObjectReference> references = new();

        public PoiLightChangerNdmfMessage(ErrorSeverity severity, string message)
        {
            Severity = severity;
            Message = message ?? string.Empty;
        }

        public ErrorSeverity Severity { get; }

        public string Message { get; }

        public void AddReference(ObjectReference obj)
        {
            references.Add(obj);
        }

        public VisualElement CreateVisualElement(ErrorReport report)
        {
            var label = new Label(ToMessage());
            label.style.whiteSpace = WhiteSpace.Normal;
            return label;
        }

        public string ToMessage()
        {
            return Message;
        }
    }
}
