using System.Collections.Generic;

namespace io.github.m8pix.poi_light_changer
{
    internal static class PoiLightChangerLicenseDefaults
    {
        internal sealed class TrustedPublicKey
        {
            public string XBase64 { get; set; } = string.Empty;

            public string YBase64 { get; set; } = string.Empty;
        }

        public const string Product = "poi-light-changer";
        public const string FullLicenseType = "full";
        public const string LicenseCodePrefix = "PLC1";
        public const string PolicyFormat = "PLCPOL1";
        public const string PolicyUrl = "https://m8pix.github.io/poi-light-changer-policy/policy.json";
        public const int OfflineGraceDays = 3;
        public const int RefreshIntervalHours = 24;
        public const int PolicyFetchTimeoutSeconds = 20;
        public const string LegacyTrustedKeyId = "plc-key-2026-01";
        public const string PrimaryTrustedKeyId = "plc-license-private";

        private static readonly IReadOnlyDictionary<string, TrustedPublicKey> TrustedPublicKeys =
            new Dictionary<string, TrustedPublicKey>(System.StringComparer.Ordinal)
            {
                [LegacyTrustedKeyId] = new TrustedPublicKey
                {
                    XBase64 = "VLwCvznqz3TW0RNmPpwpQCaB6e5kcEmJJu34GjLRVUY=",
                    YBase64 = "1XfKfE9xZIp/CGP15w9WmOgyHZ2iWhu64Z8fe1jpkWg=",
                },
                [PrimaryTrustedKeyId] = new TrustedPublicKey
                {
                    XBase64 = "lNgeLXDHzEoQ3USZyDdHpcxsgOs/afogsKF6T5nwuNw=",
                    YBase64 = "JPEhSLlED3T/MotxqUEdkGlyzfC2tYuPiaDl2YnKDEk=",
                },
            };

        public static IReadOnlyDictionary<string, TrustedPublicKey> GetTrustedPublicKeys()
        {
            return TrustedPublicKeys;
        }
    }
}
