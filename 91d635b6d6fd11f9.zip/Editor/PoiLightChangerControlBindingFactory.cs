using System;
using System.Collections.Generic;
using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    internal static class PoiLightChangerControlBindingFactory
    {
        private static readonly IReadOnlyList<string> NoAdditionalAnimatedProperties = Array.Empty<string>();
        private static readonly IReadOnlyDictionary<string, float> NoConstantProperties = new Dictionary<string, float>();

        public static PoiLightChangerImplementedControlBinding CreateSimpleScalarBinding(
            PoiLightChangerComponent component,
            PoiLightChangerControlId controlId,
            PoiLightChangerFloatControlValue control,
            string label,
            IReadOnlyList<string> additionalAnimatedProperties = null,
            IReadOnlyDictionary<string, float> constantProperties = null,
            float? overrideMinValue = null,
            float? overrideMaxValue = null,
            string overrideMenuParameterName = null)
        {
            var binding = CreateBindingShell(component, controlId, control, label, additionalAnimatedProperties, constantProperties);
            binding.OverrideMinValue = overrideMinValue;
            binding.OverrideMaxValue = overrideMaxValue;
            binding.OverrideMenuParameterName = overrideMenuParameterName;
            return binding;
        }

        public static PoiLightChangerImplementedControlBinding CreateSimpleToggleBinding(
            PoiLightChangerComponent component,
            PoiLightChangerControlId controlId,
            PoiLightChangerFloatControlValue control,
            string label,
            IReadOnlyList<string> additionalAnimatedProperties = null,
            IReadOnlyDictionary<string, float> constantProperties = null,
            float? overrideMinValue = null,
            float? overrideMaxValue = null,
            string overrideMenuParameterName = null)
        {
            var binding = CreateSimpleScalarBinding(
                component,
                controlId,
                control,
                label,
                additionalAnimatedProperties,
                constantProperties,
                overrideMinValue,
                overrideMaxValue,
                overrideMenuParameterName);
            binding.IsToggle = true;
            return binding;
        }

        public static PoiLightChangerImplementedControlBinding CreatePseudoToggleBinding(
            PoiLightChangerComponent component,
            PoiLightChangerControlId controlId,
            PoiLightChangerFloatControlValue control,
            string label,
            IReadOnlyList<string> additionalAnimatedProperties = null,
            IReadOnlyDictionary<string, float> constantProperties = null,
            float? overrideMinValue = null,
            float? overrideMaxValue = null,
            string overrideMenuParameterName = null)
        {
            return CreateSimpleToggleBinding(
                component,
                controlId,
                control,
                label,
                additionalAnimatedProperties,
                constantProperties,
                overrideMinValue,
                overrideMaxValue,
                overrideMenuParameterName);
        }

        public static PoiLightChangerImplementedControlBinding CreateLinkedToggleBinding(
            PoiLightChangerComponent component,
            PoiLightChangerControlId controlId,
            PoiLightChangerFloatControlValue control,
            string label,
            GameObject linkedToggleObject,
            IReadOnlyList<string> additionalAnimatedProperties = null,
            IReadOnlyDictionary<string, float> constantProperties = null,
            float? overrideMinValue = null,
            float? overrideMaxValue = null,
            string overrideMenuParameterName = null)
        {
            var binding = CreateSimpleToggleBinding(
                component,
                controlId,
                control,
                label,
                additionalAnimatedProperties,
                constantProperties,
                overrideMinValue,
                overrideMaxValue,
                overrideMenuParameterName);
            binding.LinkedToggleObject = linkedToggleObject;
            return binding;
        }

        public static IEnumerable<PoiLightChangerImplementedControlBinding> CreateLightDirectionBindings(PoiLightChangerComponent component)
        {
            yield return CreateSimpleToggleBinding(
                component,
                PoiLightChangerControlId.LightDirectionToggle,
                component.Poiyomi.LightDirectionToggle,
                "Light Direction Toggle",
                overrideMaxValue: (float)component.Poiyomi.LightDirectionToggleMode);

            var lightDirXCtrl = component.Poiyomi.LightDirectionX;
            var angle = lightDirXCtrl.Value * 2f * Mathf.PI;
            var definitionX = PoiLightChangerControlRegistry.GetDefinition(PoiLightChangerControlId.LightDirectionX);

            yield return CreateBindingShell(component, PoiLightChangerControlId.LightDirectionX, lightDirXCtrl, "Light Direction X (x)")
                .With(binding =>
                {
                    binding.IsAdditiveVectorControl = true;
                    binding.VectorBasePropertyName = PoiLightChangerPoiyomiShaderConstants.LightngForcedDirection;
                    binding.VectorComponentIndex = 0;
                    binding.AdditiveVectorKeyframes = new (float, float)[]
                    {
                        (0.00f, 0f),
                        (0.25f, 1000f),
                        (0.50f, 0f),
                        (0.75f, -1000f),
                        (1.00f, 0f),
                    };
                    binding.MaterialInitialValueOverride = Mathf.Sin(angle) * 1000f;
                });

            yield return CreateBindingShell(component, PoiLightChangerControlId.LightDirectionX, lightDirXCtrl, "Light Direction X (z)")
                .With(binding =>
                {
                    binding.IsAdditiveVectorControl = true;
                    binding.VectorBasePropertyName = PoiLightChangerPoiyomiShaderConstants.LightngForcedDirection;
                    binding.VectorComponentIndex = 2;
                    binding.AdditiveVectorKeyframes = new (float, float)[]
                    {
                        (0.00f, 1000f),
                        (0.25f, 0f),
                        (0.50f, -1000f),
                        (0.75f, 0f),
                        (1.00f, 1000f),
                    };
                    binding.IsSecondaryComponent = true;
                    binding.OverrideMaterialPropertyName = PoiLightChangerPoiyomiShaderConstants.LightngForcedDirectionZ;
                    binding.MaterialInitialValueOverride = Mathf.Cos(angle) * 1000f;
                    binding.Definition = definitionX;
                });

            yield return CreateBindingShell(component, PoiLightChangerControlId.LightDirectionY, component.Poiyomi.LightDirectionY, "Light Direction Y")
                .With(binding =>
                {
                    binding.IsAdditiveVectorControl = true;
                    binding.VectorBasePropertyName = PoiLightChangerPoiyomiShaderConstants.LightngForcedDirection;
                    binding.VectorComponentIndex = 1;
                    binding.OverrideMinValue = 1500f;
                    binding.OverrideMaxValue = -1500f;
                });
        }

        public static IEnumerable<PoiLightChangerImplementedControlBinding> CreateNormalizedColorBindings(
            PoiLightChangerComponent component,
            PoiLightChangerControlId controlId,
            PoiLightChangerColorControlValue colorControl,
            string parameterLeafPrefix,
            string labelPrefix,
            string propertyR,
            string propertyG,
            string propertyB)
        {
            var definition = PoiLightChangerControlRegistry.GetDefinition(controlId);
            var color = colorControl.Value;
            var normalizedDefaults = PoiLightChangerControlBindingUtility.ResolveNormalizedColorDefaults(colorControl);
            var commonFlags = CreateSplitControlFlags(colorControl);
            var prefix = PoiLightChangerGeneralSettings.DefaultParameterPrefix;
            var internalCategory = GetInternalMenuCategory(controlId);
            var internalParentLabel = definition.MenuLabelEnglish;
            var commonMenuPathPrefix = $"{internalCategory}//{internalParentLabel}";

            yield return CreateColorComponentBinding(
                component,
                controlId,
                definition,
                commonFlags,
                normalizedDefaults["r"],
                labelPrefix,
                "R",
                "R",
                "r",
                $"{commonMenuPathPrefix}//r",
                $"{prefix}/{parameterLeafPrefix}/r",
                propertyR);

            yield return CreateColorComponentBinding(
                component,
                controlId,
                definition,
                commonFlags,
                normalizedDefaults["g"],
                labelPrefix,
                "G",
                "G",
                "g",
                $"{commonMenuPathPrefix}//g",
                $"{prefix}/{parameterLeafPrefix}/g",
                propertyG);

            yield return CreateColorComponentBinding(
                component,
                controlId,
                definition,
                commonFlags,
                normalizedDefaults["b"],
                labelPrefix,
                "B",
                "B",
                "b",
                $"{commonMenuPathPrefix}//b",
                $"{prefix}/{parameterLeafPrefix}/b",
                propertyB);
        }

        public static IEnumerable<PoiLightChangerImplementedControlBinding> CreateBacklightHdrColorBindings(PoiLightChangerComponent component)
        {
            var colorControl = component.Poiyomi.BacklightColor;
            var definition = PoiLightChangerControlRegistry.GetDefinition(PoiLightChangerControlId.BacklightColor);
            var model = PoiLightChangerBacklightColorModel.FromControl(colorControl);
            var commonFlags = CreateSplitControlFlags(colorControl);
            var normalizedColorRange = PoiLightChangerControlBindingUtility.GetBacklightNormalizedColorRange(colorControl?.Range ?? new Vector2(0f, 1f));
            var prefix = PoiLightChangerGeneralSettings.DefaultParameterPrefix;
            var internalCategory = GetInternalMenuCategory(PoiLightChangerControlId.BacklightColor);
            var internalParentLabel = definition.MenuLabelEnglish;
            var commonMenuPathPrefix = $"{internalCategory}//{internalParentLabel}";

            yield return CreateColorComponentBinding(
                component,
                PoiLightChangerControlId.BacklightColor,
                definition,
                commonFlags,
                model.NormalizedColor.r,
                "Backlight Color",
                "R",
                "R",
                "r",
                $"{commonMenuPathPrefix}//r",
                $"{prefix}/BacklightColor/r",
                PoiLightChangerPoiyomiShaderConstants.BacklightColorR,
                model.ResolvedColor.r,
                normalizedColorRange);

            yield return CreateColorComponentBinding(
                component,
                PoiLightChangerControlId.BacklightColor,
                definition,
                commonFlags,
                model.NormalizedColor.g,
                "Backlight Color",
                "G",
                "G",
                "g",
                $"{commonMenuPathPrefix}//g",
                $"{prefix}/BacklightColor/g",
                PoiLightChangerPoiyomiShaderConstants.BacklightColorG,
                model.ResolvedColor.g,
                normalizedColorRange);

            yield return CreateColorComponentBinding(
                component,
                PoiLightChangerControlId.BacklightColor,
                definition,
                commonFlags,
                model.NormalizedColor.b,
                "Backlight Color",
                "B",
                "B",
                "b",
                $"{commonMenuPathPrefix}//b",
                $"{prefix}/BacklightColor/b",
                PoiLightChangerPoiyomiShaderConstants.BacklightColorB,
                model.ResolvedColor.b,
                normalizedColorRange);

            if (model.IntensityMax > 0f)
            {
                var intensityBinding = CreateBindingShell(
                    component,
                    PoiLightChangerControlId.BacklightColor,
                    new PoiLightChangerFloatControlValue(model.NormalizedIntensity, 0f, 1f)
                    {
                        Enable = commonFlags.Enable,
                        Animation = commonFlags.Animation,
                        Saved = commonFlags.Saved,
                        Synced = commonFlags.Synced,
                    },
                    "Backlight Color Intensity");
                intensityBinding.MenuCategory = internalCategory;
                intensityBinding.MenuLabel = $"{internalParentLabel} intensity";
                intensityBinding.OverrideMenuPath = $"{commonMenuPathPrefix}//intensity";
                intensityBinding.OverrideDisplayMenuPathJapanese = CreateDisplayMenuPath(definition, definition.MenuLabelJapanese, definition.MenuLabelEnglish, "強度", "Intensity").Japanese;
                intensityBinding.OverrideDisplayMenuPathEnglish = CreateDisplayMenuPath(definition, definition.MenuLabelJapanese, definition.MenuLabelEnglish, "強度", "Intensity").English;
                intensityBinding.OverrideParameterName = $"{prefix}/BacklightColor/intensity";
                intensityBinding.IsBacklightColorIntensityControl = true;
                intensityBinding.BacklightColorIntensityMax = model.IntensityMax;
                intensityBinding.BacklightColorIntensityNormalizedMin = normalizedColorRange.x;
                yield return intensityBinding;
            }
        }

        private static PoiLightChangerImplementedControlBinding CreateColorComponentBinding(
            PoiLightChangerComponent component,
            PoiLightChangerControlId controlId,
            PoiLightChangerControlDefinition definition,
            PoiLightChangerFloatControlValue commonFlags,
            float value,
            string labelPrefix,
            string labelSuffix,
            string displayLeafJapanese,
            string internalLeafEnglish,
            string overrideMenuPath,
            string overrideParameterName,
            string overrideMaterialPropertyName,
            float? materialInitialValueOverride = null,
            Vector2? controlRangeOverride = null)
        {
            var controlRange = controlRangeOverride ?? new Vector2(0f, 1f);
            var binding = CreateBindingShell(
                component,
                controlId,
                new PoiLightChangerFloatControlValue(value, controlRange.x, controlRange.y)
                {
                    Enable = commonFlags.Enable,
                    Animation = commonFlags.Animation,
                    Saved = commonFlags.Saved,
                    Synced = commonFlags.Synced,
                },
                $"{labelPrefix} {labelSuffix}");
            binding.MenuCategory = GetInternalMenuCategory(controlId);
            binding.MenuLabel = $"{definition.MenuLabelEnglish} {internalLeafEnglish}";
            binding.OverrideMenuPath = overrideMenuPath;
            binding.OverrideDisplayMenuPathJapanese = CreateDisplayMenuPath(
                definition,
                definition.MenuLabelJapanese,
                definition.MenuLabelEnglish,
                displayLeafJapanese,
                displayLeafJapanese).Japanese;
            binding.OverrideDisplayMenuPathEnglish = CreateDisplayMenuPath(
                definition,
                definition.MenuLabelJapanese,
                definition.MenuLabelEnglish,
                displayLeafJapanese,
                displayLeafJapanese).English;
            binding.OverrideMaterialPropertyName = overrideMaterialPropertyName;
            binding.OverrideParameterName = overrideParameterName;
            binding.MaterialInitialValueOverride = materialInitialValueOverride ?? value;
            return binding;
        }

        private static PoiLightChangerImplementedControlBinding CreateBindingShell(
            PoiLightChangerComponent component,
            PoiLightChangerControlId controlId,
            PoiLightChangerFloatControlValue control,
            string label,
            IReadOnlyList<string> additionalAnimatedProperties = null,
            IReadOnlyDictionary<string, float> constantProperties = null)
        {
            var definition = PoiLightChangerControlRegistry.GetDefinition(controlId);

            return new PoiLightChangerImplementedControlBinding
            {
                Definition = definition,
                Control = control,
                SectionEnabled = PoiLightChangerControlRegistry.IsSectionEnabled(component, definition),
                Label = label,
                MenuCategory = GetInternalMenuCategory(controlId),
                MenuLabel = GetInternalMenuLabel(controlId),
                MenuCategoryJapanese = GetDisplayMenuCategoryJapanese(controlId),
                MenuCategoryEnglish = GetDisplayMenuCategoryEnglish(controlId),
                MenuLabelJapanese = definition.MenuLabelJapanese,
                MenuLabelEnglish = definition.MenuLabelEnglish,
                AdditionalAnimatedProperties = additionalAnimatedProperties ?? NoAdditionalAnimatedProperties,
                ConstantProperties = constantProperties ?? NoConstantProperties,
            };
        }

        private static PoiLightChangerFloatControlValue CreateSplitControlFlags(PoiLightChangerColorControlValue colorControl)
        {
            return new PoiLightChangerFloatControlValue
            {
                Enable = colorControl.Enable,
                Animation = colorControl.Animation,
                Saved = colorControl.Saved,
                Synced = colorControl.Synced,
            };
        }

        private static string GetInternalMenuCategory(PoiLightChangerControlId controlId)
        {
            var definition = PoiLightChangerControlRegistry.GetDefinition(controlId);
            var sectionId = PoiLightChangerControlRegistry.GetSectionId(definition);
            return sectionId == PoiLightChangerControlSectionId.LightDirection
                ? PoiLightChangerControlRegistry.GetInspectorSectionTitleJapanese(sectionId)
                : PoiLightChangerControlRegistry.GetInspectorSectionTitleEnglish(sectionId);
        }

        private static string GetInternalMenuLabel(PoiLightChangerControlId controlId)
        {
            var menuPath = PoiLightChangerControlRegistry.GetDefinition(controlId)?.MenuPath ?? string.Empty;
            var separatorIndex = menuPath.LastIndexOf('/');
            return separatorIndex >= 0 ? menuPath[(separatorIndex + 1)..] : menuPath;
        }

        private static string GetDisplayMenuCategoryJapanese(PoiLightChangerControlId controlId)
        {
            var definition = PoiLightChangerControlRegistry.GetDefinition(controlId);
            return PoiLightChangerControlRegistry.GetInspectorSectionTitleJapanese(PoiLightChangerControlRegistry.GetSectionId(definition));
        }

        private static string GetDisplayMenuCategoryEnglish(PoiLightChangerControlId controlId)
        {
            var definition = PoiLightChangerControlRegistry.GetDefinition(controlId);
            return PoiLightChangerControlRegistry.GetInspectorSectionTitleEnglish(PoiLightChangerControlRegistry.GetSectionId(definition));
        }

        private static (string Japanese, string English) CreateDisplayMenuPath(
            PoiLightChangerControlDefinition definition,
            string parentJapanese,
            string parentEnglish,
            string leafJapanese,
            string leafEnglish)
        {
            var sectionId = PoiLightChangerControlRegistry.GetSectionId(definition);
            return (
                $"{PoiLightChangerControlRegistry.GetInspectorSectionTitleJapanese(sectionId)}//{parentJapanese}//{leafJapanese}",
                $"{PoiLightChangerControlRegistry.GetInspectorSectionTitleEnglish(sectionId)}//{parentEnglish}//{leafEnglish}");
        }

        private static PoiLightChangerImplementedControlBinding With(
            this PoiLightChangerImplementedControlBinding binding,
            Action<PoiLightChangerImplementedControlBinding> configure)
        {
            configure(binding);
            return binding;
        }
    }
}
