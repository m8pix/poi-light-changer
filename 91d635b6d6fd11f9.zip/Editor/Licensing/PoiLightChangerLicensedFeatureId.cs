namespace io.github.m8pix.poi_light_changer
{
    internal enum PoiLightChangerLicensedFeatureId
    {
        MaterialOverrides = 0,
        Lighting = 1,
        LightDirection = 2,
        Color = 3,
        Backlight = 4,
        Proximity = 5,
        Outline = 6,
        SSAO = 7,
        ContactShadow = 8,
        ParameterCompression = 9,
        Parameters = 10,
        Presets = 11,
        TextureBake = 12,
    }
}
