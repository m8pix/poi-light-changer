using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using VRC.SDKBase;

namespace io.github.m8pix.poi_light_changer
{
    internal enum PoiLightChangerCompressedValueKind
    {
        Float,
        Int,
        Bool,
    }

    internal sealed class PoiLightChangerCompressedParameter
    {
        public string Name { get; set; }

        public PoiLightChangerCompressedValueKind Kind { get; set; }

        public bool Synced { get; set; }

        public bool Saved { get; set; }

        public float DefaultValue { get; set; }
    }

    internal sealed class PoiLightChangerCompressionBatchEntry
    {
        public PoiLightChangerCompressedParameter Parameter { get; set; }

        public string TransportParameterName { get; set; }
    }

    internal sealed class PoiLightChangerCompressionBatch
    {
        public int BatchIndex { get; set; }

        public IReadOnlyList<PoiLightChangerCompressionBatchEntry> Entries { get; set; } = Array.Empty<PoiLightChangerCompressionBatchEntry>();
    }

    internal sealed class PoiLightChangerSyncCompressionPlan
    {
        public const string SystemPrefix = PoiLightChangerGeneralSettings.DefaultParameterPrefix + "/System/Compression";
        public const string IndexParameterName = SystemPrefix + "/Index";
        public const string LayerName = "Poi Light Changer Parameter Compressor";

        public PoiLightChangerSyncCompressionPlan(
            IReadOnlyList<PoiLightChangerCompressedParameter> sourceParameters,
            IReadOnlyList<PoiLightChangerCompressedParameter> targetParameters,
            IReadOnlyList<PoiLightChangerCompressionBatch> batches,
            int floatChannelCount,
            int intChannelCount,
            int originalBits,
            int compressedBits)
        {
            SourceParameters = sourceParameters ?? Array.Empty<PoiLightChangerCompressedParameter>();
            TargetParameters = targetParameters ?? Array.Empty<PoiLightChangerCompressedParameter>();
            Batches = batches ?? Array.Empty<PoiLightChangerCompressionBatch>();
            FloatChannelCount = Mathf.Max(0, floatChannelCount);
            IntChannelCount = Mathf.Max(0, intChannelCount);
            OriginalBits = Mathf.Max(0, originalBits);
            CompressedBits = Mathf.Max(0, compressedBits);
            SavedBits = OriginalBits - CompressedBits;
        }

        public IReadOnlyList<PoiLightChangerCompressedParameter> SourceParameters { get; }

        public IReadOnlyList<PoiLightChangerCompressedParameter> TargetParameters { get; }

        public IReadOnlyList<PoiLightChangerCompressionBatch> Batches { get; }

        public int FloatChannelCount { get; }

        public int IntChannelCount { get; }

        public int OriginalBits { get; }

        public int CompressedBits { get; }

        public int SavedBits { get; }

        public bool IsEffective => Batches.Count > 0 && SavedBits > 0;

        public static string GetFloatChannelName(int index) => $"{SystemPrefix}/Float{index}";

        public static string GetIntChannelName(int index) => $"{SystemPrefix}/Int{index}";
    }

    internal static class PoiLightChangerParameterCompression
    {
        public const int MaxSelectableChannelCount = 8;
        private const float SweepIntervalSeconds = 0.5f;
        private const float BatchHoldSeconds = 3f / 30f;
        private static readonly StringComparer ParameterNameComparer = StringComparer.Ordinal;

        public static PoiLightChangerSyncCompressionPlan BuildPlanFromSlots(
            IEnumerable<PoiLightChangerParameterSlot> slots,
            int requestedChannelCount = 1)
        {
            var source = (slots ?? Enumerable.Empty<PoiLightChangerParameterSlot>())
                .Where(slot => slot != null && !string.IsNullOrWhiteSpace(slot.Name))
                .Select(slot => new PoiLightChangerCompressedParameter
                {
                    Name = slot.Name,
                    Kind = slot.ParameterType switch
                    {
                        AnimatorControllerParameterType.Int => PoiLightChangerCompressedValueKind.Int,
                        AnimatorControllerParameterType.Bool => PoiLightChangerCompressedValueKind.Bool,
                        _ => PoiLightChangerCompressedValueKind.Float,
                    },
                    Synced = slot.Synced,
                    Saved = slot.Saved,
                    DefaultValue = slot.DefaultValue,
                })
                .ToList();

            var targets = source
                .Where(parameter => parameter.Synced)
                .Where(parameter =>
                    parameter.Kind == PoiLightChangerCompressedValueKind.Float ||
                    parameter.Kind == PoiLightChangerCompressedValueKind.Int ||
                    parameter.Kind == PoiLightChangerCompressedValueKind.Bool)
                .ToList();

            var originalBits = CalculateOriginalBits(targets);
            if (targets.Count == 0)
            {
                return new PoiLightChangerSyncCompressionPlan(source, targets, Array.Empty<PoiLightChangerCompressionBatch>(), 0, 0, originalBits, originalBits);
            }

            requestedChannelCount = Mathf.Clamp(requestedChannelCount, 1, MaxSelectableChannelCount);

            var scalarTargetCount = targets.Count(parameter =>
                parameter.Kind == PoiLightChangerCompressedValueKind.Float ||
                parameter.Kind == PoiLightChangerCompressedValueKind.Bool);
            var intTargetCount = targets.Count(parameter => parameter.Kind == PoiLightChangerCompressedValueKind.Int);
            var floatChannelCount = scalarTargetCount > 0 ? Mathf.Min(requestedChannelCount, scalarTargetCount) : 0;
            var intChannelCount = intTargetCount > 0 ? Mathf.Min(requestedChannelCount, intTargetCount) : 0;
            var compressedBits = CalculateCompressedBits(floatChannelCount, intChannelCount);

            if (compressedBits >= originalBits)
            {
                return new PoiLightChangerSyncCompressionPlan(source, targets, Array.Empty<PoiLightChangerCompressionBatch>(), 0, 0, originalBits, originalBits);
            }

            var batches = BuildBatches(targets, floatChannelCount, intChannelCount);
            return new PoiLightChangerSyncCompressionPlan(
                source,
                targets,
                batches,
                floatChannelCount,
                intChannelCount,
                originalBits,
                compressedBits);
        }

        public static IEnumerable<PoiLightChangerParameterSlot> RewriteSlots(
            IEnumerable<PoiLightChangerParameterSlot> directSlots,
            PoiLightChangerSyncCompressionPlan plan)
        {
            var source = (directSlots ?? Enumerable.Empty<PoiLightChangerParameterSlot>())
                .Where(slot => slot != null)
                .Select(slot => slot.Clone())
                .ToList();

            if (plan == null || !plan.IsEffective)
            {
                foreach (var slot in source)
                {
                    yield return slot;
                }

                yield break;
            }

            var targetNames = new HashSet<string>(
                plan.TargetParameters.Select(parameter => parameter.Name),
                ParameterNameComparer);

            foreach (var slot in source)
            {
                if (targetNames.Contains(slot.Name))
                {
                    slot.Synced = false;
                }

                yield return slot;
            }

            yield return CreateSystemSlot(
                PoiLightChangerSyncCompressionPlan.IndexParameterName,
                AnimatorControllerParameterType.Int);

            for (var index = 0; index < plan.FloatChannelCount; index++)
            {
                yield return CreateSystemSlot(
                    PoiLightChangerSyncCompressionPlan.GetFloatChannelName(index),
                    AnimatorControllerParameterType.Float);
            }

            for (var index = 0; index < plan.IntChannelCount; index++)
            {
                yield return CreateSystemSlot(
                    PoiLightChangerSyncCompressionPlan.GetIntChannelName(index),
                    AnimatorControllerParameterType.Int);
            }
        }

        public static int GetMaxUsefulChannelCount(IEnumerable<PoiLightChangerParameterSlot> slots)
        {
            var parameters = (slots ?? Enumerable.Empty<PoiLightChangerParameterSlot>())
                .Where(slot => slot != null && slot.Synced)
                .Select(slot => slot.ParameterType switch
                {
                    AnimatorControllerParameterType.Int => PoiLightChangerCompressedValueKind.Int,
                    AnimatorControllerParameterType.Bool => PoiLightChangerCompressedValueKind.Bool,
                    _ => PoiLightChangerCompressedValueKind.Float,
                })
                .ToArray();

            var originalBits = parameters.Sum(kind => kind == PoiLightChangerCompressedValueKind.Bool ? 1 : 8);
            var scalarTargetCount = parameters.Count(kind =>
                kind == PoiLightChangerCompressedValueKind.Float ||
                kind == PoiLightChangerCompressedValueKind.Bool);
            var intTargetCount = parameters.Count(kind => kind == PoiLightChangerCompressedValueKind.Int);
            var maxRequested = Mathf.Max(1, Mathf.Max(scalarTargetCount, intTargetCount));

            var maxUseful = 1;
            for (var requested = 1; requested <= maxRequested; requested++)
            {
                var floatChannelCount = scalarTargetCount > 0 ? Mathf.Min(requested, scalarTargetCount) : 0;
                var intChannelCount = intTargetCount > 0 ? Mathf.Min(requested, intTargetCount) : 0;
                if (CalculateCompressedBits(floatChannelCount, intChannelCount) < originalBits)
                {
                    maxUseful = requested;
                }
            }

            return maxUseful;
        }

        public static float GetApproximateSyncTimeSeconds(
            IEnumerable<PoiLightChangerParameterSlot> slots,
            int requestedChannelCount)
        {
            requestedChannelCount = Mathf.Clamp(requestedChannelCount, 1, MaxSelectableChannelCount);

            var parameters = (slots ?? Enumerable.Empty<PoiLightChangerParameterSlot>())
                .Where(slot => slot != null && slot.Synced)
                .Select(slot => slot.ParameterType switch
                {
                    AnimatorControllerParameterType.Int => PoiLightChangerCompressedValueKind.Int,
                    AnimatorControllerParameterType.Bool => PoiLightChangerCompressedValueKind.Bool,
                    _ => PoiLightChangerCompressedValueKind.Float,
                })
                .ToArray();

            var scalarTargetCount = parameters.Count(kind =>
                kind == PoiLightChangerCompressedValueKind.Float ||
                kind == PoiLightChangerCompressedValueKind.Bool);
            var intTargetCount = parameters.Count(kind => kind == PoiLightChangerCompressedValueKind.Int);
            var activeFloatChannels = scalarTargetCount > 0 ? Mathf.Min(requestedChannelCount, scalarTargetCount) : 0;
            var activeIntChannels = intTargetCount > 0 ? Mathf.Min(requestedChannelCount, intTargetCount) : 0;
            var scalarBatchCount = activeFloatChannels > 0 ? Mathf.CeilToInt((float)scalarTargetCount / activeFloatChannels) : 0;
            var intBatchCount = activeIntChannels > 0 ? Mathf.CeilToInt((float)intTargetCount / activeIntChannels) : 0;
            var batchCount = Mathf.Max(scalarBatchCount, intBatchCount);

            return batchCount <= 0 ? 0f : SweepIntervalSeconds + (batchCount * BatchHoldSeconds);
        }

        public static void ApplyToExpressionParameters(VRCExpressionParameters expressionParameters, PoiLightChangerSyncCompressionPlan plan)
        {
            if (expressionParameters == null || plan == null || !plan.IsEffective)
            {
                return;
            }

            var targetNames = new HashSet<string>(
                plan.TargetParameters.Select(parameter => parameter.Name),
                ParameterNameComparer);

            var rewritten = new List<VRCExpressionParameters.Parameter>();
            foreach (var parameter in expressionParameters.parameters ?? Array.Empty<VRCExpressionParameters.Parameter>())
            {
                if (parameter == null || IsSystemCompressionParameter(parameter.name))
                {
                    continue;
                }

                if (targetNames.Contains(parameter.name))
                {
                    parameter.networkSynced = false;
                }

                rewritten.Add(parameter);
            }

            rewritten.Add(new VRCExpressionParameters.Parameter
            {
                name = PoiLightChangerSyncCompressionPlan.IndexParameterName,
                valueType = VRCExpressionParameters.ValueType.Int,
                saved = false,
                defaultValue = 0f,
                networkSynced = true,
            });

            for (var index = 0; index < plan.FloatChannelCount; index++)
            {
                rewritten.Add(new VRCExpressionParameters.Parameter
                {
                    name = PoiLightChangerSyncCompressionPlan.GetFloatChannelName(index),
                    valueType = VRCExpressionParameters.ValueType.Float,
                    saved = false,
                    defaultValue = 0f,
                    networkSynced = true,
                });
            }

            for (var index = 0; index < plan.IntChannelCount; index++)
            {
                rewritten.Add(new VRCExpressionParameters.Parameter
                {
                    name = PoiLightChangerSyncCompressionPlan.GetIntChannelName(index),
                    valueType = VRCExpressionParameters.ValueType.Int,
                    saved = false,
                    defaultValue = 0f,
                    networkSynced = true,
                });
            }

            expressionParameters.parameters = rewritten.ToArray();
            EditorUtility.SetDirty(expressionParameters);
        }

        public static bool TryGetFxController(VRCAvatarDescriptor descriptor, out AnimatorController fxController)
        {
            fxController = null;
            if (descriptor == null)
            {
                return false;
            }

            var layers = descriptor.baseAnimationLayers;
            if (layers == null || layers.Length <= (int)VRCAvatarDescriptor.AnimLayerType.FX)
            {
                return false;
            }

            var fxLayer = layers[(int)VRCAvatarDescriptor.AnimLayerType.FX];
            if (fxLayer.isDefault || fxLayer.animatorController == null)
            {
                return false;
            }

            fxController = fxLayer.animatorController as AnimatorController;
            return fxController != null;
        }

        public static void ApplyToAnimatorController(
            AnimatorController controller,
            PoiLightChangerSyncCompressionPlan plan,
            string immediateTransmitTriggerParameterName = null)
        {
            if (controller == null || plan == null || !plan.IsEffective)
            {
                return;
            }

            RemoveExistingLayer(controller);
            EnsureControllerParameters(controller, plan, immediateTransmitTriggerParameterName);

            var stateMachine = new AnimatorStateMachine
            {
                name = PoiLightChangerSyncCompressionPlan.LayerName,
                hideFlags = HideFlags.HideInHierarchy,
            };
            AssetDatabase.AddObjectToAsset(stateMachine, controller);

            var idleClip = CreateTimingClip(controller, "PLC_Compression_Idle", 1f / 60f);
            var sweepClip = CreateTimingClip(controller, "PLC_Compression_Sweep", SweepIntervalSeconds);
            var batchClip = CreateTimingClip(controller, "PLC_Compression_Batch", BatchHoldSeconds);

            var rootIdle = stateMachine.AddState("Idle", new Vector3(0f, 0f));
            rootIdle.motion = idleClip;
            rootIdle.writeDefaultValues = true;
            stateMachine.defaultState = rootIdle;

            BuildReceiveBranch(stateMachine, rootIdle, idleClip, batchClip, plan.Batches);
            BuildTransmitBranch(stateMachine, rootIdle, sweepClip, batchClip, plan.Batches, immediateTransmitTriggerParameterName);

            var layers = controller.layers.ToList();
            layers.Add(new AnimatorControllerLayer
            {
                name = PoiLightChangerSyncCompressionPlan.LayerName,
                defaultWeight = 1f,
                stateMachine = stateMachine,
            });
            controller.layers = layers.ToArray();

            EditorUtility.SetDirty(controller);
        }

        private static PoiLightChangerParameterSlot CreateSystemSlot(
            string name,
            AnimatorControllerParameterType parameterType)
        {
            return new PoiLightChangerParameterSlot
            {
                Name = name,
                ParameterType = parameterType,
                Synced = true,
                Saved = false,
                IsHidden = true,
                DefaultValue = 0f,
            };
        }

        private static int CalculateOriginalBits(IEnumerable<PoiLightChangerCompressedParameter> parameters)
        {
            return (parameters ?? Enumerable.Empty<PoiLightChangerCompressedParameter>())
                .Sum(parameter => parameter.Kind == PoiLightChangerCompressedValueKind.Bool ? 1 : 8);
        }

        private static int CalculateCompressedBits(int floatChannelCount, int intChannelCount)
        {
            return 8 + (floatChannelCount * 8) + (intChannelCount * 8);
        }

        private static List<PoiLightChangerCompressionBatch> BuildBatches(
            IReadOnlyList<PoiLightChangerCompressedParameter> targets,
            int floatChannelCount,
            int intChannelCount)
        {
            var scalarTargets = targets
                .Where(parameter =>
                    parameter.Kind == PoiLightChangerCompressedValueKind.Float ||
                    parameter.Kind == PoiLightChangerCompressedValueKind.Bool)
                .ToArray();
            var intTargets = targets
                .Where(parameter => parameter.Kind == PoiLightChangerCompressedValueKind.Int)
                .ToArray();

            var batchCount = Mathf.Max(
                CalculateBatchCount(scalarTargets.Length, floatChannelCount),
                CalculateBatchCount(intTargets.Length, intChannelCount));

            var batches = new List<PoiLightChangerCompressionBatch>(batchCount);
            for (var batchIndex = 0; batchIndex < batchCount; batchIndex++)
            {
                var entries = new List<PoiLightChangerCompressionBatchEntry>();

                for (var channelIndex = 0; channelIndex < floatChannelCount; channelIndex++)
                {
                    var targetIndex = (batchIndex * floatChannelCount) + channelIndex;
                    if (targetIndex >= scalarTargets.Length)
                    {
                        break;
                    }

                    entries.Add(new PoiLightChangerCompressionBatchEntry
                    {
                        Parameter = scalarTargets[targetIndex],
                        TransportParameterName = PoiLightChangerSyncCompressionPlan.GetFloatChannelName(channelIndex),
                    });
                }

                for (var channelIndex = 0; channelIndex < intChannelCount; channelIndex++)
                {
                    var targetIndex = (batchIndex * intChannelCount) + channelIndex;
                    if (targetIndex >= intTargets.Length)
                    {
                        break;
                    }

                    entries.Add(new PoiLightChangerCompressionBatchEntry
                    {
                        Parameter = intTargets[targetIndex],
                        TransportParameterName = PoiLightChangerSyncCompressionPlan.GetIntChannelName(channelIndex),
                    });
                }

                if (entries.Count == 0)
                {
                    continue;
                }

                batches.Add(new PoiLightChangerCompressionBatch
                {
                    BatchIndex = batchIndex + 1,
                    Entries = entries,
                });
            }

            return batches;
        }

        private static int CalculateBatchCount(int targetCount, int channelCount)
        {
            if (targetCount <= 0)
            {
                return 0;
            }

            return channelCount <= 0
                ? 0
                : (targetCount + channelCount - 1) / channelCount;
        }

        private static bool IsSystemCompressionParameter(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return false;
            }

            return name.StartsWith(PoiLightChangerSyncCompressionPlan.SystemPrefix + "/", StringComparison.Ordinal);
        }

        private static void EnsureControllerParameters(
            AnimatorController controller,
            PoiLightChangerSyncCompressionPlan plan,
            string immediateTransmitTriggerParameterName)
        {
            AddControllerParameterIfMissing(controller, "IsLocal", AnimatorControllerParameterType.Bool);
            AddControllerParameterIfMissing(controller, PoiLightChangerSyncCompressionPlan.IndexParameterName, AnimatorControllerParameterType.Int);
            if (!string.IsNullOrWhiteSpace(immediateTransmitTriggerParameterName))
            {
                AddControllerParameterIfMissing(controller, immediateTransmitTriggerParameterName, AnimatorControllerParameterType.Bool);
            }

            for (var index = 0; index < plan.FloatChannelCount; index++)
            {
                AddControllerParameterIfMissing(controller, PoiLightChangerSyncCompressionPlan.GetFloatChannelName(index), AnimatorControllerParameterType.Float);
            }

            for (var index = 0; index < plan.IntChannelCount; index++)
            {
                AddControllerParameterIfMissing(controller, PoiLightChangerSyncCompressionPlan.GetIntChannelName(index), AnimatorControllerParameterType.Int);
            }

            foreach (var parameter in plan.TargetParameters)
            {
                AddControllerParameterIfMissing(
                    controller,
                    parameter.Name,
                    parameter.Kind switch
                    {
                        PoiLightChangerCompressedValueKind.Int => AnimatorControllerParameterType.Int,
                        PoiLightChangerCompressedValueKind.Bool => AnimatorControllerParameterType.Bool,
                        _ => AnimatorControllerParameterType.Float,
                    });
            }
        }

        private static void BuildReceiveBranch(
            AnimatorStateMachine stateMachine,
            AnimatorState rootIdle,
            Motion idleMotion,
            Motion batchMotion,
            IReadOnlyList<PoiLightChangerCompressionBatch> batches)
        {
            var receiveGate = stateMachine.AddState("ReceiveGate", new Vector3(-320f, 120f));
            receiveGate.motion = idleMotion;
            receiveGate.writeDefaultValues = true;

            var enterReceive = rootIdle.AddTransition(receiveGate);
            enterReceive.hasExitTime = false;
            enterReceive.duration = 0f;
            enterReceive.AddCondition(AnimatorConditionMode.IfNot, 0f, "IsLocal");

            for (var index = 0; index < batches.Count; index++)
            {
                var batch = batches[index];
                var applyState = stateMachine.AddState(
                    $"ReceiveFrame_{batch.BatchIndex}",
                    new Vector3(-320f, 220f + (index * 90f)));
                applyState.motion = batchMotion;
                applyState.writeDefaultValues = true;

                var driver = applyState.AddStateMachineBehaviour<VRCAvatarParameterDriver>();
                driver.parameters = batch.Entries
                    .Select(entry => new VRC_AvatarParameterDriver.Parameter
                    {
                        type = VRC_AvatarParameterDriver.ChangeType.Copy,
                        source = entry.TransportParameterName,
                        name = entry.Parameter.Name,
                    })
                    .ToList();

                var jump = receiveGate.AddTransition(applyState);
                jump.hasExitTime = false;
                jump.duration = 0f;
                jump.AddCondition(AnimatorConditionMode.Equals, batch.BatchIndex, PoiLightChangerSyncCompressionPlan.IndexParameterName);

                var back = applyState.AddTransition(receiveGate);
                back.hasExitTime = false;
                back.duration = 0f;
                back.AddCondition(AnimatorConditionMode.NotEqual, batch.BatchIndex, PoiLightChangerSyncCompressionPlan.IndexParameterName);

                var replay = applyState.AddTransition(applyState);
                replay.hasExitTime = true;
                replay.exitTime = 1f;
                replay.duration = 0f;
                replay.AddCondition(AnimatorConditionMode.Equals, batch.BatchIndex, PoiLightChangerSyncCompressionPlan.IndexParameterName);
            }
        }

        private static void BuildTransmitBranch(
            AnimatorStateMachine stateMachine,
            AnimatorState rootIdle,
            Motion sweepMotion,
            Motion batchMotion,
            IReadOnlyList<PoiLightChangerCompressionBatch> batches,
            string immediateTransmitTriggerParameterName)
        {
            var transmitWait = stateMachine.AddState("TransmitWait", new Vector3(320f, 120f));
            transmitWait.motion = sweepMotion;
            transmitWait.writeDefaultValues = true;

            var enterTransmit = rootIdle.AddTransition(transmitWait);
            enterTransmit.hasExitTime = false;
            enterTransmit.duration = 0f;
            enterTransmit.AddCondition(AnimatorConditionMode.If, 0f, "IsLocal");
            if (!string.IsNullOrWhiteSpace(immediateTransmitTriggerParameterName))
            {
                enterTransmit.AddCondition(AnimatorConditionMode.IfNot, 0f, immediateTransmitTriggerParameterName);
            }

            if (batches.Count == 0)
            {
                return;
            }

            var batchStates = new List<AnimatorState>(batches.Count);
            for (var index = 0; index < batches.Count; index++)
            {
                var batch = batches[index];
                var syncState = stateMachine.AddState(
                    $"TransmitFrame_{batch.BatchIndex}",
                    new Vector3(320f, 220f + (index * 90f)));
                syncState.motion = batchMotion;
                syncState.writeDefaultValues = true;

                var driver = syncState.AddStateMachineBehaviour<VRCAvatarParameterDriver>();
                driver.localOnly = true;

                var commands = batch.Entries
                    .Select(entry => new VRC_AvatarParameterDriver.Parameter
                    {
                        type = VRC_AvatarParameterDriver.ChangeType.Copy,
                        source = entry.Parameter.Name,
                        name = entry.TransportParameterName,
                    })
                    .ToList();
                commands.Add(new VRC_AvatarParameterDriver.Parameter
                {
                    type = VRC_AvatarParameterDriver.ChangeType.Set,
                    name = PoiLightChangerSyncCompressionPlan.IndexParameterName,
                    value = batch.BatchIndex,
                });
                if (index == 0 && !string.IsNullOrWhiteSpace(immediateTransmitTriggerParameterName))
                {
                    commands.Add(new VRC_AvatarParameterDriver.Parameter
                    {
                        type = VRC_AvatarParameterDriver.ChangeType.Set,
                        name = immediateTransmitTriggerParameterName,
                        value = 0f,
                    });
                }

                driver.parameters = commands;
                batchStates.Add(syncState);
            }

            var firstJump = transmitWait.AddTransition(batchStates[0]);
            firstJump.hasExitTime = true;
            firstJump.exitTime = 1f;
            firstJump.duration = 0f;
            firstJump.AddCondition(AnimatorConditionMode.If, 0f, "IsLocal");
            if (!string.IsNullOrWhiteSpace(immediateTransmitTriggerParameterName))
            {
                firstJump.AddCondition(AnimatorConditionMode.IfNot, 0f, immediateTransmitTriggerParameterName);
            }

            if (!string.IsNullOrWhiteSpace(immediateTransmitTriggerParameterName))
            {
                AddImmediateTransmitTransition(rootIdle, batchStates[0], immediateTransmitTriggerParameterName);
                AddImmediateTransmitTransition(transmitWait, batchStates[0], immediateTransmitTriggerParameterName);

                for (var index = 0; index < batchStates.Count; index++)
                {
                    AddImmediateTransmitTransition(batchStates[index], batchStates[0], immediateTransmitTriggerParameterName);
                }
            }

            for (var index = 0; index < batchStates.Count - 1; index++)
            {
                var next = batchStates[index].AddTransition(batchStates[index + 1]);
                next.hasExitTime = true;
                next.exitTime = 1f;
                next.duration = 0f;
                next.AddCondition(AnimatorConditionMode.If, 0f, "IsLocal");
                if (!string.IsNullOrWhiteSpace(immediateTransmitTriggerParameterName))
                {
                    next.AddCondition(AnimatorConditionMode.IfNot, 0f, immediateTransmitTriggerParameterName);
                }
            }

            var backToIdle = batchStates[^1].AddTransition(transmitWait);
            backToIdle.hasExitTime = true;
            backToIdle.exitTime = 1f;
            backToIdle.duration = 0f;
            backToIdle.AddCondition(AnimatorConditionMode.If, 0f, "IsLocal");
            if (!string.IsNullOrWhiteSpace(immediateTransmitTriggerParameterName))
            {
                backToIdle.AddCondition(AnimatorConditionMode.IfNot, 0f, immediateTransmitTriggerParameterName);
            }
        }

        private static void AddImmediateTransmitTransition(
            AnimatorState sourceState,
            AnimatorState destinationState,
            string immediateTransmitTriggerParameterName)
        {
            if (sourceState == null || destinationState == null || string.IsNullOrWhiteSpace(immediateTransmitTriggerParameterName))
            {
                return;
            }

            var transition = sourceState.AddTransition(destinationState);
            transition.hasExitTime = false;
            transition.duration = 0f;
            transition.AddCondition(AnimatorConditionMode.If, 0f, "IsLocal");
            transition.AddCondition(AnimatorConditionMode.If, 0f, immediateTransmitTriggerParameterName);
        }

        private static AnimationClip CreateTimingClip(AnimatorController controller, string clipName, float durationSeconds)
        {
            var clip = new AnimationClip
            {
                name = clipName,
                hideFlags = HideFlags.HideInHierarchy,
            };

            clip.SetCurve(
                "__PoiLightChanger_CompressionPulse__",
                typeof(GameObject),
                "m_IsActive",
                AnimationCurve.Constant(0f, durationSeconds, 0f));

            AssetDatabase.AddObjectToAsset(clip, controller);
            return clip;
        }

        private static void AddControllerParameterIfMissing(
            AnimatorController controller,
            string parameterName,
            AnimatorControllerParameterType parameterType)
        {
            if (controller.parameters.Any(parameter => parameter.name == parameterName))
            {
                return;
            }

            controller.AddParameter(parameterName, parameterType);
        }

        private static void RemoveExistingLayer(AnimatorController controller)
        {
            if (controller.layers.All(layer => layer.name != PoiLightChangerSyncCompressionPlan.LayerName))
            {
                return;
            }

            controller.layers = controller.layers
                .Where(layer => layer.name != PoiLightChangerSyncCompressionPlan.LayerName)
                .ToArray();
        }
    }
}
