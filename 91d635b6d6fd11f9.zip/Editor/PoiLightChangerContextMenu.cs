using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

namespace io.github.m8pix.poi_light_changer
{
    [InitializeOnLoad]
    internal static class PoiLightChangerContextMenu
    {
        private const string MenuRoot = "GameObject/" + PoiLightChangerPlugin.Title + "/";
        private const string SetupMenuPath = MenuRoot + "Setup";
        private const string HierarchySetupPath = PoiLightChangerPlugin.Title + "/Setup";
        private const int MenuPriority = -100;
        private const string DefaultPrefabGuid = "0ba26ab347fd94ad09051a2630a9d811";

        static PoiLightChangerContextMenu()
        {
            SceneHierarchyHooks.addItemsToGameObjectContextMenu += AddItemsToGameObjectContextMenu;
        }

        [MenuItem(SetupMenuPath, false, MenuPriority)]
        private static void SetupMenu()
        {
            Setup(null);
        }

        [MenuItem(SetupMenuPath, true, MenuPriority)]
        private static bool SetupMenuValidate()
        {
            return CollectTargetAvatarRoots(null).Count > 0;
        }

        private static void AddItemsToGameObjectContextMenu(GenericMenu menu, GameObject contextObject)
        {
            if (menu == null || CollectTargetAvatarRoots(contextObject).Count == 0)
            {
                return;
            }

            menu.AddItem(new GUIContent(HierarchySetupPath), false, () => Setup(contextObject));
        }

        private static void Setup(GameObject contextObject)
        {
            var avatarRoots = CollectTargetAvatarRoots(contextObject);
            if (avatarRoots.Count == 0)
            {
                return;
            }

            var results = new List<Object>(avatarRoots.Count);
            foreach (var avatarRoot in avatarRoots)
            {
                if (avatarRoot.GetComponentInChildren<PoiLightChangerComponent>(true) is { } existingComponent)
                {
                    results.Add(existingComponent.gameObject);
                    EditorGUIUtility.PingObject(existingComponent.gameObject);
                    continue;
                }

                var installedObject = Install(avatarRoot);
                if (installedObject == null)
                {
                    continue;
                }

                results.Add(installedObject);
                EditorGUIUtility.PingObject(installedObject);
            }

            if (results.Count > 0)
            {
                Selection.objects = results.ToArray();
            }
        }

        private static List<GameObject> CollectTargetAvatarRoots(GameObject contextObject)
        {
            var avatarRoots = new List<GameObject>();
            var seen = new HashSet<GameObject>();

            AddAvatarRoot(contextObject, avatarRoots, seen);
            foreach (var selectedObject in Selection.gameObjects)
            {
                AddAvatarRoot(selectedObject, avatarRoots, seen);
            }

            return avatarRoots;
        }

        private static void AddAvatarRoot(GameObject candidate, ICollection<GameObject> avatarRoots, ISet<GameObject> seen)
        {
            if (!TryGetAvatarRoot(candidate, out var avatarRoot) || !seen.Add(avatarRoot))
            {
                return;
            }

            avatarRoots.Add(avatarRoot);
        }

        private static bool TryGetAvatarRoot(GameObject candidate, out GameObject avatarRoot)
        {
            avatarRoot = null;
            if (candidate == null || !candidate.TryGetComponent<VRCAvatarDescriptor>(out _))
            {
                return false;
            }

            avatarRoot = candidate;
            return true;
        }

        private static GameObject Install(GameObject avatarRoot)
        {
            var defaultPrefab = LoadDefaultPrefab();
            GameObject installedObject;
            if (defaultPrefab != null)
            {
                installedObject = PrefabUtility.InstantiatePrefab(defaultPrefab, avatarRoot.transform) as GameObject;
            }
            else
            {
                installedObject = new GameObject(PoiLightChangerPlugin.Title);
                installedObject.transform.SetParent(avatarRoot.transform, false);
                installedObject.AddComponent<PoiLightChangerComponent>();
            }

            if (installedObject == null)
            {
                return null;
            }

            installedObject.name = PoiLightChangerPlugin.Title;
            if (!installedObject.TryGetComponent<PoiLightChangerComponent>(out var component))
            {
                component = installedObject.AddComponent<PoiLightChangerComponent>();
            }

            component.EnsureInitialized();
            Undo.RegisterCreatedObjectUndo(installedObject, $"Add {PoiLightChangerPlugin.Title}");
            EditorUtility.SetDirty(component);
            return installedObject;
        }

        private static GameObject LoadDefaultPrefab()
        {
            var path = AssetDatabase.GUIDToAssetPath(DefaultPrefabGuid);
            if (string.IsNullOrWhiteSpace(path))
            {
                return null;
            }

            return AssetDatabase.LoadAssetAtPath<GameObject>(path);
        }
    }
}
