using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    internal readonly struct PoiLightChangerBacklightColorModel
    {
        public PoiLightChangerBacklightColorModel(
            Color normalizedColor,
            float normalizedIntensity,
            float intensityMax,
            Color resolvedColor)
        {
            NormalizedColor = normalizedColor;
            NormalizedIntensity = normalizedIntensity;
            IntensityMax = intensityMax;
            ResolvedColor = resolvedColor;
        }

        public Color NormalizedColor { get; }

        public float NormalizedIntensity { get; }

        public float IntensityMax { get; }

        public Color ResolvedColor { get; }

        public static PoiLightChangerBacklightColorModel FromControl(PoiLightChangerColorControlValue colorControl)
        {
            var range = colorControl?.Range ?? new Vector2(0f, 1f);
            var color = PoiLightChangerControlBindingUtility.ClampBacklightColorToRange(colorControl?.Value ?? Color.white, range);
            var rawMaxComponent = Mathf.Max(color.r, Mathf.Max(color.g, color.b));
            var normalizedBase = Mathf.Max(rawMaxComponent, 1f);
            var intensityMax = Mathf.Max(0f, range.y);
            var pickerIntensity = PoiLightChangerControlBindingUtility.ResolveBacklightPickerIntensity(rawMaxComponent);
            var normalizedIntensity = Mathf.Approximately(intensityMax, 0f)
                ? 0f
                : Mathf.Clamp01(pickerIntensity / intensityMax);
            var resolvedMultiplier = PoiLightChangerControlBindingUtility.ResolveBacklightIntensityMultiplier(
                normalizedIntensity,
                intensityMax);
            var normalizedColor = normalizedBase > 0f
                ? new Color(color.r / normalizedBase, color.g / normalizedBase, color.b / normalizedBase, color.a)
                : new Color(1f, 1f, 1f, color.a);
            var resolvedColor = new Color(
                normalizedColor.r * resolvedMultiplier,
                normalizedColor.g * resolvedMultiplier,
                normalizedColor.b * resolvedMultiplier,
                color.a);

            return new PoiLightChangerBacklightColorModel(
                normalizedColor,
                normalizedIntensity,
                intensityMax,
                resolvedColor);
        }
    }

    internal sealed class PoiLightChangerImplementedControlBinding
    {
        public PoiLightChangerControlDefinition Definition { get; set; }

        public PoiLightChangerFloatControlValue Control { get; set; }

        public bool SectionEnabled { get; set; } = true;

        public string Label { get; set; }

        public IReadOnlyList<string> AdditionalAnimatedProperties { get; set; }

        public IReadOnlyDictionary<string, float> ConstantProperties { get; set; }

        public string MenuCategory { get; set; }

        public string MenuLabel { get; set; }

        public string MenuCategoryJapanese { get; set; }

        public string MenuCategoryEnglish { get; set; }

        public string MenuLabelJapanese { get; set; }

        public string MenuLabelEnglish { get; set; }

        public string OverrideMenuPath { get; set; }

        public string OverrideDisplayMenuPathJapanese { get; set; }

        public string OverrideDisplayMenuPathEnglish { get; set; }

        public bool IsToggle { get; set; }

        public float? OverrideMinValue { get; set; }

        public float? OverrideMaxValue { get; set; }

        public bool IsAdditiveVectorControl { get; set; }

        public string VectorBasePropertyName { get; set; }

        public int VectorComponentIndex { get; set; }

        public (float Threshold, float ComponentValue)[] AdditiveVectorKeyframes { get; set; }

        public bool IsSecondaryComponent { get; set; }

        public float? MaterialInitialValueOverride { get; set; }

        public string OverrideMaterialPropertyName { get; set; }

        public string OverrideParameterName { get; set; }

        public string OverrideMenuParameterName { get; set; }

        public bool IsBacklightColorIntensityControl { get; set; }

        public float BacklightColorIntensityMax { get; set; }

        public float BacklightColorIntensityNormalizedMin { get; set; }

        public GameObject LinkedToggleObject { get; set; }
    }

    internal static class PoiLightChangerControlBindingUtility
    {
        private static float ResolveBacklightMinColorComponent(Vector2 range)
        {
            var minIntensity = Mathf.Max(0f, range.x);
            return minIntensity <= 0f
                ? 0f
                : Mathf.Pow(2f, minIntensity);
        }

        private static float ResolveBacklightMaxColorComponent(Vector2 range)
        {
            var minIntensity = Mathf.Max(0f, range.x);
            var maxIntensity = Mathf.Max(minIntensity, range.y);
            return maxIntensity <= 0f
                ? 1f
                : Mathf.Pow(2f, maxIntensity);
        }

        public static Color ClampBacklightColorToRange(Color color, Vector2 range)
        {
            var minComponent = ResolveBacklightMinColorComponent(range);
            var maxComponent = Mathf.Max(minComponent, ResolveBacklightMaxColorComponent(range));
            var rawMaxComponent = Mathf.Max(color.r, Mathf.Max(color.g, color.b));

            if (rawMaxComponent > maxComponent && !Mathf.Approximately(rawMaxComponent, 0f))
            {
                var scale = maxComponent / rawMaxComponent;
                color.r *= scale;
                color.g *= scale;
                color.b *= scale;
            }

            color.r = Mathf.Clamp(color.r, minComponent, maxComponent);
            color.g = Mathf.Clamp(color.g, minComponent, maxComponent);
            color.b = Mathf.Clamp(color.b, minComponent, maxComponent);
            return color;
        }

        public static Vector2 GetBacklightNormalizedColorRange(Vector2 range)
        {
            var minComponent = ResolveBacklightMinColorComponent(range);
            var maxComponent = Mathf.Max(minComponent, ResolveBacklightMaxColorComponent(range));
            var normalizedMin = Mathf.Approximately(maxComponent, 0f)
                ? 0f
                : Mathf.Clamp01(minComponent / Mathf.Max(1f, maxComponent));
            return new Vector2(normalizedMin, 1f);
        }

        public static float ResolveBacklightPickerIntensity(float rawMaxComponent)
        {
            if (rawMaxComponent <= 1f)
            {
                return 0f;
            }

            return Mathf.Max(0f, Mathf.Log(rawMaxComponent, 2f));
        }

        public static float ResolveBacklightIntensityMultiplier(float normalizedIntensity, float intensityMax)
        {
            if (intensityMax <= 0f)
            {
                return 1f;
            }

            return Mathf.Pow(2f, Mathf.Clamp01(normalizedIntensity) * intensityMax);
        }

        public static float NormalizeFloatControlValue(PoiLightChangerFloatControlValue control)
        {
            if (control == null)
            {
                return 0f;
            }

            var min = control.Range.x;
            var max = control.Range.y;
            if (Mathf.Approximately(min, max))
            {
                return 0f;
            }

            return Mathf.Clamp01(Mathf.InverseLerp(min, max, control.Value));
        }

        public static float ResolveDefaultValue(IPoiLightChangerControlValue control)
        {
            return control switch
            {
                PoiLightChangerFloatControlValue floatControl => NormalizeFloatControlValue(floatControl),
                PoiLightChangerBoolControlValue boolControl => boolControl.Value ? 1f : 0f,
                PoiLightChangerColorControlValue => 1f,
                _ => 0f,
            };
        }

        public static Dictionary<string, float> ResolveNormalizedColorDefaults(PoiLightChangerColorControlValue colorControl)
        {
            var color = colorControl?.Value ?? Color.white;
            return new Dictionary<string, float>
            {
                ["r"] = Mathf.Clamp01(color.r),
                ["g"] = Mathf.Clamp01(color.g),
                ["b"] = Mathf.Clamp01(color.b),
            };
        }

        public static Dictionary<string, float> ResolveBacklightDefaults(PoiLightChangerColorControlValue colorControl)
        {
            var model = PoiLightChangerBacklightColorModel.FromControl(colorControl);

            return new Dictionary<string, float>
            {
                ["r"] = model.NormalizedColor.r,
                ["g"] = model.NormalizedColor.g,
                ["b"] = model.NormalizedColor.b,
                ["intensity"] = model.NormalizedIntensity,
            };
        }
    }

    internal static class PoiLightChangerControlBindingResolver
    {
        public static PoiLightChangerImplementedControlBinding[] GetImplementedBindings(
            PoiLightChangerComponent component,
            PoiLightChangerLicenseSnapshot licenseSnapshot = null)
        {
            if (component?.Poiyomi == null)
            {
                return Array.Empty<PoiLightChangerImplementedControlBinding>();
            }

            licenseSnapshot ??= PoiLightChangerLicenseService.GetCurrentSnapshot();

            return EnumerateImplementedBindings(component)
                .Select(binding =>
                {
                    if (binding?.Definition == null)
                    {
                        return binding;
                    }

                    binding.SectionEnabled &= PoiLightChangerLicenseFeatureGate.IsSectionAvailable(
                        PoiLightChangerControlRegistry.GetSectionId(binding.Definition),
                        licenseSnapshot);
                    return binding;
                })
                .ToArray();
        }

        public static PoiLightChangerImplementedControlBinding[] GetAnimatedBindings(
            PoiLightChangerComponent component,
            PoiLightChangerLicenseSnapshot licenseSnapshot = null)
        {
            return GetImplementedBindings(component, licenseSnapshot)
                .Where(control => control.SectionEnabled)
                .Where(control => control.Control is { Enable: true, Animation: true })
                .ToArray();
        }

        private static IEnumerable<PoiLightChangerImplementedControlBinding> EnumerateImplementedBindings(PoiLightChangerComponent component)
        {
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.LightingMin, component.Poiyomi.MinBrightness, "Min Brightness");

            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(
                component,
                PoiLightChangerControlId.LightingMax,
                component.Poiyomi.LightingMax,
                "Max Brightness",
                additionalAnimatedProperties: new[]
                {
                    PoiLightChangerPoiyomiShaderConstants.LightingAdditiveLimit,
                },
                constantProperties: new Dictionary<string, float>
                {
                    [PoiLightChangerPoiyomiShaderConstants.LightingCapEnabled] = 1.0f,
                    [PoiLightChangerPoiyomiShaderConstants.LightingAdditiveLimited] = 1.0f,
                });

            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(
                component,
                PoiLightChangerControlId.LightingMonochromatic,
                component.Poiyomi.LightingMonochromatic,
                "Grayscale",
                additionalAnimatedProperties: new[]
                {
                    PoiLightChangerPoiyomiShaderConstants.LightingAdditiveMonochromatic,
                });

            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.PPLightingMultiplier, component.Poiyomi.PPLightingMultiplier, "PP Lighting Multiplier");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.PPLightingAddition, component.Poiyomi.PPLightingAddition, "PP Lighting Addition");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.PPEmissionMultiplier, component.Poiyomi.PPEmissionMultiplier, "PP Emission Multiplier");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.PPFinalColorMultiplier, component.Poiyomi.PPFinalColorMultiplier, "PP Final Color Multiplier");

            foreach (var binding in PoiLightChangerControlBindingFactory.CreateLightDirectionBindings(component))
            {
                yield return binding;
            }

            yield return PoiLightChangerControlBindingFactory.CreateSimpleToggleBinding(component, PoiLightChangerControlId.PPHueSelectOrShift, component.Poiyomi.PPHueSelectOrShift, "PP Hue Select Or Shift");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.PPHue, component.Poiyomi.PPHue, "PP Hue");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.PPContrast, component.Poiyomi.PPContrast, "PP Contrast");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.PPSaturation, component.Poiyomi.PPSaturation, "PP Saturation");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.PPBrightness, component.Poiyomi.PPBrightness, "PP Brightness");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.PPLightness, component.Poiyomi.PPLightness, "PP Lightness");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.PPHDR, component.Poiyomi.PPHDR, "PP HDR");

            yield return PoiLightChangerControlBindingFactory.CreatePseudoToggleBinding(component, PoiLightChangerControlId.BacklightToggle, component.Poiyomi.BacklightToggle, "Backlight Toggle");
            foreach (var binding in PoiLightChangerControlBindingFactory.CreateBacklightHdrColorBindings(component))
            {
                yield return binding;
            }
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.BacklightMainStrength, component.Poiyomi.BacklightMainStrength, "Backlight Main Strength");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(
                component,
                PoiLightChangerControlId.BacklightBorder,
                component.Poiyomi.BacklightBorder,
                "Backlight Border",
                overrideMenuParameterName: PoiLightChangerPseudoToggleUtility.UsesMergedBacklightSync(component)
                    ? PoiLightChangerPseudoToggleUtility.GetStoredValueParameterName(PoiLightChangerControlId.BacklightBorder)
                    : null);
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.BacklightBlur, component.Poiyomi.BacklightBlur, "Backlight Blur");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.BacklightDirectivity, component.Poiyomi.BacklightDirectivity, "Backlight Directivity");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.BacklightViewStrength, component.Poiyomi.BacklightViewStrength, "Backlight View Strength");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleToggleBinding(
                component,
                PoiLightChangerControlId.BacklightReceiveShadow,
                component.Poiyomi.BacklightReceiveShadow,
                "Backlight Receive Shadow",
                overrideMaxValue: 1.0f);
            yield return PoiLightChangerControlBindingFactory.CreateSimpleToggleBinding(
                component,
                PoiLightChangerControlId.BacklightBackfaceMask,
                component.Poiyomi.BacklightBackfaceMask,
                "Backlight Backface Mask",
                overrideMaxValue: 1.0f);

            yield return PoiLightChangerControlBindingFactory.CreatePseudoToggleBinding(
                component,
                PoiLightChangerControlId.ProximityToggle,
                component.Poiyomi.ProximityToggle,
                "Proximity Toggle",
                additionalAnimatedProperties: new[]
                {
                    PoiLightChangerPoiyomiShaderConstants.FxProximityColorMaxDistance,
                });
            foreach (var binding in PoiLightChangerControlBindingFactory.CreateNormalizedColorBindings(
                         component,
                         PoiLightChangerControlId.ProximityColorMinColor,
                         component.Poiyomi.ProximityColorMinColor,
                         "ProximityMinColor",
                         "Proximity Min Color",
                         PoiLightChangerPoiyomiShaderConstants.FxProximityColorMinColorR,
                         PoiLightChangerPoiyomiShaderConstants.FxProximityColorMinColorG,
                         PoiLightChangerPoiyomiShaderConstants.FxProximityColorMinColorB))
            {
                yield return binding;
            }
            foreach (var binding in PoiLightChangerControlBindingFactory.CreateNormalizedColorBindings(
                         component,
                         PoiLightChangerControlId.ProximityColorMaxColor,
                         component.Poiyomi.ProximityColorMaxColor,
                         "ProximityMaxColor",
                         "Proximity Max Color",
                         PoiLightChangerPoiyomiShaderConstants.FxProximityColorMaxColorR,
                         PoiLightChangerPoiyomiShaderConstants.FxProximityColorMaxColorG,
                         PoiLightChangerPoiyomiShaderConstants.FxProximityColorMaxColorB))
            {
                yield return binding;
            }
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.ProximityColorMinDistance, component.Poiyomi.ProximityColorMinDistance, "Proximity Min Distance", overrideMinValue: 0.0f);
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.ProximityColorMaxDistance, component.Poiyomi.ProximityColorMaxDistance, "Proximity Max Distance", overrideMinValue: 0.0f);
            yield return PoiLightChangerControlBindingFactory.CreateSimpleToggleBinding(component, PoiLightChangerControlId.ProximityColorBackface, component.Poiyomi.ProximityColorBackface, "Proximity Backface", overrideMaxValue: 1.0f);

            yield return PoiLightChangerControlBindingFactory.CreatePseudoToggleBinding(component, PoiLightChangerControlId.OutlineToggle, component.Poiyomi.OutlineToggle, "Outline Toggle", overrideMaxValue: 1.0f);
            foreach (var binding in PoiLightChangerControlBindingFactory.CreateNormalizedColorBindings(
                         component,
                         PoiLightChangerControlId.OutlineLineColor,
                         component.Poiyomi.OutlineLineColor,
                         "OutlineLineColor",
                         "Outline Line Color",
                         PoiLightChangerPoiyomiShaderConstants.LineColorR,
                         PoiLightChangerPoiyomiShaderConstants.LineColorG,
                         PoiLightChangerPoiyomiShaderConstants.LineColorB))
            {
                yield return binding;
            }
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(
                component,
                PoiLightChangerControlId.OutlineLineWidth,
                component.Poiyomi.OutlineLineWidth,
                "Outline Line Width",
                overrideMinValue: 0.0f,
                overrideMenuParameterName: PoiLightChangerPseudoToggleUtility.UsesMergedOutlineSync(component)
                    ? PoiLightChangerPseudoToggleUtility.GetStoredValueParameterName(PoiLightChangerControlId.OutlineLineWidth)
                    : null);
            yield return PoiLightChangerControlBindingFactory.CreateSimpleToggleBinding(component, PoiLightChangerControlId.OutlineFixedSize, component.Poiyomi.OutlineFixedSize, "Outline Fixed Size", overrideMaxValue: 1.0f);
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.OutlineFixWidth, component.Poiyomi.OutlineFixWidth, "Outline Fix Width");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.OutlineEmission, component.Poiyomi.OutlineEmission, "Outline Emission", overrideMinValue: 0.0f);
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.OutlineOffsetZ, component.Poiyomi.OutlineOffsetZ, "Outline Offset Z");

            yield return PoiLightChangerControlBindingFactory.CreateLinkedToggleBinding(
                component,
                PoiLightChangerControlId.SSAOAnimationToggle,
                component.Poiyomi.SSAOAnimationToggle,
                "SSAO Toggle",
                component.Poiyomi.SSAOLinkedObject);
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.SSAOIntensity, component.Poiyomi.SSAOIntensity, "SSAO Intensity");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.SSAORadius, component.Poiyomi.SSAORadius, "SSAO Radius");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.SSAOQuality, component.Poiyomi.SSAOQuality, "SSAO Quality");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.SSAOCenterImportance, component.Poiyomi.SSAOCenterImportance, "SSAO Center Importance");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.SSAOBias, component.Poiyomi.SSAOBias, "SSAO Depth Bias");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.SSAOCone, component.Poiyomi.SSAOCone, "SSAO Cone Bias");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.SSAORandomScale, component.Poiyomi.SSAORandomScale, "SSAO Random Jitter");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleToggleBinding(component, PoiLightChangerControlId.SSAOUseNormals, component.Poiyomi.SSAOUseNormals, "SSAO Use Normals");

            yield return PoiLightChangerControlBindingFactory.CreateSimpleToggleBinding(component, PoiLightChangerControlId.ContactShadowAnimationToggle, component.Poiyomi.ContactShadowAnimationToggle, "Contact Shadows Toggle");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.ContactShadowIntensity, component.Poiyomi.ContactShadowIntensity, "Contact Shadows Intensity");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.ContactShadowMaxDistance, component.Poiyomi.ContactShadowMaxDistance, "Contact Shadows Max Distance");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.ContactShadowQuality, component.Poiyomi.ContactShadowQuality, "Contact Shadows Quality");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.ContactShadowThickness, component.Poiyomi.ContactShadowThickness, "Contact Shadows Thickness");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.ContactShadowBias, component.Poiyomi.ContactShadowBias, "Contact Shadows Depth Bias");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.ContactShadowNormalBias, component.Poiyomi.ContactShadowNormalBias, "Contact Shadows Normal Rejection");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.ContactShadowHideInLight, component.Poiyomi.ContactShadowHideInLight, "Contact Shadows Hide In Light");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.ContactShadowNoiseScale, component.Poiyomi.ContactShadowNoiseScale, "Contact Shadows Dither Noise");
            yield return PoiLightChangerControlBindingFactory.CreateSimpleScalarBinding(component, PoiLightChangerControlId.ContactShadowRejectionDepth, component.Poiyomi.ContactShadowRejectionDepth, "Contact Shadows Rejection Depth");
        }
    }
}
