using System.Collections.Generic;
using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    public enum PoiLightChangerMaterialFeatureMode
    {
        Inherit = 0,
        ForceEnable = 1,
    }

    public enum PoiLightChangerLightDirectionToggleMode
    {
        World = 2,
        Local = 1,
    }

    [System.Serializable]
    public sealed class PoiLightChangerPoiyomiSettings : IPoiLightChangerSettingsNode
    {
        public bool EnableLightingControl = true;

        public bool EnableLightDirectionControl = true;

        public bool EnableColorControl = true;

        public PoiLightChangerFloatControlValue MinBrightness = new(0.05f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue LightingMax = new(1.0f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue LightingMonochromatic = new(0.0f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue PPLightingMultiplier = new(1.0f, 0.0f, 2.0f);
        public PoiLightChangerFloatControlValue PPLightingAddition = new(0.0f, -1.0f, 1.0f) { Enable = false };
        public PoiLightChangerFloatControlValue PPEmissionMultiplier = new(1.0f, 0.0f, 2.0f);
        public PoiLightChangerFloatControlValue PPFinalColorMultiplier = new(1.0f, 0.0f, 2.0f) { Enable = false };
        public PoiLightChangerLightDirectionToggleMode LightDirectionToggleMode = PoiLightChangerLightDirectionToggleMode.World;
        public PoiLightChangerFloatControlValue LightDirectionToggle = new(0.0f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue LightDirectionX = new(0.5f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue LightDirectionY = new(0.5f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue PPHueSelectOrShift = new(1.0f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue PPHue = new(0.0f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue PPContrast = new(1.0f, 0.0f, 2.0f);
        public PoiLightChangerFloatControlValue PPSaturation = new(1.0f, 0.0f, 2.0f);
        public PoiLightChangerFloatControlValue PPBrightness = new(1.0f, 0.0f, 2.0f);
        public PoiLightChangerFloatControlValue PPLightness = new(0.0f, -1.0f, 1.0f);
        public PoiLightChangerFloatControlValue PPHDR = new(0.0f, -1.0f, 1.0f);

        public bool EnableSSAOControl = false;
        public PoiLightChangerMaterialFeatureMode SSAOFeatureMode = PoiLightChangerMaterialFeatureMode.Inherit;
        public PoiLightChangerFloatControlValue SSAOAnimationToggle = new(1.0f, 0.0f, 1.0f);
        public GameObject SSAOLinkedObject;
        public PoiLightChangerFloatControlValue SSAOIntensity = new(1.0f, 0.0f, 5.0f) { Enable = false };
        public PoiLightChangerFloatControlValue SSAORadius = new(0.002f, 0.0001f, 0.02f) { Enable = false };
        public PoiLightChangerFloatControlValue SSAOQuality = new(2.4f, 1.0f, 10.0f);
        public PoiLightChangerFloatControlValue SSAOCenterImportance = new(1.0f, 0.0f, 1.0f) { Enable = false };
        public PoiLightChangerFloatControlValue SSAOBias = new(0.003f, 0.0f, 0.2f) { Enable = false };
        public PoiLightChangerFloatControlValue SSAOCone = new(0.0f, 0.0f, 1.0f) { Enable = false };
        public PoiLightChangerFloatControlValue SSAORandomScale = new(0.0f, 0.0f, 1.0f) { Enable = false };
        public PoiLightChangerFloatControlValue SSAOUseNormals = new(0.0f, 0.0f, 1.0f) { Enable = false };

        public bool EnableContactShadowControl = false;
        public PoiLightChangerMaterialFeatureMode ContactShadowFeatureMode = PoiLightChangerMaterialFeatureMode.Inherit;
        public PoiLightChangerFloatControlValue ContactShadowAnimationToggle = new(1.0f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue ContactShadowIntensity = new(0.5f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue ContactShadowMaxDistance = new(0.03f, 0.001f, 0.2f);
        public PoiLightChangerFloatControlValue ContactShadowQuality = new(4.0f, 1.0f, 10.0f);
        public PoiLightChangerFloatControlValue ContactShadowThickness = new(0.005f, 0.0001f, 0.05f);
        public PoiLightChangerFloatControlValue ContactShadowBias = new(0.001f, 0.0f, 0.05f);
        public PoiLightChangerFloatControlValue ContactShadowNormalBias = new(0.3f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue ContactShadowHideInLight = new(0.0f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue ContactShadowNoiseScale = new(1.0f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue ContactShadowRejectionDepth = new(0.1f, 0.001f, 1.0f);

        public bool EnableProximityControl = true;
        public PoiLightChangerMaterialFeatureMode ProximityFeatureMode = PoiLightChangerMaterialFeatureMode.ForceEnable;
        public PoiLightChangerFloatControlValue ProximityToggle = new(1.0f, 0.0f, 1.0f) { Animation = false };
        public PoiLightChangerColorControlValue ProximityColorMinColor = new(Color.black);
        public PoiLightChangerColorControlValue ProximityColorMaxColor = new(Color.white);
        public PoiLightChangerFloatControlValue ProximityColorMinDistance = new(0.0f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue ProximityColorMaxDistance = new(0.18f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue ProximityColorBackface = new(0.0f, 0.0f, 1.0f) { Animation = false };

        public bool EnableOutlineControl = false;
        public PoiLightChangerMaterialFeatureMode OutlineFeatureMode = PoiLightChangerMaterialFeatureMode.Inherit;
        public bool RemoveOutlineTexture = false;
        public PoiLightChangerFloatControlValue OutlineToggle = new(0.0f, 0.0f, 1.0f);
        public PoiLightChangerColorControlValue OutlineLineColor = new(Color.black);
        public PoiLightChangerFloatControlValue OutlineLineWidth = new(0.0f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue OutlineFixedSize = new(0.0f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue OutlineFixWidth = new(0.5f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue OutlineEmission = new(0.0f, 0.0f, 5.0f);
        public PoiLightChangerFloatControlValue OutlineOffsetZ = new(0.0f, 0.0f, 25.0f);

        public bool EnableBacklightControl = true;
        public PoiLightChangerMaterialFeatureMode BacklightFeatureMode = PoiLightChangerMaterialFeatureMode.ForceEnable;

        public PoiLightChangerColorControlValue BacklightColor = new(new Color(1.0f, 1.0f, 1.0f, 0.0f));
        public PoiLightChangerFloatControlValue BacklightToggle = new(0.0f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue BacklightMainStrength = new(0.0f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue BacklightBorder = new(0.35f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue BacklightBlur = new(0.05f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue BacklightDirectivity = new(5.0f, 0.0f, 10.0f);
        public PoiLightChangerFloatControlValue BacklightViewStrength = new(1.0f, 0.0f, 1.0f);
        public PoiLightChangerFloatControlValue BacklightReceiveShadow = new(1.0f, 0.0f, 1.0f) { Animation = false };
        public PoiLightChangerFloatControlValue BacklightBackfaceMask = new(1.0f, 0.0f, 1.0f) { Animation = false };

        public bool Normalize()
        {
            var changed = false;

            changed |= NormalizeLightDirectionToggleMode(ref LightDirectionToggleMode);
            changed |= NormalizeFeatureMode(ref SSAOFeatureMode);
            changed |= NormalizeFeatureMode(ref ContactShadowFeatureMode);
            changed |= NormalizeFeatureMode(ref ProximityFeatureMode);
            changed |= NormalizeFeatureMode(ref OutlineFeatureMode);
            changed |= NormalizeFeatureMode(ref BacklightFeatureMode);

            return changed;
        }

        IEnumerable<IPoiLightChangerSettingsNode> IPoiLightChangerSettingsNode.Children
        {
            get
            {
                yield break;
            }
        }

        private static bool NormalizeFeatureMode(ref PoiLightChangerMaterialFeatureMode value)
        {
            if (value != PoiLightChangerMaterialFeatureMode.Inherit &&
                value != PoiLightChangerMaterialFeatureMode.ForceEnable)
            {
                value = PoiLightChangerMaterialFeatureMode.Inherit;
                return true;
            }

            return false;
        }

        private static bool NormalizeLightDirectionToggleMode(ref PoiLightChangerLightDirectionToggleMode value)
        {
            if (value != PoiLightChangerLightDirectionToggleMode.World &&
                value != PoiLightChangerLightDirectionToggleMode.Local)
            {
                value = PoiLightChangerLightDirectionToggleMode.World;
                return true;
            }

            return false;
        }
    }
}
