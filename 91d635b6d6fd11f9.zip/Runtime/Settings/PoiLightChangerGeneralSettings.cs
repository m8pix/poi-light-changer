using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    [System.Serializable]
    public sealed class PoiLightChangerGeneralSettings : IPoiLightChangerSettingsNode
    {
        public const string DefaultParameterPrefix = "PLC";

        public PoiLightChangerWriteDefaultsMode WriteDefaults = PoiLightChangerWriteDefaultsMode.MatchAvatar;
        public bool AddResetButton = true;
        public bool AutoAddAnimated = true;
        public bool ExcludeParticleSystem = false;
    }

    public enum PoiLightChangerWriteDefaultsMode
    {
        [InspectorName("アバターに合わせる")]
        MatchAvatar,
        [InspectorName("有効")]
        ForceOn,
        [InspectorName("無効")]
        ForceOff,
    }
}
