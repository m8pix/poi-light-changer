namespace io.github.m8pix.poi_light_changer
{
    internal static class PoiLightChangerLicenseFeatureGate
    {
        public static bool IsFeatureAvailable(PoiLightChangerLicensedFeatureId featureId, PoiLightChangerLicenseSnapshot snapshot)
        {
            return featureId switch
            {
                PoiLightChangerLicensedFeatureId.Lighting => true,
                PoiLightChangerLicensedFeatureId.LightDirection => true,
                _ => snapshot?.IsLicensed ?? false,
            };
        }

        public static bool IsSectionAvailable(PoiLightChangerControlSectionId sectionId, PoiLightChangerLicenseSnapshot snapshot)
        {
            return IsFeatureAvailable(MapSection(sectionId), snapshot);
        }

        public static PoiLightChangerLicensedFeatureId MapSection(PoiLightChangerControlSectionId sectionId)
        {
            return sectionId switch
            {
                PoiLightChangerControlSectionId.Lighting => PoiLightChangerLicensedFeatureId.Lighting,
                PoiLightChangerControlSectionId.LightDirection => PoiLightChangerLicensedFeatureId.LightDirection,
                PoiLightChangerControlSectionId.Color => PoiLightChangerLicensedFeatureId.Color,
                PoiLightChangerControlSectionId.SSAO => PoiLightChangerLicensedFeatureId.SSAO,
                PoiLightChangerControlSectionId.ContactShadow => PoiLightChangerLicensedFeatureId.ContactShadow,
                PoiLightChangerControlSectionId.Squish => PoiLightChangerLicensedFeatureId.Squish,
                PoiLightChangerControlSectionId.Proximity => PoiLightChangerLicensedFeatureId.Proximity,
                PoiLightChangerControlSectionId.Outline => PoiLightChangerLicensedFeatureId.Outline,
                PoiLightChangerControlSectionId.Backlight => PoiLightChangerLicensedFeatureId.Backlight,
                _ => PoiLightChangerLicensedFeatureId.MaterialOverrides,
            };
        }
    }
}
