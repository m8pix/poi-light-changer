using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    [CustomEditor(typeof(PoiLightChangerComponent))]
    internal sealed class PoiLightChangerComponentEditor : Editor
    {
        static PoiLightChangerComponentEditor()
        {
            EditorApplication.projectChanged += InvalidateProjectCache;
        }

        private readonly struct PoiLikeSectionState
        {
            public PoiLikeSectionState(bool expanded)
            {
                Expanded = expanded;
            }

            public bool Expanded { get; }
        }

        private readonly struct PoiLikeHeaderState
        {
            public PoiLikeHeaderState(bool expanded)
            {
                Expanded = expanded;
            }

            public bool Expanded { get; }
        }

        private readonly struct PoiyomiSectionRestrictionState
        {
            public PoiyomiSectionRestrictionState(bool disableSsao, bool disableContactShadow, bool disableSquish, string helpBoxMessage)
            {
                DisableSsao = disableSsao;
                DisableContactShadow = disableContactShadow;
                DisableSquish = disableSquish;
                HelpBoxMessage = helpBoxMessage ?? string.Empty;
            }

            public bool DisableSsao { get; }

            public bool DisableContactShadow { get; }

            public bool DisableSquish { get; }

            public string HelpBoxMessage { get; }

            public bool HasHelpBox => !string.IsNullOrWhiteSpace(HelpBoxMessage);
        }

        private SerializedProperty generalProperty;
        private SerializedProperty menuProperty;
        private SerializedProperty syncProperty;
        private SerializedProperty targetProperty;
        private SerializedProperty poiyomiProperty;
        private SerializedProperty bakeProperty;
        private SerializedProperty overridesProperty;

        private const string KeyGeneral  = "PoiLightChanger.Foldout.General";
        private const string KeyTarget   = "PoiLightChanger.Foldout.Target";
        private const string KeyOverrides = "PoiLightChanger.Foldout.Overrides";
        private const string KeyLighting = "PoiLightChanger.Foldout.Lighting";
        private const string KeyLightDirection = "PoiLightChanger.Foldout.LightDirection";
        private const string KeyColor = "PoiLightChanger.Foldout.Color";
        private const string KeySSAO = "PoiLightChanger.Foldout.SSAO";
        private const string KeyContactShadow = "PoiLightChanger.Foldout.ContactShadow";
        private const string KeySquish = "PoiLightChanger.Foldout.Squish";
        private const string KeyProximity = "PoiLightChanger.Foldout.Proximity";
        private const string KeyOutline = "PoiLightChanger.Foldout.Outline";
        private const string KeyBacklight = "PoiLightChanger.Foldout.Backlight";
        private const string KeyBake     = "PoiLightChanger.Foldout.Bake";
        private const string KeyParam    = "PoiLightChanger.Foldout.Param";
        private const string KeyPreset   = "PoiLightChanger.Foldout.Preset";
        private const string KeyLicense  = "PoiLightChanger.Foldout.License";
        private const string FoldoutDefaultsVersionKey = "PoiLightChanger.Foldout.DefaultsVersion";
        private const int FoldoutDefaultsVersion = 5;
        private const bool DefaultFoldoutExpanded = false;
        private const float FloatStep    = 0.005f;
        private const float MinMaxSliderThumbPadding = 6f;
        private const float GroupSpacing = 8f;
        private const float PopupFieldWidth = 180f;
        private const float PopupFieldGap = 4f;
        private const float TitleLanguagePopupWidth = 96f;
        private const float TitleRowHeight = 35f;
        private const float SectionHelpBoxIndent = 15f;

        private static bool _defaultsInitialized;

        private static string _packageVersion;
        private PoiLightChangerInspectorLanguageMode _activeLanguageMode = PoiLightChangerInspectorLanguageMode.Japanese;
        private static GUIStyle _poiyomiTitleStyle;
        private static GUIStyle _versionLabelStyle;
        private static GUIStyle _subsectionHeaderStyle;
        private static GUIStyle _contextMenuIconStyle;
        private const string PoiyomiDepthGetPrefabGuid = "23c61f8f4d0a87243a36c937bd3e1393";
        private string _presetNameDraft = string.Empty;
        private string _licenseCodeDraft = string.Empty;
        private string _pendingPolicyRefreshLicenseCode = string.Empty;
        private int _selectedPresetIndex;
        private IReadOnlyList<PoiLightChangerDiagnosticEntry> _activeDiagnostics = Array.Empty<PoiLightChangerDiagnosticEntry>();
        private PoiLightChangerLicenseSnapshot _licenseSnapshot = new();
        private PoiLightChangerPolicyFetchOperation _pendingPolicyRefreshOperation;
        private bool _isPolicyRefreshInProgress;
        private static string PackageVersion => _packageVersion ??= ResolvePackageVersion();
        private string ResetLabel => Tr("リセット", "Reset");
        private string CopySettingsLabel => Tr("設定値をコピー", "Copy Settings");
        private string PasteSettingsLabel => Tr("設定値を貼り付け", "Paste Settings");
        private static GUIStyle PoiyomiTitleStyle
        {
            get
            {
                if (_poiyomiTitleStyle == null)
                {
                    _poiyomiTitleStyle = new GUIStyle(GUI.skin.label)
                    {
                        fontSize = 17,
                        fontStyle = FontStyle.Bold,
                        alignment = TextAnchor.MiddleCenter,
                    };
                }

                return _poiyomiTitleStyle;
            }
        }

        private static GUIStyle VersionLabelStyle
        {
            get
            {
                if (_versionLabelStyle == null)
                {
                    _versionLabelStyle = new GUIStyle(EditorStyles.label)
                    {
                        fontSize = 11,
                        alignment = TextAnchor.LowerRight,
                    };
                    _versionLabelStyle.normal.textColor = new Color(1f, 1f, 1f, 0.75f);
                }

                return _versionLabelStyle;
            }
        }

        private static GUIStyle SubsectionHeaderStyle
        {
            get
            {
                if (_subsectionHeaderStyle == null)
                {
                    _subsectionHeaderStyle = new GUIStyle("ShurikenModuleTitle")
                    {
                        font = EditorStyles.label.font,
                        border = new RectOffset(15, 7, 4, 4),
                        fixedHeight = 22,
                        contentOffset = new Vector2(20f, -2f),
                        fontSize = GUI.skin.font.fontSize
                    };
                }

                return _subsectionHeaderStyle;
            }
        }

        private static GUIStyle ContextMenuIconStyle
        {
            get
            {
                if (_contextMenuIconStyle == null)
                {
                    _contextMenuIconStyle = new GUIStyle
                    {
                        stretchWidth = true,
                        stretchHeight = true,
                        fixedHeight = 0f,
                        fixedWidth = 0f,
                        normal = new GUIStyleState
                        {
                            background = EditorGUIUtility.IconContent("_Menu").image as Texture2D,
                        },
                    };
                }

                return _contextMenuIconStyle;
            }
        }

        private string Tr(string japanese, string english)
        {
            return _activeLanguageMode switch
            {
                PoiLightChangerInspectorLanguageMode.English => english,
                PoiLightChangerInspectorLanguageMode.Japanese => japanese,
                _ => japanese,
            };
        }

        private GUIContent Tg(string japanese, string english)
        {
            return new GUIContent(Tr(japanese, english));
        }

        private string[] GetBoolOptions()
        {
            return new[]
            {
                Tr("無効", "Disabled"),
                Tr("有効", "Enabled"),
            };
        }

        private string[] GetControlToggleLabels()
        {
            return new[]
            {
                Tr("アニメーション", "Animation"),
                Tr("同期", "Sync"),
                Tr("保存", "Save"),
            };
        }

        private string[] GetWriteDefaultsOptions()
        {
            return new[]
            {
                Tr("アバターに合わせる", "Match Avatar"),
                Tr("有効", "Enabled"),
                Tr("無効", "Disabled"),
            };
        }

        private string[] GetMaterialFeatureModeOptions()
        {
            return new[]
            {
                Tr("現在の状態を維持", "Keep Current State"),
                Tr("すべてのマテリアルで強制", "Force On All Materials"),
            };
        }

        private string[] GetLightDirectionModeOptions()
        {
            return new[]
            {
                Tr("ワールド", "World"),
                Tr("ローカル", "Local"),
            };
        }

        private string[] GetCompressionChannelOptionLabels(int count)
        {
            count = Mathf.Max(1, count);
            var labels = new string[count];
            for (var index = 0; index < count; index++)
            {
                labels[index] = (index + 1).ToString();
            }

            return labels;
        }

        private void OnEnable()
        {
            generalProperty = serializedObject.FindProperty(nameof(PoiLightChangerComponent.General));
            menuProperty = serializedObject.FindProperty(nameof(PoiLightChangerComponent.Menu));
            syncProperty    = serializedObject.FindProperty(nameof(PoiLightChangerComponent.Sync));
            targetProperty  = serializedObject.FindProperty(nameof(PoiLightChangerComponent.Target));
            poiyomiProperty = serializedObject.FindProperty(nameof(PoiLightChangerComponent.Poiyomi));
            bakeProperty    = serializedObject.FindProperty(nameof(PoiLightChangerComponent.Bake));
            overridesProperty = serializedObject.FindProperty(nameof(PoiLightChangerComponent.Overrides));

            if (!_defaultsInitialized)
            {
                _defaultsInitialized = true;
                EnsureFoldoutDefaults();
            }

            var cachedLicenseState = PoiLightChangerLicenseStore.Load();
            _licenseCodeDraft = cachedLicenseState.storedLicenseCode ?? string.Empty;
            _licenseSnapshot = PoiLightChangerLicenseService.GetCurrentSnapshot();
            EditorApplication.update += HandlePendingPolicyRefresh;
        }

        private void OnDisable()
        {
            EditorApplication.update -= HandlePendingPolicyRefresh;
            _pendingPolicyRefreshOperation?.Dispose();
            _pendingPolicyRefreshOperation = null;
            _isPolicyRefreshInProgress = false;
            _pendingPolicyRefreshLicenseCode = string.Empty;
        }

        private static void EnsureFoldoutDefaults()
        {
            if (SessionState.GetInt(FoldoutDefaultsVersionKey, 0) >= FoldoutDefaultsVersion)
            {
                return;
            }

            SetFoldoutDefault(KeyGeneral, DefaultFoldoutExpanded);
            SetFoldoutDefault(KeyTarget, DefaultFoldoutExpanded);
            SetFoldoutDefault(KeyOverrides, DefaultFoldoutExpanded);
            SetFoldoutDefault(KeyLighting, DefaultFoldoutExpanded);
            SetFoldoutDefault(KeyLightDirection, DefaultFoldoutExpanded);
            SetFoldoutDefault(KeyColor, DefaultFoldoutExpanded);
            SetFoldoutDefault(KeySSAO, DefaultFoldoutExpanded);
            SetFoldoutDefault(KeyContactShadow, DefaultFoldoutExpanded);
            SetFoldoutDefault(KeySquish, DefaultFoldoutExpanded);
            SetFoldoutDefault(KeyProximity, DefaultFoldoutExpanded);
            SetFoldoutDefault(KeyOutline, DefaultFoldoutExpanded);
            SetFoldoutDefault(KeyBacklight, DefaultFoldoutExpanded);
            SetFoldoutDefault(KeyBake, DefaultFoldoutExpanded);
            SetFoldoutDefault(KeyParam, DefaultFoldoutExpanded);
            SetFoldoutDefault(KeyPreset, DefaultFoldoutExpanded);
            SetFoldoutDefault(KeyLicense, DefaultFoldoutExpanded);
            SessionState.SetInt(FoldoutDefaultsVersionKey, FoldoutDefaultsVersion);
        }

        private static void SetFoldoutDefault(string key, bool value)
        {
            SessionState.SetBool(key, value);
        }

        public override void OnInspectorGUI()
        {
            if (target is PoiLightChangerComponent component && component.EnsureInitialized())
            {
                EditorUtility.SetDirty(component);
            }

            serializedObject.Update();
            _activeLanguageMode = ResolveInspectorLanguageMode();
            _licenseSnapshot = PoiLightChangerLicenseService.GetCurrentSnapshot();
            _activeDiagnostics = target is PoiLightChangerComponent activeComponent
                ? PoiLightChangerDiagnostics.CollectComponentDiagnostics(activeComponent, licenseSnapshot: _licenseSnapshot)
                : Array.Empty<PoiLightChangerDiagnosticEntry>();
            var hasPoiyomiPro = HasPoiyomiProInProject();
            var hasPoiyomiV10OrNewerPro = HasPoiyomiV10OrNewerProInProject();
            var materialOverridesAvailable = IsFeatureAvailable(PoiLightChangerLicensedFeatureId.MaterialOverrides);
            var colorAvailable = IsSectionAvailable(PoiLightChangerControlSectionId.Color);
            var backlightAvailable = IsSectionAvailable(PoiLightChangerControlSectionId.Backlight);
            var proximityAvailable = IsSectionAvailable(PoiLightChangerControlSectionId.Proximity);
            var outlineAvailable = IsSectionAvailable(PoiLightChangerControlSectionId.Outline);
            var ssaoAvailable = IsSectionAvailable(PoiLightChangerControlSectionId.SSAO);
            var contactShadowAvailable = IsSectionAvailable(PoiLightChangerControlSectionId.ContactShadow);
            var squishAvailable = IsSectionAvailable(PoiLightChangerControlSectionId.Squish);
            var parameterCompressionAvailable = IsFeatureAvailable(PoiLightChangerLicensedFeatureId.ParameterCompression);
            var textureBakeAvailable = IsFeatureAvailable(PoiLightChangerLicensedFeatureId.TextureBake);
            var presetsAvailable = IsFeatureAvailable(PoiLightChangerLicensedFeatureId.Presets);
            var poiyomiSectionRestriction = ResolvePoiyomiSectionRestriction(hasPoiyomiPro, hasPoiyomiV10OrNewerPro);
            var shouldShowPoiyomiSectionHelpBox =
                (poiyomiSectionRestriction.DisableSsao && ssaoAvailable) ||
                (poiyomiSectionRestriction.DisableContactShadow && contactShadowAvailable) ||
                (poiyomiSectionRestriction.DisableSquish && squishAvailable);
            SynchronizeSsaoAvailabilityState(hasPoiyomiPro);
            SynchronizeContactShadowAvailabilityState(hasPoiyomiV10OrNewerPro);
            SynchronizeSquishAvailabilityState(hasPoiyomiV10OrNewerPro);
            var disableWholeInspector = PoiLightChangerDiagnostics.ShouldDisableInspector(_activeDiagnostics);

            DrawHeaderRow("Poi Light Changer");
            EditorGUILayout.Space(6f);
            DrawTitleLicenseInfoHelpBox();
            DrawInspectorDiagnosticHelpBoxes();
            DrawGroupSpacing();

            using (new EditorGUI.DisabledScope(disableWholeInspector))
            {
                DrawGroupHeader(Tr("マテリアル共通設定", "Material Overrides"));
                DrawSection(
                    KeyOverrides,
                    Tr("マテリアル共通設定", "Material Overrides"),
                    DrawOverridesSection,
                    disabled: !materialOverridesAvailable,
                    useIndent: false,
                    menuCallback: menu => AddPropertyMenuItems(
                        menu,
                        new[] { overridesProperty.propertyPath },
                        () => ResetSerializedProperty(serializedObject, overridesProperty.propertyPath)));
                EditorGUILayout.HelpBox(
                    Tr("すべてのマテリアルに同じ設定値を適用します。", "Apply the same override values to all target materials."),
                    MessageType.Info);
                DrawGroupSpacing();

                DrawGroupHeader(Tr("マテリアル設定", "Material Settings"));
                DrawPoiyomiSectionWithToggle(
                    KeyLighting,
                    PoiLightChangerControlSectionId.Lighting,
                    DrawLightingSection,
                    useIndent: false);

                DrawPoiyomiSectionWithToggle(
                    KeyLightDirection,
                    PoiLightChangerControlSectionId.LightDirection,
                    DrawLightDirectionSection,
                    useIndent: false);

                DrawPoiyomiSectionWithToggle(
                    KeyColor,
                    PoiLightChangerControlSectionId.Color,
                    DrawColorSection,
                    useIndent: false,
                    disabled: !colorAvailable);

                DrawPoiyomiSectionWithToggle(
                    KeyBacklight,
                    PoiLightChangerControlSectionId.Backlight,
                    DrawBacklightSection,
                    useIndent: false,
                    disabled: !backlightAvailable);

                DrawPoiyomiSectionWithToggle(
                    KeyProximity,
                    PoiLightChangerControlSectionId.Proximity,
                    DrawProximitySection,
                    useIndent: false,
                    disabled: !proximityAvailable);

                DrawPoiyomiSectionWithToggle(
                    KeyOutline,
                    PoiLightChangerControlSectionId.Outline,
                    DrawOutlineSection,
                    useIndent: false,
                    disabled: !outlineAvailable);

                DrawPoiyomiSectionWithToggle(
                    KeySSAO,
                    PoiLightChangerControlSectionId.SSAO,
                    () =>
                    {
                        using (new EditorGUI.DisabledScope(poiyomiSectionRestriction.DisableSsao))
                        {
                            DrawSSAOSection();
                        }
                    },
                    useIndent: false,
                    disabled: poiyomiSectionRestriction.DisableSsao || !ssaoAvailable);

                DrawPoiyomiSectionWithToggle(
                    KeyContactShadow,
                    PoiLightChangerControlSectionId.ContactShadow,
                    () =>
                    {
                        using (new EditorGUI.DisabledScope(poiyomiSectionRestriction.DisableContactShadow))
                        {
                            DrawContactShadowSection();
                        }
                    },
                    useIndent: false,
                    disabled: poiyomiSectionRestriction.DisableContactShadow || !contactShadowAvailable);

                DrawPoiyomiSectionWithToggle(
                    KeySquish,
                    PoiLightChangerControlSectionId.Squish,
                    () =>
                    {
                        using (new EditorGUI.DisabledScope(poiyomiSectionRestriction.DisableSquish))
                        {
                            DrawSquishSection();
                        }
                    },
                    useIndent: false,
                    disabled: poiyomiSectionRestriction.DisableSquish || !squishAvailable);
                if (shouldShowPoiyomiSectionHelpBox && poiyomiSectionRestriction.HasHelpBox)
                {
                    EditorGUILayout.HelpBox(poiyomiSectionRestriction.HelpBoxMessage, MessageType.Info);
                }

                DrawGroupSpacing();
            }

            DrawGroupHeader(Tr("ライセンス", "License"));
            DrawSection(
                KeyLicense,
                Tr("ライセンス認証", "License Authentication"),
                DrawLicenseSection);
            DrawGroupSpacing();

            using (new EditorGUI.DisabledScope(disableWholeInspector))
            {
                DrawGroupHeader(Tr("その他の設定", "Other Settings"));
                DrawSection(
                    KeyGeneral,
                    Tr("基本設定", "General Settings"),
                    DrawGeneralSection,
                    menuCallback: menu => AddPropertyMenuItems(
                        menu,
                        new[] { generalProperty.propertyPath },
                        () => ResetSerializedProperty(serializedObject, generalProperty.propertyPath)));
                DrawSection(
                    KeyParam,
                    Tr("パラメーター圧縮", "Parameter Compression"),
                    DrawParamSection,
                    disabled: !parameterCompressionAvailable,
                    menuCallback: menu => AddPropertyMenuItems(
                        menu,
                        new[] { syncProperty.propertyPath },
                        () => ResetSerializedProperty(serializedObject, syncProperty.propertyPath)));
                DrawSection(
                    KeyBake,
                    Tr("テクスチャの焼き込み", "Texture Baking"),
                    DrawBakeSection,
                    disabled: !textureBakeAvailable,
                    menuCallback: menu => AddPropertyMenuItems(
                        menu,
                        new[] { bakeProperty.propertyPath },
                        () => ResetSerializedProperty(serializedObject, bakeProperty.propertyPath)));
                DrawSection(
                    KeyTarget,
                    Tr("除外設定", "Exclusion Settings"),
                    DrawTargetSection);
                DrawSection(
                    KeyPreset,
                    Tr("プリセット", "Presets"),
                    DrawPresetSection,
                    disabled: !presetsAvailable);
            }

            GUILayout.Space(8f);
            serializedObject.ApplyModifiedProperties();
        }

        private void SynchronizeSsaoAvailabilityState(bool hasPoiyomiPro)
        {
            if (hasPoiyomiPro || poiyomiProperty == null)
            {
                return;
            }

            var ssaoEnableProperty = poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.EnableSSAOControl));
            if (ssaoEnableProperty != null && ssaoEnableProperty.boolValue)
            {
                ssaoEnableProperty.boolValue = false;
            }

            if (SessionState.GetBool(KeySSAO, DefaultFoldoutExpanded))
            {
                SessionState.SetBool(KeySSAO, false);
            }
        }

        private void SynchronizeContactShadowAvailabilityState(bool hasPoiyomiV10OrNewerPro)
        {
            if (hasPoiyomiV10OrNewerPro || poiyomiProperty == null)
            {
                return;
            }

            var contactShadowEnableProperty = poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.EnableContactShadowControl));
            if (contactShadowEnableProperty != null && contactShadowEnableProperty.boolValue)
            {
                contactShadowEnableProperty.boolValue = false;
            }

            if (SessionState.GetBool(KeyContactShadow, DefaultFoldoutExpanded))
            {
                SessionState.SetBool(KeyContactShadow, false);
            }
        }

        private void SynchronizeSquishAvailabilityState(bool hasPoiyomiV10OrNewerPro)
        {
            if (hasPoiyomiV10OrNewerPro || poiyomiProperty == null)
            {
                return;
            }

            var squishEnableProperty = poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.EnableSquishControl));
            if (squishEnableProperty != null && squishEnableProperty.boolValue)
            {
                squishEnableProperty.boolValue = false;
            }

            if (SessionState.GetBool(KeySquish, DefaultFoldoutExpanded))
            {
                SessionState.SetBool(KeySquish, false);
            }
        }

        private PoiLightChangerInspectorLanguageMode ResolveInspectorLanguageMode()
        {
            if (menuProperty == null)
            {
                return PoiLightChangerInspectorLanguageMode.Japanese;
            }

            var languageProperty = menuProperty.FindPropertyRelative(nameof(PoiLightChangerMenuSettings.InspectorLanguage));
            if (languageProperty == null)
            {
                return PoiLightChangerInspectorLanguageMode.Japanese;
            }

            return languageProperty.intValue == (int)PoiLightChangerInspectorLanguageMode.English
                ? PoiLightChangerInspectorLanguageMode.English
                : PoiLightChangerInspectorLanguageMode.Japanese;
        }

        private void DrawInspectorDiagnosticHelpBoxes()
        {
            DrawDiagnosticsForPlacement(PoiLightChangerDiagnosticPlacement.Global, false);
        }

        private void DrawTitleLicenseInfoHelpBox()
        {
            if (_licenseSnapshot == null || _licenseSnapshot.IsLicensed)
            {
                return;
            }

            EditorGUILayout.HelpBox(
                Tr(
                    "現在は無料機能のみに制限されています。\n購入済みの方はライセンス認証から登録してください。",
                    "Only free features are currently available.\nIf you have already purchased, register it from License Authentication."),
                MessageType.Info);
        }

        private PoiyomiSectionRestrictionState ResolvePoiyomiSectionRestriction(bool hasPoiyomiPro, bool hasPoiyomiV10OrNewerPro)
        {
            if (!hasPoiyomiPro)
            {
                return new PoiyomiSectionRestrictionState(
                    disableSsao: true,
                    disableContactShadow: true,
                    disableSquish: true,
                    helpBoxMessage: Tr(
                        "Poiyomi Proが有効ではない為、一部のセクションが無効化されます。",
                        "Some sections are disabled because Poiyomi Pro is not enabled."));
            }

            if (!hasPoiyomiV10OrNewerPro)
            {
                return new PoiyomiSectionRestrictionState(
                    disableSsao: false,
                    disableContactShadow: true,
                    disableSquish: true,
                    helpBoxMessage: Tr(
                        "Poiyomiのバージョンによる影響で、一部のセクションが無効化されます。",
                        "Some sections are disabled due to the Poiyomi version in use."));
            }

            return new PoiyomiSectionRestrictionState(
                disableSsao: false,
                disableContactShadow: false,
                disableSquish: false,
                helpBoxMessage: string.Empty);
        }

        private void DrawDiagnosticsForPlacement(PoiLightChangerDiagnosticPlacement placement, bool indented)
        {
            foreach (var diagnostic in PoiLightChangerDiagnostics.FilterByPlacement(_activeDiagnostics, placement))
            {
                if (IsInspectorLicenseDiagnostic(diagnostic))
                {
                    continue;
                }

                var message = diagnostic.GetInspectorMessage(_activeLanguageMode);
                if (string.IsNullOrWhiteSpace(message))
                {
                    continue;
                }

                if (indented)
                {
                    DrawIndentedHelpBox(message, diagnostic.InspectorMessageType, SectionHelpBoxIndent);
                }
                else
                {
                    EditorGUILayout.HelpBox(message, diagnostic.InspectorMessageType);
                }
            }
        }

        private static bool IsInspectorLicenseDiagnostic(PoiLightChangerDiagnosticEntry diagnostic)
        {
            if (diagnostic == null)
            {
                return false;
            }

            return diagnostic.Id == PoiLightChangerDiagnosticId.LicenseUnlicensed ||
                   diagnostic.Id == PoiLightChangerDiagnosticId.LicenseOfflineGraceExpired;
        }

        private void DrawSection(
            string key,
            string title,
            System.Action drawContent,
            bool disabled = false,
            bool useIndent = true,
            System.Action<GenericMenu> menuCallback = null)
        {
            var state = BeginPoiLikeSection(new GUIContent(title), key, menuCallback, visuallyDisabled: disabled);
            if (!state.Expanded)
                return;

            EditorGUILayout.Space();

            using (new EditorGUI.DisabledScope(disabled))
            {
                if (useIndent)
                {
                    GUILayout.BeginHorizontal();
                    GUILayout.Space(15f);
                    EditorGUILayout.BeginVertical();
                }

                drawContent();

                if (useIndent)
                {
                    EditorGUILayout.EndVertical();
                    GUILayout.EndHorizontal();
                }
            }

            EndPoiLikeSection();
        }

        private static PoiLikeSectionState BeginPoiLikeSection(
            GUIContent label,
            string key,
            System.Action<GenericMenu> menuCallback = null,
            bool visuallyDisabled = false)
        {
            Rect position = GUILayoutUtility.GetRect(label, SubsectionHeaderStyle);
            position = ApplyPoiLikeHeaderOffset(position, 0);

            using (new EditorGUI.DisabledScope(visuallyDisabled))
            {
                DrawPoiLikeHeaderBoxAndContent(position, label, reserveToggleLane: false);
                DrawPoiLikeHeaderFoldoutArrow(position, SessionState.GetBool(key, DefaultFoldoutExpanded));
            }

            Rect? contextButtonRect = null;
            if (menuCallback != null)
            {
                using (new EditorGUI.DisabledScope(visuallyDisabled))
                {
                    contextButtonRect = DrawContextMenuButton(position);
                }
            }

            bool expanded = HandlePoiLikeSectionInput(position, key, menuCallback: menuCallback, contextButtonRect: contextButtonRect);

            return new PoiLikeSectionState(expanded);
        }

        private static void DrawSectionWithToggle(
            string key,
            string title,
            SerializedProperty enableProp,
            System.Action drawContent,
            bool useIndent = true,
            bool disabled = false,
            System.Action<GenericMenu> menuCallback = null)
        {
            bool isEnabled = enableProp.boolValue;
            bool displayEnabled = disabled ? false : isEnabled;
            var state = BeginPoiLikeSection(
                new GUIContent(title),
                key,
                enableProp,
                ref displayEnabled,
                menuCallback,
                disableEnableToggle: disabled,
                visuallyDisabled: disabled);
            if (!state.Expanded)
                return;

            EditorGUILayout.Space();

            using (new EditorGUI.DisabledScope(disabled))
            {
                if (useIndent)
                {
                    GUILayout.BeginHorizontal();
                    GUILayout.Space(15f);
                    EditorGUILayout.BeginVertical();
                }

                drawContent();

                if (useIndent)
                {
                    EditorGUILayout.EndVertical();
                    GUILayout.EndHorizontal();
                }
            }

            EndPoiLikeSection();
        }

        private void DrawSubsection(
            string key,
            string title,
            System.Action drawContent,
            System.Action<GenericMenu> menuCallback = null)
        {
            var state = BeginPoiLikeSubsection(new GUIContent(title), key, menuCallback);
            if (!state.Expanded)
                return;

            EditorGUILayout.Space();

            GUILayout.BeginHorizontal();
            GUILayout.Space(15f);
            EditorGUILayout.BeginVertical();

            drawContent();

            EditorGUILayout.EndVertical();
            GUILayout.EndHorizontal();

            EndPoiLikeSubsection();
        }

        private void DrawGeneralSection()
        {
            DrawEnumPropertyPopup(
                generalProperty.FindPropertyRelative(nameof(PoiLightChangerGeneralSettings.WriteDefaults)),
                Tg("Write Defaults", "Write Defaults"),
                GetWriteDefaultsOptions());

            DrawExMenuLanguageDropdown(
                menuProperty?.FindPropertyRelative(nameof(PoiLightChangerMenuSettings.ExMenuLanguage)));

            DrawBoolDropdown(
                EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight),
                Tr("リセットボタンを追加", "Add Reset Button"),
                generalProperty.FindPropertyRelative(nameof(PoiLightChangerGeneralSettings.AddResetButton)));
            DrawBoolDropdown(
                EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight),
                Tr("パーティクルを除外", "Exclude Particle Systems"),
                generalProperty.FindPropertyRelative(nameof(PoiLightChangerGeneralSettings.ExcludeParticleSystem)));
            DrawToggleRight(
                generalProperty.FindPropertyRelative(nameof(PoiLightChangerGeneralSettings.AutoAddAnimated)),
                Tg("Animatedを自動で付与", "Auto Add Animated"));
            EditorGUILayout.HelpBox(
                Tr(
                    "Lock済みのマテリアルはビルド時に一時解除し、Animated付与・再Lockを行います。",
                    "Locked materials are temporarily unlocked during build, marked Animated, and then locked again."),
                MessageType.Info);
        }

        private void DrawPoiyomiSectionWithToggle(
            string key,
            PoiLightChangerControlSectionId sectionId,
            System.Action drawContent,
            bool useIndent = true,
            bool disabled = false)
        {
            var enableProperty = GetPoiyomiSectionEnableProperty(sectionId);
            var title = GetLocalizedSectionTitle(sectionId);
            if (enableProperty == null || string.IsNullOrWhiteSpace(title))
            {
                return;
            }

            DrawSectionWithToggle(
                key,
                title,
                enableProperty,
                drawContent,
                useIndent,
                disabled,
                menu => AddPropertyMenuItems(
                    menu,
                    GetPoiyomiSectionPropertyPaths(sectionId),
                    () => ResetPoiyomiSectionProperties(
                        serializedObject,
                        poiyomiProperty.propertyPath,
                        sectionId)));
        }

        private string GetLocalizedSectionTitle(PoiLightChangerControlSectionId sectionId)
        {
            var japanese = PoiLightChangerControlRegistry.GetInspectorSectionTitleJapanese(sectionId);
            var english = PoiLightChangerControlRegistry.GetInspectorSectionTitleEnglish(sectionId);
            if (string.IsNullOrWhiteSpace(japanese) && string.IsNullOrWhiteSpace(english))
            {
                return string.Empty;
            }

            return Tr(japanese, english);
        }

        private SerializedProperty GetPoiyomiSectionEnableProperty(PoiLightChangerControlSectionId sectionId)
        {
            var propertyName = PoiLightChangerControlRegistry.GetSectionEnablePropertyName(sectionId);
            if (poiyomiProperty == null || string.IsNullOrWhiteSpace(propertyName))
            {
                return null;
            }

            return poiyomiProperty.FindPropertyRelative(propertyName);
        }

        private string[] GetPoiyomiSectionPropertyPaths(PoiLightChangerControlSectionId sectionId)
        {
            if (poiyomiProperty == null)
            {
                return System.Array.Empty<string>();
            }

            var enablePropertyName = PoiLightChangerControlRegistry.GetSectionEnablePropertyName(sectionId);
            var propertyNames = PoiLightChangerControlRegistry.GetSectionPropertyNames(sectionId);

            return new[] { enablePropertyName }
                .Concat(propertyNames ?? System.Array.Empty<string>())
                .Select(name => $"{poiyomiProperty.propertyPath}.{name}")
                .ToArray();
        }

        private void AddPropertyMenuItems(
            GenericMenu menu,
            System.Collections.Generic.IReadOnlyList<string> propertyPaths,
            System.Action resetAction)
        {
            if (menu == null)
            {
                return;
            }

            menu.AddItem(
                new GUIContent(CopySettingsLabel),
                false,
                () => PoiLightChangerInspectorClipboard.TryCopy(serializedObject, propertyPaths));

            if (PoiLightChangerInspectorClipboard.CanPaste(propertyPaths))
            {
                menu.AddItem(
                    new GUIContent(PasteSettingsLabel),
                    false,
                    () =>
                    {
                        if (PoiLightChangerInspectorClipboard.TryPaste(serializedObject, propertyPaths, PasteSettingsLabel))
                        {
                            serializedObject.Update();
                            Repaint();
                        }
                    });
            }
            else
            {
                menu.AddDisabledItem(new GUIContent(PasteSettingsLabel));
            }

            if (resetAction != null)
            {
                menu.AddSeparator(string.Empty);
                menu.AddItem(new GUIContent(ResetLabel), false, () => resetAction());
            }
        }

        private void DrawHeaderRow(string title)
        {
            var rowRect = EditorGUILayout.GetControlRect(false, TitleRowHeight);
            var leftRect = new Rect(rowRect.x, rowRect.y, TitleLanguagePopupWidth, rowRect.height);
            var popupRect = new Rect(rowRect.xMax - TitleLanguagePopupWidth, rowRect.y, TitleLanguagePopupWidth, EditorGUIUtility.singleLineHeight);
            var versionRect = new Rect(rowRect.xMax - TitleLanguagePopupWidth, rowRect.y, TitleLanguagePopupWidth - 6f, rowRect.height);
            var titleRect = new Rect(leftRect.xMax, rowRect.y, Mathf.Max(0f, popupRect.x - leftRect.xMax), rowRect.height);

            EditorGUI.LabelField(titleRect, title, PoiyomiTitleStyle);
            EditorGUI.LabelField(versionRect, $"v{PackageVersion}", VersionLabelStyle);

            if (menuProperty == null)
            {
                return;
            }

            DrawLanguagePopup(
                popupRect,
                menuProperty.FindPropertyRelative(nameof(PoiLightChangerMenuSettings.InspectorLanguage)));
        }

        private void DrawExMenuLanguageDropdown(SerializedProperty property)
        {
            if (property == null)
            {
                return;
            }

            var rowRect = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
            ResolveFixedPopupLayout(rowRect, out var labelRect, out var popupRect);
            EditorGUI.LabelField(labelRect, Tg("メニューの言語", "Menu Language"));

            string[] options =
            {
                Tr("インスペクターに合わせる", "Match Inspector"),
                Tr("英語", "English"),
                Tr("日本語", "Japanese"),
            };

            int selectedIndex = property.intValue switch
            {
                (int)PoiLightChangerExMenuLanguageMode.MatchInspector => 0,
                (int)PoiLightChangerExMenuLanguageMode.English => 1,
                _ => 2,
            };

            EditorGUI.BeginChangeCheck();
            selectedIndex = EditorGUI.Popup(popupRect, selectedIndex, options);
            if (EditorGUI.EndChangeCheck())
            {
                property.intValue = selectedIndex switch
                {
                    0 => (int)PoiLightChangerExMenuLanguageMode.MatchInspector,
                    1 => (int)PoiLightChangerExMenuLanguageMode.English,
                    _ => (int)PoiLightChangerExMenuLanguageMode.Japanese,
                };
            }
        }

        private static void DrawLanguagePopup(Rect position, SerializedProperty property)
        {
            if (property == null)
            {
                return;
            }

            string[] options =
            {
                "English",
                "Japanese",
            };

            int selectedIndex = property.intValue == (int)PoiLightChangerInspectorLanguageMode.English ? 0 : 1;
            EditorGUI.BeginChangeCheck();
            selectedIndex = EditorGUI.Popup(position, selectedIndex, options);
            if (EditorGUI.EndChangeCheck())
            {
                property.intValue = selectedIndex == 0
                    ? (int)PoiLightChangerInspectorLanguageMode.English
                    : (int)PoiLightChangerInspectorLanguageMode.Japanese;
            }
        }

        private static string ResolvePackageVersion()
        {
            var packageInfo = UnityEditor.PackageManager.PackageInfo.FindForAssembly(typeof(PoiLightChangerComponentEditor).Assembly);
            return string.IsNullOrWhiteSpace(packageInfo?.version) ? "0.0.0" : packageInfo.version;
        }

        private static void InvalidateProjectCache()
        {
            PoiLightChangerDiagnostics.InvalidateCaches();
        }

        private static bool HasPoiyomiProInProject()
        {
            return PoiLightChangerDiagnostics.HasPoiyomiProInProject();
        }

        private static bool HasPoiyomiV10OrNewerProInProject()
        {
            return PoiLightChangerDiagnostics.HasPoiyomiV10OrNewerProInProject();
        }

        private bool IsFeatureAvailable(PoiLightChangerLicensedFeatureId featureId)
        {
            return PoiLightChangerLicenseFeatureGate.IsFeatureAvailable(featureId, _licenseSnapshot);
        }

        private bool IsSectionAvailable(PoiLightChangerControlSectionId sectionId)
        {
            return PoiLightChangerLicenseFeatureGate.IsSectionAvailable(sectionId, _licenseSnapshot);
        }

        private void DrawLicenseSection()
        {
            var cachedLicenseState = PoiLightChangerLicenseStore.Load();
            var hasStoredLicense = !string.IsNullOrWhiteSpace(cachedLicenseState.storedLicenseCode);

            _licenseCodeDraft = DrawFixedLayoutTextField(
                Tr("ライセンスコード", "Enter License Code"),
                _licenseCodeDraft,
                0.35f);

            using (new EditorGUI.DisabledScope(string.IsNullOrWhiteSpace(_licenseCodeDraft) || _isPolicyRefreshInProgress))
            {
                if (GUILayout.Button(Tr("ライセンスを登録", "Validate and Save License")))
                {
                    CancelPendingPolicyRefresh();
                    _licenseSnapshot = PoiLightChangerLicenseService.ValidateAndActivate(_licenseCodeDraft, allowNetwork: true);
                    if (_licenseSnapshot.IsLicensed)
                    {
                        _licenseCodeDraft = PoiLightChangerLicenseStore.Load().storedLicenseCode ?? _licenseCodeDraft;
                    }

                    GUI.FocusControl(null);
                    Repaint();
                }
            }

            var buttonRowRect = EditorGUILayout.GetControlRect();
            var buttonSpacing = 4f;
            var halfButtonWidth = (buttonRowRect.width - buttonSpacing) * 0.5f;
            var refreshButtonRect = new Rect(buttonRowRect.x, buttonRowRect.y, halfButtonWidth, buttonRowRect.height);
            var clearButtonRect = new Rect(buttonRowRect.x + halfButtonWidth + buttonSpacing, buttonRowRect.y, halfButtonWidth, buttonRowRect.height);

            using (new EditorGUI.DisabledScope(!hasStoredLicense || _isPolicyRefreshInProgress))
            {
                if (GUI.Button(refreshButtonRect, Tr("再認証", "Refresh Policy")))
                {
                    StartAsyncPolicyRefresh(cachedLicenseState.storedLicenseCode);
                    GUI.FocusControl(null);
                    Repaint();
                }
            }

            using (new EditorGUI.DisabledScope(!hasStoredLicense || _isPolicyRefreshInProgress))
            {
                if (GUI.Button(clearButtonRect, Tr("ライセンスを削除", "Clear Stored License")))
                {
                    CancelPendingPolicyRefresh();
                    PoiLightChangerLicenseService.ClearStoredLicense();
                    _licenseSnapshot = PoiLightChangerLicenseService.GetCurrentSnapshot();
                    _licenseCodeDraft = string.Empty;
                    GUI.FocusControl(null);
                    Repaint();
                }
            }

            DrawLicenseInfoRow(
                Tr("認証状態", "Status"),
                GetLicenseStateLabel());
            DrawLicenseInfoRow(
                Tr("ライセンス", "License"),
                GetLicenseAvailabilityLabel());

            if (_licenseSnapshot?.LicensePayload != null)
            {
                DrawLicenseInfoRow(
                    Tr("ユーザータイプ", "User Type"),
                    _licenseSnapshot.LicensePayload.cohort);
            }

            if (ShouldShowLicenseStatusHelpBox())
            {
                EditorGUILayout.Space(2f);
                EditorGUILayout.HelpBox(
                    GetLicenseStatusMessage(),
                    GetLicenseStatusMessageType());
            }

            if (ShouldShowBottomLicensePurchaseHelpBox())
            {
                EditorGUILayout.Space(2f);
                EditorGUILayout.HelpBox(
                    Tr(
                        "Boothで案内するライセンスコードを入力して認証してください。\n未認証時は無料範囲のみ使用できます。",
                        "Enter the license code provided with your Booth purchase. Without a license, only the free feature set is available."),
                    MessageType.Info);
            }
        }

        private string GetLicenseStatusMessage()
        {
            var licenseDiagnostic = GetLicenseDiagnosticForFoldout();
            if (licenseDiagnostic != null)
            {
                return licenseDiagnostic.GetInspectorMessage(_activeLanguageMode);
            }

            var statusMessage = _activeLanguageMode == PoiLightChangerInspectorLanguageMode.English
                ? _licenseSnapshot?.StatusMessageEnglish
                : _licenseSnapshot?.StatusMessageJapanese;
            var actionMessage = GetLicenseActionMessage();

            if (string.IsNullOrWhiteSpace(statusMessage) && string.IsNullOrWhiteSpace(actionMessage))
            {
                return GetLicenseAvailabilityLabel();
            }

            if (string.IsNullOrWhiteSpace(statusMessage))
            {
                return actionMessage;
            }

            if (string.IsNullOrWhiteSpace(actionMessage))
            {
                return statusMessage;
            }

            return $"{statusMessage}\n{actionMessage}";
        }

        private MessageType GetLicenseStatusMessageType()
        {
            var licenseDiagnostic = GetLicenseDiagnosticForFoldout();
            if (licenseDiagnostic != null)
            {
                return licenseDiagnostic.InspectorMessageType;
            }

            return _licenseSnapshot?.ValidationState switch
            {
                PoiLightChangerLicenseValidationState.Licensed => MessageType.Info,
                PoiLightChangerLicenseValidationState.LicensedUsingCache => MessageType.Info,
                PoiLightChangerLicenseValidationState.PolicyFetchFailedWithinGrace => MessageType.Warning,
                _ => MessageType.Warning,
            };
        }

        private PoiLightChangerDiagnosticEntry GetLicenseDiagnosticForFoldout()
        {
            if (_activeDiagnostics == null)
            {
                return null;
            }

            return _activeDiagnostics.FirstOrDefault(IsInspectorLicenseDiagnostic);
        }

        private string GetLicenseGuideMessage()
        {
            if (_isPolicyRefreshInProgress)
            {
                return Tr(
                    "ライセンスを再認証中です。完了するまで現在の状態を表示したまま待機します。",
                    "Refreshing policy. PLC will keep showing the current state until the request finishes.");
            }

            return _licenseSnapshot?.ValidationState switch
            {
                PoiLightChangerLicenseValidationState.Licensed => Tr(
                    "このPCに保存されたライセンスを使用中です。別のUnityプロジェクトでも同じライセンスを共有できます。",
                    "This PC is using a stored license. The same license can be shared across your Unity projects."),
                PoiLightChangerLicenseValidationState.LicensedUsingCache => Tr(
                    "前回成功した認証キャッシュを使用中です。ネット接続できるときにライセンスを再認証してください。",
                    "The last successful policy cache is currently in use. Refresh the policy when you are back online."),
                PoiLightChangerLicenseValidationState.PolicyFetchFailedWithinGrace => Tr(
                    "ライセンスの再認証に失敗しましたが、猶予期間中はキャッシュを使用して継続できます。",
                    "Policy refresh failed, but PLC can continue using the cached policy during the grace period."),
                PoiLightChangerLicenseValidationState.PolicyExpired => Tr(
                    "オフライン猶予が切れています。ネット接続した状態でライセンスを再認証してください。",
                    "The offline grace period has expired. Refresh the policy while online."),
                PoiLightChangerLicenseValidationState.SignatureInvalid => Tr(
                    "入力したライセンスコードを確認してから再度認証してください。保存済みコードを使い直す場合は再入力が必要です。",
                    "Check the entered license code and validate again. Re-enter the code if you want to try the stored one again."),
                PoiLightChangerLicenseValidationState.PolicyInvalid => Tr(
                    "ライセンスコードは読めていますが、現在のライセンスの認証情報と一致していません。配布中の最新コードを確認してください。",
                    "The license code was parsed, but it does not match the current policy. Check the latest distributed code."),
                PoiLightChangerLicenseValidationState.LicenseExpired => Tr(
                    "このライセンスコードは有効期間外です。新しいコードを入力してください。",
                    "This license code is outside its active time window. Enter a newer code."),
                _ => Tr(
                    "Boothで案内するライセンスコードを入力して認証してください。\n未認証時は無料範囲のみ使用できます。",
                    "Enter the license code provided with your Booth purchase. Without a license, only the free feature set is available."),
            };
        }

        private MessageType GetLicenseGuideMessageType()
        {
            if (_isPolicyRefreshInProgress)
            {
                return MessageType.Info;
            }

            return _licenseSnapshot?.ValidationState switch
            {
                PoiLightChangerLicenseValidationState.Licensed => MessageType.Info,
                PoiLightChangerLicenseValidationState.LicensedUsingCache => MessageType.Info,
                PoiLightChangerLicenseValidationState.PolicyFetchFailedWithinGrace => MessageType.Warning,
                PoiLightChangerLicenseValidationState.PolicyExpired => MessageType.Warning,
                _ => MessageType.Warning,
            };
        }

        private bool ShouldShowTopLicenseGuideHelpBox()
        {
            return _isPolicyRefreshInProgress ||
                   (_licenseSnapshot != null &&
                    _licenseSnapshot.ValidationState != PoiLightChangerLicenseValidationState.Unlicensed);
        }

        private bool ShouldShowBottomLicensePurchaseHelpBox()
        {
            return !_isPolicyRefreshInProgress &&
                   _licenseSnapshot?.ValidationState == PoiLightChangerLicenseValidationState.Unlicensed;
        }

        private bool ShouldShowLicenseStatusHelpBox()
        {
            if (_isPolicyRefreshInProgress || _licenseSnapshot == null)
            {
                return false;
            }

            return _licenseSnapshot.ValidationState switch
            {
                PoiLightChangerLicenseValidationState.Unlicensed => false,
                PoiLightChangerLicenseValidationState.Licensed => false,
                PoiLightChangerLicenseValidationState.LicensedUsingCache => false,
                _ => true,
            };
        }

        private string GetLicenseActionMessage()
        {
            if (_isPolicyRefreshInProgress)
            {
                return Tr(
                    "確認完了後にライセンス状態を更新します。",
                    "PLC will update the license state when the refresh completes.");
            }

            return _licenseSnapshot?.ValidationState switch
            {
                PoiLightChangerLicenseValidationState.Licensed => Tr(
                    "すべてのPLC機能が使用できます。失効情報を更新したいときはライセンスを再認証してください。",
                    "All PLC features are available. Refresh the policy when you want to update revocation information."),
                PoiLightChangerLicenseValidationState.LicensedUsingCache => Tr(
                    "現在はキャッシュを使って継続中です。猶予が切れる前にライセンスを再認証してください。",
                    "PLC is currently running on the cached policy. Refresh it before the grace period expires."),
                PoiLightChangerLicenseValidationState.PolicyFetchFailedWithinGrace => Tr(
                    "猶予が残っている間は継続利用できます。ネット接続後にライセンスを再認証してください。",
                    "You can keep using PLC while grace remains. Refresh the policy once you have network access."),
                PoiLightChangerLicenseValidationState.PolicyExpired => Tr(
                    "再認証できるまではLightingとLight Directionのみ使用できます。",
                    "Until the policy is refreshed, only Lighting and Light Direction remain available."),
                PoiLightChangerLicenseValidationState.Unlicensed => Tr(
                    "認証すると Color、Parameters、Presets を含む全機能が解放されます。",
                    "Validating unlocks all PLC features, including Color, Parameters, and Presets."),
                _ => Tr(
                    "状態を解消するまではLightingとLight Directionのみ使用できます。",
                    "Until this state is resolved, only Lighting and Light Direction remain available."),
            };
        }

        private string GetLicenseStateLabel()
        {
            if (_isPolicyRefreshInProgress)
            {
                return Tr("確認中", "Refreshing");
            }

            return _licenseSnapshot?.ValidationState switch
            {
                PoiLightChangerLicenseValidationState.Licensed => Tr("認証済み", "Licensed"),
                PoiLightChangerLicenseValidationState.LicensedUsingCache => Tr("認証済み", "Licensed"),
                PoiLightChangerLicenseValidationState.PolicyFetchFailedWithinGrace => Tr("認証済み (再取得失敗 / 猶予中)", "Licensed (Refresh Failed / In Grace)"),
                PoiLightChangerLicenseValidationState.PolicyExpired => Tr("再確認が必要", "Refresh Required"),
                PoiLightChangerLicenseValidationState.LicenseExpired => Tr("期限外", "Expired"),
                PoiLightChangerLicenseValidationState.SignatureInvalid => Tr("コード不正", "Invalid Code"),
                PoiLightChangerLicenseValidationState.PolicyInvalid => Tr("認証情報不一致", "Policy Mismatch"),
                _ => Tr("未認証", "Unlicensed"),
            };
        }

        private string GetLicenseAvailabilityLabel()
        {
            return _licenseSnapshot != null && _licenseSnapshot.IsLicensed
                ? Tr("すべての機能を利用可能", "All features are available")
                : Tr("無料機能のみ", "Free features only");
        }

        private void StartAsyncPolicyRefresh(string storedLicenseCode)
        {
            CancelPendingPolicyRefresh();
            _pendingPolicyRefreshLicenseCode = storedLicenseCode ?? string.Empty;
            _isPolicyRefreshInProgress = !string.IsNullOrWhiteSpace(_pendingPolicyRefreshLicenseCode);

            if (!_isPolicyRefreshInProgress)
            {
                return;
            }

            _pendingPolicyRefreshOperation = new PoiLightChangerPolicyClient().BeginFetch(PoiLightChangerLicenseDefaults.PolicyFetchTimeoutSeconds);
            if (_pendingPolicyRefreshOperation == null)
            {
                _licenseSnapshot = PoiLightChangerLicenseService.RefreshPolicyWithResult(
                    _pendingPolicyRefreshLicenseCode,
                    new PoiLightChangerPolicyFetchResult
                    {
                        Success = false,
                        ErrorMessageJapanese = "認証情報URLが不正です。",
                        ErrorMessageEnglish = "The policy URL is invalid.",
                    });
                _pendingPolicyRefreshLicenseCode = string.Empty;
                _isPolicyRefreshInProgress = false;
            }
        }

        private void CancelPendingPolicyRefresh()
        {
            _pendingPolicyRefreshOperation?.Dispose();
            _pendingPolicyRefreshOperation = null;
            _pendingPolicyRefreshLicenseCode = string.Empty;
            _isPolicyRefreshInProgress = false;
        }

        private void HandlePendingPolicyRefresh()
        {
            if (!_isPolicyRefreshInProgress || _pendingPolicyRefreshOperation == null)
            {
                return;
            }

            if (!_pendingPolicyRefreshOperation.TryGetResult(out var result))
            {
                return;
            }

            _pendingPolicyRefreshOperation.Dispose();
            _pendingPolicyRefreshOperation = null;
            _isPolicyRefreshInProgress = false;
            _licenseSnapshot = PoiLightChangerLicenseService.RefreshPolicyWithResult(_pendingPolicyRefreshLicenseCode, result);
            _licenseCodeDraft = PoiLightChangerLicenseStore.Load().storedLicenseCode ?? _licenseCodeDraft;
            _pendingPolicyRefreshLicenseCode = string.Empty;
            Repaint();
        }

        private void DrawLicenseInfoRow(string label, string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return;
            }

            var row = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
            ResolveFixedPopupLayout(row, out var labelRect, out var valueRect);
            EditorGUI.LabelField(labelRect, label);
            EditorGUI.LabelField(valueRect, value);
        }

        private void DrawParamSection()
        {
            var useCompressionProperty = syncProperty.FindPropertyRelative(nameof(PoiLightChangerSyncSettings.UseParameterCompression));
            var channelCountProperty = syncProperty.FindPropertyRelative(nameof(PoiLightChangerSyncSettings.CompressionChannelCount));
            channelCountProperty.intValue = Mathf.Clamp(
                channelCountProperty.intValue,
                1,
                PoiLightChangerParameterCompression.MaxSelectableChannelCount);

            var useCompressionRow = EditorGUILayout.GetControlRect();
            DrawBoolDropdown(
                useCompressionRow,
                Tr("パラメーター圧縮を使用", "Use Parameter Compression"),
                useCompressionProperty);

            var directLayout = PoiLightChangerParameterProvider.GetDirectParameterLayout((PoiLightChangerComponent)target, _licenseSnapshot);
            var compressionPlan = PoiLightChangerParameterCompression.BuildPlanFromSlots(
                directLayout,
                channelCountProperty.intValue);
            var approximateSyncTime = PoiLightChangerParameterCompression.GetApproximateSyncTimeSeconds(
                directLayout,
                channelCountProperty.intValue);
            var usedBits = useCompressionProperty.boolValue && compressionPlan.IsEffective
                ? compressionPlan.CompressedBits
                : compressionPlan.OriginalBits;

            using (new EditorGUI.DisabledScope(!useCompressionProperty.boolValue))
            {
                var row = EditorGUILayout.GetControlRect();
                DrawIntValuePopup(
                    row,
                    Tr("同期チャンネル数", "Sync Channel Count"),
                    channelCountProperty,
                    GetCompressionChannelOptionLabels(PoiLightChangerParameterCompression.MaxSelectableChannelCount),
                    1);
            }

            EditorGUILayout.HelpBox(
                Tr(
                    $"使用Bit数: {usedBits} bit\n" +
                    $"推定同期時間: 約 {approximateSyncTime:0.#} 秒\n" +
                    "1チャンネルあたり10パラメーター/秒で同期されます。",
                    $"Used bits: {usedBits} bit\n" +
                    $"Estimated sync time: about {approximateSyncTime:0.#} sec\n" +
                    "Each channel syncs about 10 parameters per second."),
                MessageType.Info);
            DrawDiagnosticsForPlacement(PoiLightChangerDiagnosticPlacement.Parameters, false);
        }

        private void DrawPresetSection()
        {
            if (target is not PoiLightChangerComponent component)
            {
                return;
            }

            var presetKeys = PoiLightChangerPresetManager.Keys;
            if (_selectedPresetIndex >= presetKeys.Count)
            {
                _selectedPresetIndex = Mathf.Max(0, presetKeys.Count - 1);
            }

            if (presetKeys.Count == 0)
            {
                EditorGUILayout.HelpBox(
                    Tr("プリセットはまだありません。", "No presets have been saved yet."),
                    MessageType.None);
            }
            else
            {
                var presetOptions = presetKeys.ToArray();
                _selectedPresetIndex = EditorGUILayout.Popup(
                    Tr("プリセット", "Presets"),
                    _selectedPresetIndex,
                    presetOptions);

                var selectedPreset = presetKeys[_selectedPresetIndex];
                EditorGUILayout.BeginHorizontal();

                if (GUILayout.Button(Tr("選択中のプリセットを読み込む", "Load Selected Preset")))
                {
                    if (PoiLightChangerPresetManager.TryLoad(selectedPreset, component))
                    {
                        serializedObject.Update();
                        _presetNameDraft = selectedPreset;
                    }
                }

                if (GUILayout.Button(Tr("選択中のプリセットを削除", "Delete Selected Preset")))
                {
                    if (EditorUtility.DisplayDialog(
                            Tr("プリセットを削除", "Delete Preset"),
                            Tr(
                                $"\"{selectedPreset}\" を削除します。",
                                $"Delete \"{selectedPreset}\"?"),
                            Tr("削除", "Delete"),
                            Tr("キャンセル", "Cancel")))
                    {
                        PoiLightChangerPresetManager.Remove(selectedPreset);
                        _selectedPresetIndex = Mathf.Max(0, _selectedPresetIndex - 1);
                    }
                }

                EditorGUILayout.EndHorizontal();
                EditorGUILayout.Space();
            }

            _presetNameDraft = EditorGUILayout.TextField(
                Tr("保存名", "Preset Name"),
                _presetNameDraft);

            using (new EditorGUI.DisabledScope(string.IsNullOrWhiteSpace(_presetNameDraft)))
            {
                if (GUILayout.Button(Tr("設定を保存 / 上書き", "Save / Overwrite Settings")))
                {
                    if (PoiLightChangerPresetManager.TrySave(_presetNameDraft, component))
                    {
                        var updatedKeys = PoiLightChangerPresetManager.Keys;
                        _selectedPresetIndex = Mathf.Max(0, System.Array.IndexOf(updatedKeys.ToArray(), _presetNameDraft.Trim()));
                    }
                }
            }

            EditorGUILayout.HelpBox(
                Tr(
                    "プリセットは同じPC上なら別プロジェクトからも読み込めます。",
                    "Presets can also be loaded from other projects on the same machine."),
                MessageType.Info);
        }

        private void DrawTargetSection()
        {
            DrawToggleRight(
                targetProperty.FindPropertyRelative(nameof(PoiLightChangerTargetSettings.IncludeInactiveRenderers)),
                Tg("非アクティブなレンダラーを含める", "Include Inactive Renderers"));

            EditorGUILayout.Space();

            var excludedObjectsProperty = targetProperty.FindPropertyRelative(nameof(PoiLightChangerTargetSettings.ExcludedObjects));
            EditorGUILayout.LabelField(Tr("除外オブジェクト", "Excluded Objects"), EditorStyles.boldLabel);
            DrawExcludedObjectsList(excludedObjectsProperty);
            DrawCompactHelpBox(
                Tr(
                    "アバター内のオブジェクトを追加することで処理から除外できます。",
                    "You can exclude objects from processing by adding objects in the avatar."),
                MessageType.Info);
        }

        private void DrawExcludedObjectsList(SerializedProperty property)
        {
            if (property == null || !property.isArray)
            {
                return;
            }

            CleanupNullExcludedObjects(property);

            for (var index = 0; index < property.arraySize; index++)
            {
                var element = property.GetArrayElementAtIndex(index);
                var objectProperty = element.FindPropertyRelative(nameof(PoiLightChangerExcludedObjectEntry.Object));
                var includeChildrenProperty = element.FindPropertyRelative(nameof(PoiLightChangerExcludedObjectEntry.IncludeChildren));
                var rowRect = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
                const float gap = 4f;
                const float toggleWidth = 92f;
                const float removeWidth = 20f;
                var objectRect = new Rect(
                    rowRect.x,
                    rowRect.y,
                    rowRect.width - toggleWidth - removeWidth - (gap * 2f),
                    rowRect.height);
                var toggleRect = new Rect(objectRect.xMax + gap, rowRect.y, toggleWidth, rowRect.height);
                var removeRect = new Rect(toggleRect.xMax + gap, rowRect.y, removeWidth, rowRect.height);

                var previousObject = objectProperty.objectReferenceValue as GameObject;
                EditorGUI.BeginChangeCheck();
                var selectedObject = EditorGUI.ObjectField(
                    objectRect,
                    GUIContent.none,
                    objectProperty.objectReferenceValue,
                    typeof(GameObject),
                    true) as GameObject;
                if (EditorGUI.EndChangeCheck())
                {
                    if (selectedObject == null)
                    {
                        objectProperty.objectReferenceValue = null;
                    }
                    else
                    {
                        objectProperty.objectReferenceValue = FilterExcludedObjectSelection(selectedObject) ?? previousObject;
                    }
                }

                if (objectProperty.objectReferenceValue == null)
                {
                    property.DeleteArrayElementAtIndex(index);
                    break;
                }

                EditorGUI.BeginChangeCheck();
                var includeChildren = EditorGUI.ToggleLeft(
                    toggleRect,
                    Tg("子を含める", "Include Children"),
                    includeChildrenProperty.boolValue);
                if (EditorGUI.EndChangeCheck())
                {
                    includeChildrenProperty.boolValue = includeChildren;
                }

                if (GUI.Button(removeRect, "-"))
                {
                    if (objectProperty.objectReferenceValue != null)
                    {
                        objectProperty.objectReferenceValue = null;
                    }

                    property.DeleteArrayElementAtIndex(index);
                    break;
                }

                if (objectProperty.objectReferenceValue is GameObject currentObject &&
                    !IsValidExcludedObject(currentObject))
                {
                    property.DeleteArrayElementAtIndex(index);
                    break;
                }
            }

            DrawExcludedObjectAddField(property);
        }

        private void DrawExcludedObjectAddField(SerializedProperty property)
        {
            var rowRect = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
            var currentEvent = Event.current;
            if (currentEvent != null)
            {
                switch (currentEvent.type)
                {
                    case EventType.DragUpdated:
                    case EventType.DragPerform:
                    {
                        if (rowRect.Contains(currentEvent.mousePosition) &&
                            DragAndDrop.objectReferences.Any(reference => reference is GameObject))
                        {
                            DragAndDrop.visualMode = DragAndDropVisualMode.Copy;
                            if (currentEvent.type == EventType.DragPerform)
                            {
                                DragAndDrop.AcceptDrag();
                                AddExcludedObjects(
                                    property,
                                    DragAndDrop.objectReferences.OfType<GameObject>());
                                DragAndDrop.activeControlID = 0;
                                GUI.changed = true;
                            }

                            currentEvent.Use();
                        }

                        break;
                    }
                    case EventType.DragExited:
                    {
                        HandleUtility.Repaint();
                        break;
                    }
                }
            }

            EditorGUI.BeginChangeCheck();
            var selectedObject = EditorGUI.ObjectField(
                rowRect,
                GUIContent.none,
                null,
                typeof(GameObject),
                true) as GameObject;
            if (EditorGUI.EndChangeCheck() && selectedObject != null)
            {
                AddExcludedObjects(property, new[] { selectedObject });
            }
        }

        private void AddExcludedObjects(SerializedProperty property, IEnumerable<GameObject> gameObjects)
        {
            if (property == null || !property.isArray || gameObjects == null)
            {
                return;
            }

            var pendingObjects = gameObjects
                .Select(FilterExcludedObjectSelection)
                .Where(gameObject => gameObject != null)
                .Distinct()
                .Where(gameObject => !ContainsObject(property, gameObject))
                .ToArray();
            if (pendingObjects.Length == 0)
            {
                return;
            }

            foreach (var gameObject in pendingObjects)
            {
                property.InsertArrayElementAtIndex(property.arraySize);
                var element = property.GetArrayElementAtIndex(property.arraySize - 1);
                element.FindPropertyRelative(nameof(PoiLightChangerExcludedObjectEntry.Object)).objectReferenceValue = gameObject;
                element.FindPropertyRelative(nameof(PoiLightChangerExcludedObjectEntry.IncludeChildren)).boolValue = false;
            }
        }

        private static bool ContainsObject(SerializedProperty property, GameObject gameObject)
        {
            if (property == null || !property.isArray || gameObject == null)
            {
                return false;
            }

            for (var index = 0; index < property.arraySize; index++)
            {
                var element = property.GetArrayElementAtIndex(index);
                var objectProperty = element.FindPropertyRelative(nameof(PoiLightChangerExcludedObjectEntry.Object));
                if (objectProperty.objectReferenceValue == gameObject)
                {
                    return true;
                }
            }

            return false;
        }

        private static void CleanupNullExcludedObjects(SerializedProperty property)
        {
            if (property == null || !property.isArray)
            {
                return;
            }

            for (var index = property.arraySize - 1; index >= 0; index--)
            {
                var element = property.GetArrayElementAtIndex(index);
                var objectProperty = element.FindPropertyRelative(nameof(PoiLightChangerExcludedObjectEntry.Object));
                if (objectProperty.objectReferenceValue == null)
                {
                    property.DeleteArrayElementAtIndex(index);
                }
            }
        }

        private GameObject FilterExcludedObjectSelection(GameObject candidate)
        {
            return IsValidExcludedObject(candidate) ? candidate : null;
        }

        private bool IsValidExcludedObject(GameObject candidate)
        {
            if (candidate == null || EditorUtility.IsPersistent(candidate))
            {
                return false;
            }

            if (target is not PoiLightChangerComponent component)
            {
                return false;
            }

            var avatarRootObject = PoiLightChangerDiagnostics.FindAvatarRootObject(component.gameObject);
            if (avatarRootObject == null)
            {
                return false;
            }

            var candidateTransform = candidate.transform;
            var avatarRootTransform = avatarRootObject.transform;
            return candidateTransform == avatarRootTransform || candidateTransform.IsChildOf(avatarRootTransform);
        }

        private void DrawBakeSection()
        {
            DrawToggleRight(
                bakeProperty.FindPropertyRelative(nameof(PoiLightChangerBakeSettings.EnableColorBake)),
                Tg("テクスチャの焼き込みを有効化", "Enable Texture Baking"));
            DrawToggleRight(
                bakeProperty.FindPropertyRelative(nameof(PoiLightChangerBakeSettings.AllowForceOverrideSameReference)),
                Tg("メインテクスチャと同じ参照を上書き", "Override Same Main Texture Reference"));
            DrawDiagnosticsForPlacement(PoiLightChangerDiagnosticPlacement.TextureBake, false);
            EditorGUILayout.HelpBox(
                Tr(
                    "Poiyomi v9以下の焼き込みは独自実装です。\n詳細はDocsを参照してください。",
                    "Poiyomi v9 and below use a PLC-specific bake implementation.\nSee the Docs for details."),
                MessageType.Info);
        }

        private void DrawLightingSection()
        {
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.MinBrightness)),
                Tr("明るさの下限", "Min Brightness"), 0f, 1f);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.LightingMax)),
                Tr("明るさの上限", "Max Brightness"), 0f, 20f);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.LightingMonochromatic)),
                Tr("ライトのモノクロ化", "Monochrome Lighting"), 0f, 1f);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.PPLightingMultiplier)),
                Tr("ライティング乗数", "Lighting Multiplier"), 0f, 3f, hardMin: 0f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.PPLightingAddition)),
                Tr("ライティング加算", "Lighting Addition"), -3f, 3f, hardMin: float.MinValue, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.PPEmissionMultiplier)),
                Tr("エミッション乗数", "Emission Multiplier"), 0f, 3f, hardMin: 0f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.PPFinalColorMultiplier)),
                Tr("カラー乗数", "Final Color Multiplier"), 0f, 3f, hardMin: 0f, hardMax: float.MaxValue);
        }

        private void DrawOverridesSection()
        {
            DrawEnumOverrideSetting(
                overridesProperty.FindPropertyRelative(nameof(PoiLightChangerOverrideSettings.LightColorMode)),
                Tr("ライトカラーモード", "Light Color Mode"),
                new[] { "Poi Custom", "Standard", "UTS2", "OpenLit(lil toon)" });
            DrawEnumOverrideSetting(
                overridesProperty.FindPropertyRelative(nameof(PoiLightChangerOverrideSettings.LightMapMode)),
                Tr("ライトマップモード", "Light Map Mode"),
                new[] { "Poi Custom", "Normalized NDotL", "Saturated NDotL", "Casted Shadows Only", "SDF" });
            DrawEnumOverrideSetting(
                overridesProperty.FindPropertyRelative(nameof(PoiLightChangerOverrideSettings.LightDirectionMode)),
                Tr("光方向モード", "Light Direction Mode"),
                new[] { "Poi Custom", "Forced Local Direction", "Forced World Direction", "UTS2", "OpenLit(lil toon)", "View Direction" });
            DrawBoolOverrideSetting(
                overridesProperty.FindPropertyRelative(nameof(PoiLightChangerOverrideSettings.Ltcgi)),
                "LTCGI");
            DrawBoolOverrideSetting(
                overridesProperty.FindPropertyRelative(nameof(PoiLightChangerOverrideSettings.NearClipForce)),
                Tr("ニアクリップを強制", "Reduce Clip Distance"));
            DrawWorldAoBlockOverride(
                overridesProperty.FindPropertyRelative(nameof(PoiLightChangerOverrideSettings.WorldAOBlock)),
                Tr("ワールドAOブロッカー", "World AO Blocker"));
        }

        private void DrawBoolOverrideSetting(SerializedProperty property, string label)
        {
            if (property == null)
                return;

            var enable = property.FindPropertyRelative(nameof(PoiLightChangerBoolOverrideValue.Enable));
            var value = property.FindPropertyRelative(nameof(PoiLightChangerBoolOverrideValue.Value));
            bool isEnabled = enable.boolValue;

            var headerState = BeginPoiLikeSubsection(
                new GUIContent(label),
                property,
                enable,
                ref isEnabled,
                menuCallback: menu => AddPropertyMenuItems(
                    menu,
                    new[] { property.propertyPath },
                    () => ResetSerializedProperty(property.serializedObject, property.propertyPath)));
            if (!headerState.Expanded)
                return;

            using (new EditorGUI.DisabledScope(!isEnabled))
            {
                EditorGUILayout.Space();
                GUILayout.BeginHorizontal();
                GUILayout.Space(30f);
                EditorGUILayout.BeginVertical();

                var row = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
                DrawBoolDropdown(row, Tr("設定値", "Value"), value);

                EditorGUILayout.EndVertical();
                GUILayout.EndHorizontal();
            }

            EndPoiLikeSubsection();
        }

        private void DrawEnumOverrideSetting(SerializedProperty property, string label, string[] options)
        {
            if (property == null)
                return;

            var enable = property.FindPropertyRelative(nameof(PoiLightChangerIntOverrideValue.Enable));
            var value = property.FindPropertyRelative(nameof(PoiLightChangerIntOverrideValue.Value));
            bool isEnabled = enable.boolValue;

            var headerState = BeginPoiLikeSubsection(
                new GUIContent(label),
                property,
                enable,
                ref isEnabled,
                menuCallback: menu => AddPropertyMenuItems(
                    menu,
                    new[] { property.propertyPath },
                    () => ResetSerializedProperty(property.serializedObject, property.propertyPath)));
            if (!headerState.Expanded)
                return;

            using (new EditorGUI.DisabledScope(!isEnabled))
            {
                EditorGUILayout.Space();
                GUILayout.BeginHorizontal();
                GUILayout.Space(30f);
                EditorGUILayout.BeginVertical();

                var row = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
                DrawIntPopup(row, Tr("設定値", "Value"), value, options);

                EditorGUILayout.EndVertical();
                GUILayout.EndHorizontal();
            }

            EndPoiLikeSubsection();
        }

        private void DrawWorldAoBlockOverride(SerializedProperty property, string label)
        {
            if (property == null)
                return;

            var enable = property.FindPropertyRelative(nameof(PoiLightChangerWorldAoBlockOverrideValue.Enable));
            var enabledValue = property.FindPropertyRelative(nameof(PoiLightChangerWorldAoBlockOverrideValue.Enabled));
            var uvChannel = property.FindPropertyRelative(nameof(PoiLightChangerWorldAoBlockOverrideValue.UVChannel));
            var flipNormal = property.FindPropertyRelative(nameof(PoiLightChangerWorldAoBlockOverrideValue.FlipNormal));
            bool isEnabled = enable.boolValue;

            var headerState = BeginPoiLikeSubsection(
                new GUIContent(label),
                property,
                enable,
                ref isEnabled,
                menuCallback: menu => AddPropertyMenuItems(
                    menu,
                    new[] { property.propertyPath },
                    () => ResetSerializedProperty(property.serializedObject, property.propertyPath)));
            if (!headerState.Expanded)
                return;

            using (new EditorGUI.DisabledScope(!isEnabled))
            {
                EditorGUILayout.Space();
                GUILayout.BeginHorizontal();
                GUILayout.Space(30f);
                EditorGUILayout.BeginVertical();

                var row1 = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
                DrawBoolDropdown(row1, Tr("有効", "Enabled"), enabledValue);
                var row2 = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
                DrawIntPopup(row2, Tr("UVチャンネル", "UV Channel"), uvChannel, new[] { "UV0", "UV1", "UV2", "UV3" });
                var row3 = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
                DrawBoolDropdown(row3, Tr("法線反転", "Flip Normal"), flipNormal);

                EditorGUILayout.EndVertical();
                GUILayout.EndHorizontal();
            }

            EndPoiLikeSubsection();
        }

        private void DrawBoolDropdown(
            Rect position,
            string label,
            SerializedProperty valueProp,
            string[] options = null)
        {
            DrawBoolDropdown(position, label, valueProp, EditorStyles.label, options);
        }

        private void DrawBoolDropdown(
            Rect position,
            string label,
            SerializedProperty valueProp,
            GUIStyle labelStyle,
            string[] options = null)
        {
            var indexPropValue = valueProp.boolValue ? 1 : 0;
            ResolveFixedPopupLayout(position, out var labelRect, out var popupRect);

            EditorGUI.LabelField(labelRect, label, labelStyle);
            EditorGUI.BeginChangeCheck();
            int selectedIndex = EditorGUI.Popup(popupRect, indexPropValue, options ?? GetBoolOptions());
            if (EditorGUI.EndChangeCheck())
            {
                valueProp.boolValue = selectedIndex != 0;
            }
        }

        private static void DrawIntPopup(Rect position, string label, SerializedProperty valueProp, string[] options)
        {
            ResolveFixedPopupLayout(position, out var labelRect, out var popupRect);

            EditorGUI.LabelField(labelRect, label);
            EditorGUI.BeginChangeCheck();
            int selectedIndex = EditorGUI.Popup(popupRect, Mathf.Clamp(valueProp.intValue, 0, options.Length - 1), options);
            if (EditorGUI.EndChangeCheck())
            {
                valueProp.intValue = selectedIndex;
            }
        }

        private static void DrawIntValuePopup(Rect position, string label, SerializedProperty valueProp, string[] options, int baseValue)
        {
            ResolveFixedPopupLayout(position, out var labelRect, out var popupRect);

            EditorGUI.LabelField(labelRect, label);
            var selectedIndex = Mathf.Clamp(valueProp.intValue - baseValue, 0, options.Length - 1);
            EditorGUI.BeginChangeCheck();
            selectedIndex = EditorGUI.Popup(popupRect, selectedIndex, options);
            if (EditorGUI.EndChangeCheck())
            {
                valueProp.intValue = selectedIndex + baseValue;
            }
        }

        private void DrawLightDirectionSection()
        {
            DrawLightDirectionToggleModeDropdown(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.LightDirectionToggleMode)));
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.LightDirectionToggle)),
                Tr("トグル", "Toggle"), 0f, 1f, hideRange: true, valueLabel: Tr("初期値", "Default"), step: 1f, options: GetBoolOptions(), lockEnable: true);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.LightDirectionX)),
                "X", 0f, 1f, hideRange: true, lockEnable: true);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.LightDirectionY)),
                "Y", 0f, 1f, hideRange: true, lockEnable: true);
        }

        private void DrawColorSection()
        {
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.PPHueSelectOrShift)),
                Tr("色相選択 / 色相シフト", "Hue Select Or Shift"), 0f, 1f, hideRange: true, valueLabel: Tr("初期値", "Default"), step: 1f, options: new[] { Tr("色相選択", "Hue Select"), Tr("色相シフト", "Hue Shift") });
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.PPHue)),
                Tr("色相", "Hue"), 0f, 1f, hideRange: true);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.PPContrast)),
                Tr("コントラスト", "Contrast"), 0f, 2f, hardMin: 0f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.PPSaturation)),
                Tr("彩度", "Saturation"), 0f, 2f, hardMin: 0f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.PPBrightness)),
                Tr("明るさ", "Brightness"), 0f, 2f, hardMin: 0f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.PPLightness)),
                Tr("明度", "Lightness"), -1f, 1f, hardMin: float.MinValue, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.PPHDR)),
                "HDR", -1f, 1f, hardMin: float.MinValue, hardMax: float.MaxValue);
        }

        private void DrawSSAOSection()
        {
            DrawSectionFeatureModeDropdown(PoiLightChangerControlSectionId.SSAO);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.SSAOAnimationToggle)),
                Tr("トグル", "Toggle"),
                0f,
                1f,
                hideRange: true,
                valueLabel: Tr("初期値", "Default"),
                step: 1f,
                options: GetBoolOptions(),
                drawAdditionalFields: () =>
                {
                    DrawDepthLightField(
                        poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.SSAOLinkedObject)),
                        Tr("DepthLight", "DepthLight"));
                },
                drawAfterOptions: DrawDepthLightHelpBox);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.SSAOIntensity)),
                Tr("強度", "Intensity"), 0f, 5f, hardMin: 0f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.SSAORadius)),
                Tr("半径", "Radius"), 0.0001f, 0.02f, hardMin: 0.0001f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.SSAOQuality)),
                Tr("品質", "Quality"), 1f, 10f, hardMin: 1f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.SSAOCenterImportance)),
                Tr("中心重み", "Center Importance"), 0f, 1f);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.SSAOBias)),
                Tr("深度バイアス", "Depth Bias"), 0f, 0.2f, hardMin: 0f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.SSAOCone)),
                Tr("コーンバイアス", "Cone Bias"), 0f, 1f);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.SSAORandomScale)),
                Tr("ランダムジッター", "Random Jitter"), 0f, 1f);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.SSAOUseNormals)),
                Tr("法線を使用", "Use Normals"), 0f, 1f, hideRange: true, valueLabel: Tr("初期値", "Default"), step: 1f, options: GetBoolOptions());
        }

        private void DrawContactShadowSection()
        {
            DrawSectionFeatureModeDropdown(PoiLightChangerControlSectionId.ContactShadow);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.ContactShadowAnimationToggle)),
                Tr("トグル", "Toggle"),
                0f,
                1f,
                hideRange: true,
                valueLabel: Tr("初期値", "Default"),
                step: 1f,
                options: GetBoolOptions());
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.ContactShadowIntensity)),
                Tr("影の強度", "Shadow Intensity"), 0f, 1f, hardMin: 0f, hardMax: 1f);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.ContactShadowMaxDistance)),
                Tr("最大距離", "Max Distance"), 0.001f, 0.2f, hardMin: 0.001f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.ContactShadowQuality)),
                Tr("品質", "Quality"), 1f, 10f, hardMin: 1f, hardMax: 10f);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.ContactShadowThickness)),
                Tr("厚み", "Thickness"), 0.0001f, 0.05f, hardMin: 0.0001f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.ContactShadowBias)),
                Tr("深度バイアス", "Depth Bias"), 0f, 0.05f, hardMin: 0f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.ContactShadowNormalBias)),
                Tr("法線リジェクション", "Normal Rejection"), 0f, 1f, hardMin: 0f, hardMax: 1f);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.ContactShadowHideInLight)),
                Tr("明部で軽減", "Hide In Light"), 0f, 1f, hardMin: 0f, hardMax: 1f);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.ContactShadowNoiseScale)),
                Tr("ディザノイズ", "Dither Noise"), 0f, 1f, hardMin: 0f, hardMax: 1f);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.ContactShadowRejectionDepth)),
                Tr("除外深度", "Rejection Depth"), 0.001f, 1f, hardMin: 0.001f, hardMax: float.MaxValue);
        }

        private void DrawSquishSection()
        {
            DrawSectionFeatureModeDropdown(PoiLightChangerControlSectionId.Squish);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.SquishAnimationToggle)),
                Tr("トグル", "Toggle"),
                0f,
                1f,
                hideRange: true,
                valueLabel: Tr("初期値", "Default"),
                step: 1f,
                options: GetBoolOptions());
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.SquishMax)),
                Tr("最大量", "Max Squish"), 0.01f, 1f, hardMin: 0.01f, hardMax: 1f);
        }

        private void DrawProximitySection()
        {
            DrawSectionFeatureModeDropdown(PoiLightChangerControlSectionId.Proximity);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.ProximityToggle)),
                Tr("トグル", "Toggle"), 0f, 1f, hideRange: true, valueLabel: Tr("初期値", "Default"), step: 1f, options: GetBoolOptions());
            DrawColorControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.ProximityColorMinColor)),
                Tr("最小時カラー", "Min Color"),
                allowHdrIntensity: false);
            DrawColorControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.ProximityColorMaxColor)),
                Tr("最大時カラー", "Max Color"),
                allowHdrIntensity: false);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.ProximityColorMinDistance)),
                Tr("最小距離", "Min Distance"), 0f, 1f, hardMin: 0f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.ProximityColorMaxDistance)),
                Tr("最大距離", "Max Distance"), 0f, 1f, hardMin: 0f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.ProximityColorBackface)),
                Tr("裏面を影にする", "Backface"), 0f, 1f, hideRange: true, valueLabel: Tr("初期値", "Default"), step: 1f, options: GetBoolOptions());
            DrawIndentedHelpBox(
                Tr(
                    "Poiyomiには距離フェードを直接トグルできるパラメータがないため、距離フェード/トグルは最小距離と最大距離を0に固定する擬似制御でOn/Offを表現します。",
                    "Poiyomi does not provide a parameter to toggle Proximity directly, so PLC represents Proximity/Toggle as a pseudo toggle by forcing both Min Distance and Max Distance to 0 when Off."),
                MessageType.Info,
                SectionHelpBoxIndent);
        }

        private void DrawOutlineSection()
        {
            DrawSectionFeatureModeDropdown(PoiLightChangerControlSectionId.Outline);
            DrawStaticBoolProperty(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.RemoveOutlineTexture)),
                Tr("Outline Textureを利用しない", "Disable Outline Texture"));
            DrawIndentedHelpBox(
                Tr("すべてのマテリアルでOutline Textureを利用しません。", "Disables Outline Texture on all target materials."),
                MessageType.Info,
                SectionHelpBoxIndent);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.OutlineToggle)),
                Tr("トグル", "Toggle"), 0f, 1f, hideRange: true, valueLabel: Tr("初期値", "Default"), step: 1f, options: GetBoolOptions());
            DrawColorControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.OutlineLineColor)),
                Tr("カラー", "Line Color"),
                allowHdrIntensity: false);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.OutlineLineWidth)),
                Tr("太さ", "Line Width"), 0f, 1f, hardMin: 0f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.OutlineFixedSize)),
                Tr("距離補正を有効", "Fixed Size"), 0f, 1f, hideRange: true, valueLabel: Tr("初期値", "Default"), step: 1f, options: GetBoolOptions());
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.OutlineFixWidth)),
                Tr("距離補正", "Fix Width"), 0f, 1f);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.OutlineEmission)),
                Tr("エミッション", "Emission"), 0f, 5f, hardMin: 0f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.OutlineOffsetZ)),
                Tr("Zオフセット", "Offset Z"), 0f, 25f, hardMin: float.MinValue, hardMax: float.MaxValue);
            DrawIndentedHelpBox(
                Tr(
                    "Poiyomiには輪郭線を直接トグルできるパラメータがないため、輪郭線/トグルは太さを0にする擬似制御でOn/Offを表現します。",
                    "Poiyomi does not provide a parameter to toggle Outline directly, so PLC represents Outline/Toggle as a pseudo toggle by forcing Line Width to 0 when Off."),
                MessageType.Info,
                SectionHelpBoxIndent);
        }

        private void DrawBacklightSection()
        {
            DrawSectionFeatureModeDropdown(PoiLightChangerControlSectionId.Backlight);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.BacklightToggle)),
                Tr("トグル", "Toggle"), 0f, 1f, hideRange: true, valueLabel: Tr("初期値", "Default"), step: 1f, options: GetBoolOptions());
            DrawColorControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.BacklightColor)),
                Tr("カラー", "Color"));
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.BacklightMainStrength)),
                Tr("メインカラーの強度", "Main Color Blend"), 0f, 1f);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.BacklightBorder)),
                Tr("境界", "Border"), 0f, 1f);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.BacklightBlur)),
                Tr("ぼかし", "Blur"), 0f, 1f);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.BacklightDirectivity)),
                Tr("指向性", "Directivity"), 0f, 10f, hardMin: 0f, hardMax: float.MaxValue);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.BacklightViewStrength)),
                Tr("視線方向の強さ", "View direction strength"), 0f, 1f);
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.BacklightReceiveShadow)),
                Tr("影を受け取る", "Receive Shadow"), 0f, 1f, hideRange: true, valueLabel: Tr("初期値", "Default"), step: 1f, options: GetBoolOptions());
            DrawFloatControl(
                poiyomiProperty.FindPropertyRelative(nameof(PoiLightChangerPoiyomiSettings.BacklightBackfaceMask)),
                Tr("裏面で無効化", "Backface Mask"), 0f, 1f, hideRange: true, valueLabel: Tr("初期値", "Default"), step: 1f, options: GetBoolOptions());
            DrawIndentedHelpBox(
                Tr(
                    "Poiyomiには逆光ライトを直接トグルできるパラメータがないため、逆光ライト/トグルは境界を100%に固定する擬似制御でOn/Offを表現します。",
                    "Poiyomi does not provide a parameter to toggle Backlight directly, so PLC represents Backlight/Toggle as a pseudo toggle by forcing Border to 100% when Off."),
                MessageType.Info,
                SectionHelpBoxIndent);
        }

        private static void DrawToggleRight(SerializedProperty prop, GUIContent label, bool disabled = false)
        {
            var rect      = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
            DrawToggleRight(rect, prop, label, disabled);
        }

        private static void DrawToggleRight(Rect rect, SerializedProperty prop, GUIContent label, bool disabled = false)
        {
            float toggleW = 16f;
            float rightPadding = 4f;
            var labelRect  = new Rect(rect.x, rect.y, rect.width - toggleW - rightPadding - 2f, rect.height);
            var toggleRect = new Rect(rect.xMax - toggleW - rightPadding, rect.y, toggleW, rect.height);

            using (new EditorGUI.DisabledScope(disabled))
            {
                EditorGUI.LabelField(labelRect, label);
                EditorGUI.BeginChangeCheck();
                bool v = EditorGUI.Toggle(toggleRect, prop.boolValue);
                if (EditorGUI.EndChangeCheck())
                    prop.boolValue = v;
            }
        }

        private void DrawStaticBoolProperty(SerializedProperty prop, string label)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Space(15f);
            EditorGUILayout.BeginVertical();

            var row = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
            DrawBoolDropdown(row, label, prop, EditorStyles.label);

            EditorGUILayout.EndVertical();
            GUILayout.EndHorizontal();
        }

        private static void DrawEnumPropertyPopup(SerializedProperty prop, GUIContent label, string[] options = null)
        {
            if (prop == null)
            {
                return;
            }

            var row = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
            ResolveFixedPopupLayout(row, out var labelRect, out var popupRect);

            EditorGUI.LabelField(labelRect, label);
            EditorGUI.BeginChangeCheck();
            int selectedIndex = EditorGUI.Popup(popupRect, prop.enumValueIndex, options ?? prop.enumDisplayNames);
            if (EditorGUI.EndChangeCheck())
            {
                prop.enumValueIndex = selectedIndex;
            }
        }

        private static void DrawExplicitEnumValuePopup(SerializedProperty prop, GUIContent label, string[] options, int[] optionValues)
        {
            if (prop == null || options == null || optionValues == null || options.Length == 0 || options.Length != optionValues.Length)
            {
                return;
            }

            var row = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
            ResolveFixedPopupLayout(row, out var labelRect, out var popupRect);

            EditorGUI.LabelField(labelRect, label);
            var selectedIndex = System.Array.IndexOf(optionValues, prop.intValue);
            if (selectedIndex < 0)
            {
                selectedIndex = 0;
            }

            EditorGUI.BeginChangeCheck();
            selectedIndex = EditorGUI.Popup(popupRect, selectedIndex, options);
            if (EditorGUI.EndChangeCheck())
            {
                prop.intValue = optionValues[Mathf.Clamp(selectedIndex, 0, optionValues.Length - 1)];
            }
        }

        private static string DrawFixedLayoutTextField(string label, string value, float labelWidthRatio = 0.5f)
        {
            var row = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
            ResolveProportionalLayout(row, Mathf.Clamp01(labelWidthRatio), out var labelRect, out var fieldRect);
            EditorGUI.LabelField(labelRect, label);
            return EditorGUI.TextField(fieldRect, value ?? string.Empty);
        }

        private void DrawMaterialFeatureModeDropdown(SerializedProperty property, string japaneseLabel, string englishLabel)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Space(15f);
            EditorGUILayout.BeginVertical();

            DrawEnumPropertyPopup(
                property,
                Tg(japaneseLabel, englishLabel),
                GetMaterialFeatureModeOptions());

            EditorGUILayout.EndVertical();
            GUILayout.EndHorizontal();
        }

        private void DrawLightDirectionToggleModeDropdown(SerializedProperty property)
        {
            if (property == null)
            {
                return;
            }

            GUILayout.BeginHorizontal();
            GUILayout.Space(15f);
            EditorGUILayout.BeginVertical();

            DrawExplicitEnumValuePopup(
                property,
                Tg("光源の向きのモード", "Light Direction Mode"),
                GetLightDirectionModeOptions(),
                new[]
                {
                    (int)PoiLightChangerLightDirectionToggleMode.World,
                    (int)PoiLightChangerLightDirectionToggleMode.Local,
                });

            EditorGUILayout.EndVertical();
            GUILayout.EndHorizontal();
        }

        private void DrawSectionFeatureModeDropdown(PoiLightChangerControlSectionId sectionId)
        {
            var propertyName = PoiLightChangerControlRegistry.GetSectionFeatureModePropertyName(sectionId);
            if (string.IsNullOrWhiteSpace(propertyName) || poiyomiProperty == null)
            {
                return;
            }

            var property = poiyomiProperty.FindPropertyRelative(propertyName);
            if (property == null)
            {
                return;
            }

            DrawMaterialFeatureModeDropdown(
                property,
                PoiLightChangerControlRegistry.GetSectionFeatureModeLabelJapanese(sectionId),
                PoiLightChangerControlRegistry.GetSectionFeatureModeLabelEnglish(sectionId));
        }

        private static void DrawIndentedHelpBox(string text, MessageType messageType, float leftPadding = 30f)
        {
            GUILayout.BeginHorizontal();
            GUILayout.Space(leftPadding);
            EditorGUILayout.BeginVertical();
            EditorGUILayout.HelpBox(text, messageType);
            EditorGUILayout.EndVertical();
            GUILayout.EndHorizontal();
        }

        private static void DrawCompactHelpBox(string text, MessageType messageType)
        {
            EditorGUILayout.HelpBox(text, messageType);
        }

        private void DrawDepthLightField(SerializedProperty property, string label)
        {
            if (property == null)
            {
                return;
            }

            const float bodyLabelWidth = 80f;
            const float gap = 4f;
            var autoDetectContent = new GUIContent(Tr("自動検出", "Auto Detect"));
            var autoDetectButtonWidth = Mathf.Ceil(GUI.skin.button.CalcSize(autoDetectContent).x) + 10f;

            var row = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
            ResolveInlinePopupLayout(row, bodyLabelWidth, out var labelRect, out var fieldRect);
            var objectRect = new Rect(fieldRect.x, fieldRect.y, Mathf.Max(0f, fieldRect.width - autoDetectButtonWidth - gap), fieldRect.height);
            var buttonRect = new Rect(objectRect.xMax + gap, fieldRect.y, autoDetectButtonWidth, fieldRect.height);

            EditorGUI.LabelField(labelRect, label);
            EditorGUI.BeginChangeCheck();
            var selectedObject = EditorGUI.ObjectField(objectRect, GUIContent.none, property.objectReferenceValue, typeof(GameObject), true);
            if (EditorGUI.EndChangeCheck())
            {
                property.objectReferenceValue = selectedObject;
            }

            using (new EditorGUI.DisabledScope(property.objectReferenceValue != null))
            {
                if (GUI.Button(buttonRect, autoDetectContent))
                {
                    var detectedObject = TryAutoDetectDepthLightObject();
                    if (detectedObject != null)
                    {
                        property.objectReferenceValue = detectedObject;
                    }
                }
            }

            if (property.objectReferenceValue is not GameObject depthLightObject)
            {
                return;
            }

            if (EditorUtility.IsPersistent(depthLightObject))
            {
                property.objectReferenceValue = null;
                return;
            }

            if (target is not PoiLightChangerComponent component)
            {
                property.objectReferenceValue = null;
                return;
            }

            var avatarRootObject = PoiLightChangerDiagnostics.FindAvatarRootObject(component.gameObject);
            if (avatarRootObject == null)
            {
                property.objectReferenceValue = null;
                return;
            }

            if (!depthLightObject.transform.IsChildOf(avatarRootObject.transform))
            {
                property.objectReferenceValue = null;
            }
        }

        private void DrawDepthLightHelpBox()
        {
            DrawCompactHelpBox(
                Tr(
                    "アバター内のDepthLightを選択すると同時に制御できます。",
                    "Selecting a DepthLight in this avatar lets PLC control it at the same time."),
                MessageType.Info);
        }

        private GameObject TryAutoDetectDepthLightObject()
        {
            if (target is not PoiLightChangerComponent component)
            {
                return null;
            }

            var avatarRootObject = PoiLightChangerDiagnostics.FindAvatarRootObject(component.gameObject);
            if (avatarRootObject == null)
            {
                return null;
            }

            var depthGetPrefab = FindPoiyomiDepthGetPrefabAsset();
            if (depthGetPrefab == null)
            {
                return null;
            }

            GameObject matchedObject = null;
            foreach (var transform in avatarRootObject.GetComponentsInChildren<Transform>(true))
            {
                var candidate = transform.gameObject;
                if (PrefabUtility.GetNearestPrefabInstanceRoot(candidate) != candidate)
                {
                    continue;
                }

                var sourceObject = PrefabUtility.GetCorrespondingObjectFromSource(candidate);
                if (sourceObject != depthGetPrefab)
                {
                    continue;
                }

                if (matchedObject != null)
                {
                    return null;
                }

                matchedObject = candidate;
            }

            return matchedObject;
        }

        private static GameObject FindPoiyomiDepthGetPrefabAsset()
        {
            var path = AssetDatabase.GUIDToAssetPath(PoiyomiDepthGetPrefabGuid);
            if (!string.IsNullOrWhiteSpace(path))
            {
                var asset = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (asset != null)
                {
                    return asset;
                }
            }

            foreach (var guid in AssetDatabase.FindAssets("DepthGet t:Prefab"))
            {
                path = AssetDatabase.GUIDToAssetPath(guid);
                if (!path.EndsWith("/_PoiyomiShaders/Prefabs/DepthGet.prefab", StringComparison.OrdinalIgnoreCase))
                {
                    continue;
                }

                var asset = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (asset != null)
                {
                    return asset;
                }
            }

            return null;
        }

        private static void DrawGroupHeader(string title)
        {
            EditorGUILayout.LabelField(title, EditorStyles.boldLabel);
            var rect = EditorGUILayout.GetControlRect(false, 2f);
            rect.height = 1f;
            EditorGUI.DrawRect(rect, new Color(1f, 1f, 1f, 0.08f));
        }

        private static void DrawGroupSpacing()
        {
            EditorGUILayout.Space(GroupSpacing);
        }

        private static void ResolveFixedPopupLayout(Rect position, out Rect labelRect, out Rect popupRect)
        {
            float popupWidth = Mathf.Min(PopupFieldWidth, Mathf.Max(96f, position.width * 0.5f));
            float popupX = position.xMax - popupWidth;
            float labelWidth = Mathf.Max(0f, popupX - position.x - PopupFieldGap);

            labelRect = new Rect(position.x, position.y, labelWidth, position.height);
            popupRect = new Rect(popupX, position.y, popupWidth, position.height);
        }

        private static void ResolveProportionalLayout(Rect position, float labelWidthRatio, out Rect labelRect, out Rect fieldRect)
        {
            float labelWidth = Mathf.Max(0f, (position.width - PopupFieldGap) * labelWidthRatio);
            float fieldWidth = Mathf.Max(0f, position.width - labelWidth - PopupFieldGap);
            labelRect = new Rect(position.x, position.y, labelWidth, position.height);
            fieldRect = new Rect(labelRect.xMax + PopupFieldGap, position.y, fieldWidth, position.height);
        }

        private static void ResolveInlinePopupLayout(Rect position, float bodyLabelWidth, out Rect labelRect, out Rect popupRect)
        {
            float fieldWidth = position.width - bodyLabelWidth;
            labelRect = new Rect(position.x, position.y, bodyLabelWidth, position.height);
            popupRect = new Rect(position.x + bodyLabelWidth, position.y, fieldWidth, position.height);
        }

        private void DrawFloatControl(
            SerializedProperty property,
            string label,
            float absoluteMin,
            float absoluteMax,
            bool hideRange = false,
            string valueLabel = null,
            float step = FloatStep,
            string[] options = null,
            bool lockEnable = false,
            float? hardMin = null,
            float? hardMax = null,
            System.Action drawAdditionalFields = null,
            System.Action drawAfterOptions = null)
        {
            if (property == null)
                return;

            var enable    = property.FindPropertyRelative(nameof(PoiLightChangerControlValue.Enable));
            var animation = property.FindPropertyRelative(nameof(PoiLightChangerControlValue.Animation));
            var synced    = property.FindPropertyRelative(nameof(PoiLightChangerControlValue.Synced));
            var saved     = property.FindPropertyRelative(nameof(PoiLightChangerControlValue.Saved));
            var value     = property.FindPropertyRelative(nameof(PoiLightChangerFloatControlValue.Value));
            var range     = property.FindPropertyRelative(nameof(PoiLightChangerFloatControlValue.Range));

            bool isEnabled = lockEnable || enable.boolValue;
            var  rv        = range.vector2Value;
            float lo = hideRange ? absoluteMin : rv.x;
            float hi = hideRange ? absoluteMax : Mathf.Max(rv.x + 0.001f, rv.y);
            float bodyLabelWidth = 80f;
            valueLabel ??= Tr("初期値", "Default");

            var headerState = BeginPoiLikeSubsection(
                new GUIContent(label),
                property,
                enable,
                ref isEnabled,
                lockEnable,
                menuCallback: menu => AddPropertyMenuItems(
                    menu,
                    new[] { property.propertyPath },
                    () => ResetSerializedProperty(property.serializedObject, property.propertyPath)));
            if (!headerState.Expanded)
                return;

            using (new EditorGUI.DisabledScope(!isEnabled))
            {
                DrawFloatControlBody(value, range, animation, synced, saved, lo, hi, absoluteMin, absoluteMax, bodyLabelWidth, hideRange, valueLabel, step, options, hardMin, hardMax, drawAdditionalFields, drawAfterOptions);
            }

            EndPoiLikeSubsection();
        }

        private static PoiLikeSectionState BeginPoiLikeSection(
            GUIContent label,
            string key,
            SerializedProperty enable,
            ref bool isEnabled,
            System.Action<GenericMenu> menuCallback = null,
            bool disableEnableToggle = false,
            bool visuallyDisabled = false)
        {
            Rect position = GUILayoutUtility.GetRect(label, SubsectionHeaderStyle);
            position = ApplyPoiLikeHeaderOffset(position, 0);

            using (new EditorGUI.DisabledScope(visuallyDisabled || disableEnableToggle))
            {
                DrawPoiLikeHeaderBoxAndContent(position, label, enable, ref isEnabled);
                DrawPoiLikeHeaderFoldoutArrow(position, SessionState.GetBool(key, DefaultFoldoutExpanded));
            }

            Rect? contextButtonRect = null;
            if (menuCallback != null)
            {
                using (new EditorGUI.DisabledScope(visuallyDisabled))
                {
                    contextButtonRect = DrawContextMenuButton(position);
                }
            }

            bool expanded = HandlePoiLikeSectionInput(position, key, excludeCheckbox: true, menuCallback, contextButtonRect);

            return new PoiLikeSectionState(expanded);
        }

        private static void EndPoiLikeSection()
        {
            EditorGUILayout.Space();
        }

        private static PoiLikeSectionState BeginPoiLikeSubsection(
            GUIContent label,
            string key,
            System.Action<GenericMenu> menuCallback = null)
        {
            Rect position = GUILayoutUtility.GetRect(label, SubsectionHeaderStyle);
            position = ApplyPoiLikeHeaderOffset(position, 1);

            DrawPoiLikeHeaderBoxAndContent(position, label, reserveToggleLane: false);
            DrawPoiLikeHeaderFoldoutArrow(position, SessionState.GetBool(key, DefaultFoldoutExpanded));
            Rect? contextButtonRect = null;
            if (menuCallback != null)
                contextButtonRect = DrawContextMenuButton(position);
            bool expanded = HandlePoiLikeSectionInput(position, key, menuCallback: menuCallback, contextButtonRect: contextButtonRect);

            return new PoiLikeSectionState(expanded);
        }

        private static PoiLikeHeaderState BeginPoiLikeSubsection(
            GUIContent label,
            SerializedProperty property,
            SerializedProperty enable,
            ref bool isEnabled,
            bool hideEnableToggle = false,
            System.Action<GenericMenu> menuCallback = null)
        {
            Rect position = GUILayoutUtility.GetRect(label, SubsectionHeaderStyle);
            position = ApplyPoiLikeHeaderOffset(position, 1);

            if (hideEnableToggle)
                DrawPoiLikeHeaderBoxAndContent(position, label, reserveToggleLane: false);
            else
                DrawPoiLikeHeaderBoxAndContent(position, label, enable, ref isEnabled);

            DrawPoiLikeHeaderFoldoutArrow(position, SessionState.GetBool(GetControlExpandedKey(property), DefaultFoldoutExpanded));
            Rect? contextButtonRect = null;
            if (menuCallback != null)
                contextButtonRect = DrawContextMenuButton(position);
            bool expanded = HandlePoiLikeHeaderInput(position, property, menuCallback, contextButtonRect);

            return new PoiLikeHeaderState(expanded);
        }

        private static void EndPoiLikeSubsection()
        {
            EditorGUILayout.Space();
        }

        private static Rect ApplyPoiLikeHeaderOffset(Rect position, int xOffset)
        {
            int xOffsetTotal = xOffset * 15 + 15;
            position.width -= xOffsetTotal - position.x;
            position.x = xOffsetTotal;
            return position;
        }

        private static void DrawPoiLikeHeaderBoxAndContent(
            Rect rect,
            GUIContent content,
            bool reserveToggleLane)
        {
            string prefix = reserveToggleLane ? "     " : string.Empty;
            GUI.Box(rect, new GUIContent(prefix + content.text, content.tooltip), SubsectionHeaderStyle);
        }

        private static void DrawPoiLikeHeaderBoxAndContent(
            Rect rect,
            GUIContent content,
            SerializedProperty enable,
            ref bool isEnabled)
        {
            DrawPoiLikeHeaderBoxAndContent(rect, content, reserveToggleLane: true);

            Rect checkboxRect = GetPoiLikeHeaderCheckboxRect(rect);

            EditorGUI.BeginChangeCheck();
            bool newEnable = EditorGUI.Toggle(checkboxRect, GUIContent.none, isEnabled);
            if (EditorGUI.EndChangeCheck())
            {
                enable.boolValue = newEnable;
                isEnabled = newEnable;
            }
        }

        private static void DrawPoiLikeHeaderFoldoutArrow(Rect rect, bool expanded)
        {
            if (Event.current.type != EventType.Repaint)
                return;

            Rect arrowRect = new RectOffset(4, 0, 0, 0).Remove(rect);
            arrowRect.height = 18;
            arrowRect.width = 13;
            EditorStyles.foldout.Draw(arrowRect, false, false, expanded, false);
        }

        private static bool HandlePoiLikeHeaderInput(
            Rect rect,
            SerializedProperty property,
            System.Action<GenericMenu> menuCallback = null,
            Rect? contextButtonRect = null)
        {
            string key = GetControlExpandedKey(property);
            bool expanded = SessionState.GetBool(key, DefaultFoldoutExpanded);
            Rect checkboxRect = GetPoiLikeHeaderCheckboxRect(rect);

            if (Event.current.type == EventType.MouseDown
                && rect.Contains(Event.current.mousePosition))
            {
                bool isContextTrigger = menuCallback != null
                    && (Event.current.button == 1 || contextButtonRect?.Contains(Event.current.mousePosition) == true);

                if (isContextTrigger)
                {
                    var menu = new GenericMenu();
                    menuCallback(menu);
                    menu.DropDown(new Rect(Event.current.mousePosition.x, Event.current.mousePosition.y, 0, 0));
                    Event.current.Use();
                }
                else if (!checkboxRect.Contains(Event.current.mousePosition) && !Event.current.alt)
                {
                    expanded = !expanded;
                    SessionState.SetBool(key, expanded);
                    Event.current.Use();
                }
            }

            return expanded;
        }

        private static Rect GetPoiLikeHeaderCheckboxRect(Rect rect)
        {
            Rect toggleLaneRect = new Rect(rect);
            toggleLaneRect.x += 5f;
            toggleLaneRect.y += 1f;
            toggleLaneRect.height -= 4f;
            toggleLaneRect.width = GUI.skin.font.fontSize * 3f;

            const float checkboxSize = 14f;
            float checkboxY = toggleLaneRect.y + Mathf.Round((toggleLaneRect.height - checkboxSize) * 0.5f);
            return new Rect(toggleLaneRect.x + 14f, checkboxY, checkboxSize, checkboxSize);
        }

        private static bool HandlePoiLikeSectionInput(
            Rect rect,
            string key,
            bool excludeCheckbox = false,
            System.Action<GenericMenu> menuCallback = null,
            Rect? contextButtonRect = null)
        {
            bool expanded = SessionState.GetBool(key, DefaultFoldoutExpanded);

            Rect checkboxRect = excludeCheckbox ? GetPoiLikeHeaderCheckboxRect(rect) : default;

            if (Event.current.type == EventType.MouseDown && rect.Contains(Event.current.mousePosition))
            {
                bool isContextTrigger = menuCallback != null
                    && (Event.current.button == 1 || contextButtonRect?.Contains(Event.current.mousePosition) == true);

                if (isContextTrigger)
                {
                    var menu = new GenericMenu();
                    menuCallback(menu);
                    menu.DropDown(new Rect(Event.current.mousePosition.x, Event.current.mousePosition.y, 0, 0));
                    Event.current.Use();
                }
                else if ((!excludeCheckbox || !checkboxRect.Contains(Event.current.mousePosition)) && !Event.current.alt)
                {
                    expanded = !expanded;
                    SessionState.SetBool(key, expanded);
                    Event.current.Use();
                }
            }

            return expanded;
        }

        private static Rect DrawContextMenuButton(Rect sectionRect)
        {
            const float size = 16f;
            var p = new Rect(sectionRect.xMax - size - 2f, sectionRect.y + 1f, size, sectionRect.height - 4f);
            if (Event.current.type == EventType.Repaint)
                GUI.Label(p, GUIContent.none, ContextMenuIconStyle);
            return p;
        }

        private void ResetPoiyomiSectionProperties(
            SerializedObject so,
            string poiyomiPath,
            PoiLightChangerControlSectionId sectionId)
        {
            var sectionEnablePropertyName = PoiLightChangerControlRegistry.GetSectionEnablePropertyName(sectionId);
            var propertyNames = PoiLightChangerControlRegistry.GetSectionPropertyNames(sectionId);
            var obj = new GameObject { hideFlags = HideFlags.HideInHierarchy | HideFlags.DontSave };
            try
            {
                using var defaultSo = new SerializedObject(obj.AddComponent<PoiLightChangerComponent>());
                Undo.RecordObject(so.targetObject, ResetLabel);
                foreach (var name in new[] { sectionEnablePropertyName }
                             .Concat(propertyNames ?? System.Array.Empty<string>()))
                {
                    var src = defaultSo.FindProperty(poiyomiPath + "." + name);
                    if (src != null)
                        so.CopyFromSerializedPropertyIfDifferent(src);
                }
                so.ApplyModifiedProperties();
            }
            finally
            {
                DestroyImmediate(obj);
            }
        }

        private void ResetSerializedProperty(SerializedObject so, string propertyPath)
        {
            if (so == null || string.IsNullOrEmpty(propertyPath))
                return;

            var obj = new GameObject { hideFlags = HideFlags.HideInHierarchy | HideFlags.DontSave };
            try
            {
                using var defaultSo = new SerializedObject(obj.AddComponent<PoiLightChangerComponent>());
                var src = defaultSo.FindProperty(propertyPath);
                if (src == null)
                    return;

                Undo.RecordObject(so.targetObject, ResetLabel);
                so.CopyFromSerializedPropertyIfDifferent(src);
                so.ApplyModifiedProperties();
            }
            finally
            {
                DestroyImmediate(obj);
            }
        }

        private void DrawFloatControlBody(
            SerializedProperty value,
            SerializedProperty range,
            SerializedProperty animation,
            SerializedProperty synced,
            SerializedProperty saved,
            float lo,
            float hi,
            float absoluteMin,
            float absoluteMax,
            float bodyLabelWidth,
            bool hideRange,
            string valueLabel = null,
            float step = FloatStep,
            string[] options = null,
            float? hardMin = null,
            float? hardMax = null,
            System.Action drawAdditionalFields = null,
            System.Action drawAfterOptions = null)
        {
            valueLabel ??= Tr("初期値", "Default");
            EditorGUILayout.Space();

            GUILayout.BeginHorizontal();
            GUILayout.Space(30f);
            EditorGUILayout.BeginVertical();

            var row1 = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
            if (options != null && options.Length > 0)
            {
                DrawValueDropdown(row1, valueLabel, value, bodyLabelWidth, options);
            }
            else
            {
                DrawValueSlider(
                    row1,
                    valueLabel,
                    value,
                    lo,
                    hi,
                    bodyLabelWidth,
                    step,
                    hardMin,
                    hardMax);
            }

            if (!hideRange)
            {
                var row2 = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
                EditorGUI.LabelField(new Rect(row2.x, row2.y, bodyLabelWidth, row2.height), Tr("操作範囲", "Range"));
                DrawMinMaxSlider(
                    new Rect(row2.x + bodyLabelWidth, row2.y, row2.width - bodyLabelWidth, row2.height),
                    value, range, absoluteMin, absoluteMax, step, hardMin, hardMax);
            }

            drawAdditionalFields?.Invoke();
            DrawOptionToggles(
                EditorGUILayout.GetControlRect(false, EditorGUIUtility.singleLineHeight),
                animation, synced, saved);
            drawAfterOptions?.Invoke();

            EditorGUILayout.EndVertical();
            GUILayout.EndHorizontal();
        }

        private static string GetControlExpandedKey(SerializedProperty property)
        {
            return "PoiLightChanger.ControlFoldout." + property.propertyPath;
        }

        private static void DrawValueDropdown(
            Rect position,
            string label,
            SerializedProperty valueProp,
            float bodyLabelWidth,
            string[] options)
        {
            ResolveInlinePopupLayout(position, bodyLabelWidth, out var labelRect, out var popupRect);

            EditorGUI.LabelField(labelRect, label);
            EditorGUI.BeginChangeCheck();
            int selectedIndex = EditorGUI.Popup(popupRect, Mathf.RoundToInt(valueProp.floatValue), options);
            if (EditorGUI.EndChangeCheck())
            {
                valueProp.floatValue = selectedIndex;
            }
        }

        private static void DrawValueSlider(
            Rect position,
            string label,
            SerializedProperty valueProp,
            float minValue,
            float maxValue,
            float bodyLabelWidth,
            float step = FloatStep,
            float? hardMin = null,
            float? hardMax = null)
        {
            float fieldWidth = Mathf.Max(position.width * 0.12f, 52f);
            float sliderX = position.x + bodyLabelWidth;
            float sliderWidth = position.width - bodyLabelWidth - fieldWidth - 4f;

            var labelRect = new Rect(position.x, position.y, bodyLabelWidth, position.height);
            var sliderRect = new Rect(sliderX, position.y, sliderWidth, position.height);
            var fieldRect = new Rect(sliderRect.xMax + 4f, position.y, fieldWidth, position.height);

            float fieldMin = hardMin ?? minValue;
            float fieldMax = hardMax ?? maxValue;

            EditorGUI.LabelField(labelRect, label);
            EditorGUI.BeginChangeCheck();
            float sliderValue = GUI.HorizontalSlider(sliderRect, valueProp.floatValue, minValue, maxValue);
            float fieldValue = DrawSteppedFloatField(fieldRect, sliderValue, fieldMin, fieldMax, step);
            if (EditorGUI.EndChangeCheck())
                valueProp.floatValue = ClampAndRound(fieldValue, fieldMin, fieldMax, step);
        }

        private static void DrawMinMaxSlider(
            Rect position,
            SerializedProperty valueProp,
            SerializedProperty rangeProp,
            float absoluteMin,
            float absoluteMax,
            float step = FloatStep,
            float? hardMin = null,
            float? hardMax = null)
        {
            var v      = rangeProp.vector2Value;
            float fw   = Mathf.Max(position.width * 0.1f, 48f);
            float pad  = 4f;

            var leftField  = new Rect(position.x, position.y, fw, position.height);
            var rightField = new Rect(position.xMax - fw, position.y, fw, position.height);
            var slider     = new Rect(
                leftField.xMax + pad,
                position.y,
                rightField.x - leftField.xMax - pad * 2f,
                position.height);
            slider.xMin += MinMaxSliderThumbPadding;
            slider.xMax -= MinMaxSliderThumbPadding;

            float fieldMin = hardMin ?? absoluteMin;
            float fieldMax = hardMax ?? absoluteMax;

            EditorGUI.BeginChangeCheck();
            float lo = DrawSteppedFloatField(leftField, v.x, fieldMin, fieldMax, step);
            float hi = DrawSteppedFloatField(rightField, v.y, fieldMin, fieldMax, step);
            EditorGUI.MinMaxSlider(
                slider, GUIContent.none,
                ref lo, ref hi,
                Mathf.Min(lo, absoluteMin),
                Mathf.Max(hi, absoluteMax));
            if (EditorGUI.EndChangeCheck())
            {
                lo = ClampAndRound(lo, fieldMin, fieldMax, step);
                hi = ClampAndRound(hi, fieldMin, fieldMax, step);
                if (hi < lo)
                    hi = lo;

                v.x = lo;
                v.y = hi;
                rangeProp.vector2Value = v;
                valueProp.floatValue = ClampAndRound(valueProp.floatValue, lo, hi, step);
            }
        }

        private static float ClampAndRound(float value, float minValue, float maxValue, float step = FloatStep)
        {
            return Mathf.Clamp(Mathf.Round(value / step) * step, minValue, maxValue);
        }

        private static float DrawSteppedFloatField(Rect position, float value, float minValue, float maxValue, float step = FloatStep)
        {
            var text = EditorGUI.DelayedTextField(position, FormatSteppedValue(value, step));
            if (!float.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out float parsedValue)
                && !float.TryParse(text, NumberStyles.Float, CultureInfo.CurrentCulture, out parsedValue))
            {
                return value;
            }

            return ClampAndRound(parsedValue, minValue, maxValue, step);
        }

        private static string FormatSteppedValue(float value, float step = FloatStep)
        {
            return ClampAndRound(value, float.MinValue, float.MaxValue, step).ToString("0.###", CultureInfo.InvariantCulture);
        }

        private void DrawOptionToggles(
            Rect p,
            SerializedProperty animation,
            SerializedProperty synced,
            SerializedProperty saved)
        {
            string[] labels = GetControlToggleLabels();
            SerializedProperty[] props = { animation, synced, saved };

            float[] widths = new float[3];
            float total = 0f;
            for (int i = 0; i < 3; i++)
            {
                widths[i] = EditorStyles.toggle.CalcSize(new GUIContent(labels[i])).x + 8f;
                total += widths[i];
            }
            float spacing = 9f;
            float rightPadding = 0f;
            float contentWidth = total + spacing * 2f;
            float x = Mathf.Max(p.x + 8f, p.xMax - rightPadding - contentWidth);

            for (int i = 0; i < 3; i++)
            {
                bool disabled = i >= 1 && !animation.boolValue;
                var r = new Rect(x, p.y, widths[i], p.height);
                using (new EditorGUI.DisabledScope(disabled))
                {
                    EditorGUI.BeginChangeCheck();
                    bool v = EditorGUI.ToggleLeft(r, labels[i], props[i].boolValue);
                    if (EditorGUI.EndChangeCheck())
                        props[i].boolValue = v;
                }
                x += widths[i] + spacing;
            }
        }

        private void DrawColorControl(
            SerializedProperty property,
            string label,
            bool allowHdrIntensity = true)
        {
            if (property == null)
                return;

            var enable    = property.FindPropertyRelative(nameof(PoiLightChangerControlValue.Enable));
            var animation = property.FindPropertyRelative(nameof(PoiLightChangerControlValue.Animation));
            var synced    = property.FindPropertyRelative(nameof(PoiLightChangerControlValue.Synced));
            var saved     = property.FindPropertyRelative(nameof(PoiLightChangerControlValue.Saved));
            var value     = property.FindPropertyRelative(nameof(PoiLightChangerColorControlValue.Value));
            var range     = property.FindPropertyRelative(nameof(PoiLightChangerColorControlValue.Range));

            bool isEnabled = enable.boolValue;
            float bodyLabelWidth = 80f;

            var headerState = BeginPoiLikeSubsection(
                new GUIContent(label),
                property,
                enable,
                ref isEnabled,
                menuCallback: menu => AddPropertyMenuItems(
                    menu,
                    new[] { property.propertyPath },
                    () => ResetSerializedProperty(property.serializedObject, property.propertyPath)));
            if (!headerState.Expanded)
                return;

            using (new EditorGUI.DisabledScope(!isEnabled))
            {
                EditorGUILayout.Space();

                GUILayout.BeginHorizontal();
                GUILayout.Space(30f);
                EditorGUILayout.BeginVertical();

                var colorRect = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
                EditorGUI.LabelField(new Rect(colorRect.x, colorRect.y, bodyLabelWidth, colorRect.height), Tr("初期値", "Default"));
                EditorGUI.BeginChangeCheck();
                var newColor = EditorGUI.ColorField(
                    new Rect(colorRect.x + bodyLabelWidth, colorRect.y, colorRect.width - bodyLabelWidth, colorRect.height),
                    GUIContent.none,
                    value.colorValue,
                    true, true, true);
                if (EditorGUI.EndChangeCheck())
                    value.colorValue = allowHdrIntensity
                        ? ClampColorIntensityToRange(newColor, range.vector2Value)
                        : ClampColorToLdr(newColor);

                if (allowHdrIntensity)
                {
                    var rangeRect = EditorGUILayout.GetControlRect(true, EditorGUIUtility.singleLineHeight);
                    EditorGUI.LabelField(new Rect(rangeRect.x, rangeRect.y, bodyLabelWidth, rangeRect.height), Tr("操作範囲", "Range"));
                    DrawColorIntensityMinMaxSlider(
                        new Rect(rangeRect.x + bodyLabelWidth, rangeRect.y, rangeRect.width - bodyLabelWidth, rangeRect.height),
                        value, range);
                }

                DrawOptionToggles(
                    EditorGUILayout.GetControlRect(false, EditorGUIUtility.singleLineHeight),
                    animation, synced, saved);

                EditorGUILayout.EndVertical();
                GUILayout.EndHorizontal();
            }

            EndPoiLikeSubsection();
        }

        private static Color ClampColorToLdr(Color color)
        {
            return new Color(
                Mathf.Clamp01(color.r),
                Mathf.Clamp01(color.g),
                Mathf.Clamp01(color.b),
                Mathf.Clamp01(color.a));
        }

        private static void DrawColorIntensityMinMaxSlider(
            Rect position,
            SerializedProperty valueProp,
            SerializedProperty rangeProp)
        {
            var v = rangeProp.vector2Value;
            float absoluteMin = 0f;
            float absoluteMax = 10f;
            float hardMin = 0f;
            float hardMax = absoluteMax;
            float fw = Mathf.Max(position.width * 0.1f, 48f);
            float pad = 4f;

            var leftField  = new Rect(position.x, position.y, fw, position.height);
            var rightField = new Rect(position.xMax - fw, position.y, fw, position.height);
            var slider     = new Rect(
                leftField.xMax + pad,
                position.y,
                rightField.x - leftField.xMax - pad * 2f,
                position.height);
            slider.xMin += MinMaxSliderThumbPadding;
            slider.xMax -= MinMaxSliderThumbPadding;

            EditorGUI.BeginChangeCheck();
            float lo = DrawSteppedFloatField(leftField, v.x, hardMin, hardMax, FloatStep);
            float hi = DrawSteppedFloatField(rightField, v.y, hardMin, hardMax, FloatStep);
            EditorGUI.MinMaxSlider(
                slider, GUIContent.none,
                ref lo, ref hi,
                Mathf.Min(lo, absoluteMin),
                Mathf.Max(hi, absoluteMax));
            if (EditorGUI.EndChangeCheck())
            {
                lo = ClampAndRound(lo, hardMin, hardMax, FloatStep);
                hi = ClampAndRound(hi, hardMin, hardMax, FloatStep);
                if (hi < lo)
                    hi = lo;

                v.x = lo;
                v.y = hi;
                rangeProp.vector2Value = v;
                valueProp.colorValue = ClampColorIntensityToRange(valueProp.colorValue, v);
            }
        }

        private static Color ClampColorIntensityToRange(Color color, Vector2 range)
        {
            return PoiLightChangerControlBindingUtility.ClampBacklightColorToRange(color, range);
        }
    }
}
