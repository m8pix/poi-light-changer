using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    public enum PoiLightChangerControlSectionId
    {
        Lighting,
        LightDirection,
        Color,
        SSAO,
        ContactShadow,
        Proximity,
        Outline,
        Backlight,
    }

    public enum PoiLightChangerControlId
    {
        LightingMin,
        LightingMax,
        LightingMonochromatic,
        PPLightingMultiplier,
        PPLightingAddition,
        PPEmissionMultiplier,
        PPFinalColorMultiplier,
        LightDirectionToggle,
        LightDirectionX,
        LightDirectionY,
        PPHueSelectOrShift,
        PPHue,
        PPContrast,
        PPSaturation,
        PPBrightness,
        PPLightness,
        PPHDR,
        SSAOAnimationToggle,
        SSAOIntensity,
        SSAORadius,
        SSAOQuality,
        SSAOCenterImportance,
        SSAOBias,
        SSAOCone,
        SSAORandomScale,
        SSAOUseNormals,
        ContactShadowAnimationToggle,
        ContactShadowIntensity,
        ContactShadowMaxDistance,
        ContactShadowQuality,
        ContactShadowThickness,
        ContactShadowBias,
        ContactShadowNormalBias,
        ContactShadowHideInLight,
        ContactShadowNoiseScale,
        ContactShadowRejectionDepth,
        ProximityToggle,
        ProximityColorMinColor,
        ProximityColorMaxColor,
        ProximityColorMinDistance,
        ProximityColorMaxDistance,
        ProximityColorBackface,
        OutlineToggle,
        OutlineLineColor,
        OutlineLineWidth,
        OutlineFixedSize,
        OutlineFixWidth,
        OutlineEmission,
        OutlineOffsetZ,
        BacklightColor,
        BacklightToggle,
        BacklightMainStrength,
        BacklightBorder,
        BacklightBlur,
        BacklightDirectivity,
        BacklightViewStrength,
        BacklightReceiveShadow,
        BacklightBackfaceMask,
    }

    public enum PoiLightChangerControlKind
    {
        Scalar,
        Toggle,
        NormalizedColor,
        HdrColor,
        VectorComposite,
        PseudoToggle,
        LinkedToggle,
    }

    public sealed class PoiLightChangerControlMetadata
    {
        public PoiLightChangerControlKind Kind { get; set; }

        public string InspectorLabelJapanese { get; set; }

        public string InspectorLabelEnglish { get; set; }

        public string MenuLabelJapanese { get; set; }

        public string MenuLabelEnglish { get; set; }
    }

    public sealed class PoiLightChangerControlDefinition
    {
        public PoiLightChangerControlDefinition(
            PoiLightChangerControlId id,
            string menuPath,
            string parameterSuffix,
            string processorKey,
            string materialPropertyName,
            bool implementedInCurrentBuild,
            AnimatorControllerParameterType parameterType,
            Func<PoiLightChangerComponent, IPoiLightChangerControlValue> accessor)
        {
            Id = id;
            MenuPath = menuPath;
            ParameterSuffix = parameterSuffix;
            ProcessorKey = processorKey;
            MaterialPropertyName = materialPropertyName;
            ImplementedInCurrentBuild = implementedInCurrentBuild;
            ParameterType = parameterType;
            Accessor = accessor;
        }

        public PoiLightChangerControlId Id { get; }

        public string MenuPath { get; }

        public string ParameterSuffix { get; }

        public string ProcessorKey { get; }

        public string MaterialPropertyName { get; }

        public bool ImplementedInCurrentBuild { get; }

        public AnimatorControllerParameterType ParameterType { get; }

        public PoiLightChangerControlKind ControlKind => PoiLightChangerControlRegistry.GetControlMetadata(Id).Kind;

        public string InspectorLabelJapanese => PoiLightChangerControlRegistry.GetControlMetadata(Id).InspectorLabelJapanese;

        public string InspectorLabelEnglish => PoiLightChangerControlRegistry.GetControlMetadata(Id).InspectorLabelEnglish;

        public string MenuLabelJapanese => PoiLightChangerControlRegistry.GetControlMetadata(Id).MenuLabelJapanese;

        public string MenuLabelEnglish => PoiLightChangerControlRegistry.GetControlMetadata(Id).MenuLabelEnglish;

        private Func<PoiLightChangerComponent, IPoiLightChangerControlValue> Accessor { get; }

        public IPoiLightChangerControlValue GetControl(PoiLightChangerComponent component)
        {
            if (component == null)
            {
                return null;
            }

            return Accessor(component);
        }
    }

    public sealed class PoiLightChangerControlSectionDefinition
    {
        public PoiLightChangerControlSectionDefinition(
            PoiLightChangerControlSectionId id,
            string enablePropertyName,
            Func<PoiLightChangerComponent, bool> isEnabled,
            IReadOnlyList<string> propertyNames = null,
            string inspectorTitleJapanese = null,
            string inspectorTitleEnglish = null,
            string featureModePropertyName = null,
            string featureModeLabelJapanese = null,
            string featureModeLabelEnglish = null)
        {
            Id = id;
            EnablePropertyName = enablePropertyName;
            IsEnabled = isEnabled;
            PropertyNames = propertyNames ?? Array.Empty<string>();
            InspectorTitleJapanese = inspectorTitleJapanese ?? string.Empty;
            InspectorTitleEnglish = inspectorTitleEnglish ?? string.Empty;
            FeatureModePropertyName = featureModePropertyName ?? string.Empty;
            FeatureModeLabelJapanese = featureModeLabelJapanese ?? string.Empty;
            FeatureModeLabelEnglish = featureModeLabelEnglish ?? string.Empty;
        }

        public PoiLightChangerControlSectionId Id { get; }

        public string EnablePropertyName { get; }

        public IReadOnlyList<string> PropertyNames { get; }

        public string InspectorTitleJapanese { get; }

        public string InspectorTitleEnglish { get; }

        public string FeatureModePropertyName { get; }

        public string FeatureModeLabelJapanese { get; }

        public string FeatureModeLabelEnglish { get; }

        private Func<PoiLightChangerComponent, bool> IsEnabled { get; }

        public bool EvaluateIsEnabled(PoiLightChangerComponent component)
        {
            return IsEnabled?.Invoke(component) ?? false;
        }
    }

    public static class PoiLightChangerControlRegistry
    {
        private static readonly IReadOnlyDictionary<PoiLightChangerControlSectionId, PoiLightChangerControlSectionDefinition> SectionDefinitions =
            new Dictionary<PoiLightChangerControlSectionId, PoiLightChangerControlSectionDefinition>
            {
                [PoiLightChangerControlSectionId.Lighting] = new(
                    PoiLightChangerControlSectionId.Lighting,
                    nameof(PoiLightChangerPoiyomiSettings.EnableLightingControl),
                    component => component?.Poiyomi?.EnableLightingControl ?? false,
                    new[]
                    {
                        nameof(PoiLightChangerPoiyomiSettings.MinBrightness),
                        nameof(PoiLightChangerPoiyomiSettings.LightingMax),
                        nameof(PoiLightChangerPoiyomiSettings.LightingMonochromatic),
                        nameof(PoiLightChangerPoiyomiSettings.PPLightingMultiplier),
                        nameof(PoiLightChangerPoiyomiSettings.PPLightingAddition),
                        nameof(PoiLightChangerPoiyomiSettings.PPEmissionMultiplier),
                        nameof(PoiLightChangerPoiyomiSettings.PPFinalColorMultiplier),
                    },
                    inspectorTitleJapanese: "ライティング",
                    inspectorTitleEnglish: "Lighting"),
                [PoiLightChangerControlSectionId.LightDirection] = new(
                    PoiLightChangerControlSectionId.LightDirection,
                    nameof(PoiLightChangerPoiyomiSettings.EnableLightDirectionControl),
                    component => component?.Poiyomi?.EnableLightDirectionControl ?? false,
                    new[]
                    {
                        nameof(PoiLightChangerPoiyomiSettings.LightDirectionToggle),
                        nameof(PoiLightChangerPoiyomiSettings.LightDirectionX),
                        nameof(PoiLightChangerPoiyomiSettings.LightDirectionY),
                    },
                    inspectorTitleJapanese: "光源の向き",
                    inspectorTitleEnglish: "Light Direction"),
                [PoiLightChangerControlSectionId.Color] = new(
                    PoiLightChangerControlSectionId.Color,
                    nameof(PoiLightChangerPoiyomiSettings.EnableColorControl),
                    component => component?.Poiyomi?.EnableColorControl ?? false,
                    new[]
                    {
                        nameof(PoiLightChangerPoiyomiSettings.PPHueSelectOrShift),
                        nameof(PoiLightChangerPoiyomiSettings.PPHue),
                        nameof(PoiLightChangerPoiyomiSettings.PPContrast),
                        nameof(PoiLightChangerPoiyomiSettings.PPSaturation),
                        nameof(PoiLightChangerPoiyomiSettings.PPBrightness),
                        nameof(PoiLightChangerPoiyomiSettings.PPLightness),
                        nameof(PoiLightChangerPoiyomiSettings.PPHDR),
                    },
                    inspectorTitleJapanese: "カラー",
                    inspectorTitleEnglish: "Color"),
                [PoiLightChangerControlSectionId.SSAO] = new(
                    PoiLightChangerControlSectionId.SSAO,
                    nameof(PoiLightChangerPoiyomiSettings.EnableSSAOControl),
                    component => component?.Poiyomi?.EnableSSAOControl ?? false,
                    new[]
                    {
                        nameof(PoiLightChangerPoiyomiSettings.SSAOFeatureMode),
                        nameof(PoiLightChangerPoiyomiSettings.SSAOAnimationToggle),
                        nameof(PoiLightChangerPoiyomiSettings.SSAOLinkedObject),
                        nameof(PoiLightChangerPoiyomiSettings.SSAOIntensity),
                        nameof(PoiLightChangerPoiyomiSettings.SSAORadius),
                        nameof(PoiLightChangerPoiyomiSettings.SSAOQuality),
                        nameof(PoiLightChangerPoiyomiSettings.SSAOCenterImportance),
                        nameof(PoiLightChangerPoiyomiSettings.SSAOBias),
                        nameof(PoiLightChangerPoiyomiSettings.SSAOCone),
                        nameof(PoiLightChangerPoiyomiSettings.SSAORandomScale),
                        nameof(PoiLightChangerPoiyomiSettings.SSAOUseNormals),
                    },
                    inspectorTitleJapanese: "SSAO",
                    inspectorTitleEnglish: "SSAO",
                    featureModePropertyName: nameof(PoiLightChangerPoiyomiSettings.SSAOFeatureMode),
                    featureModeLabelJapanese: "SSAOを有効化",
                    featureModeLabelEnglish: "SSAO Enable"),
                [PoiLightChangerControlSectionId.ContactShadow] = new(
                    PoiLightChangerControlSectionId.ContactShadow,
                    nameof(PoiLightChangerPoiyomiSettings.EnableContactShadowControl),
                    component => component?.Poiyomi?.EnableContactShadowControl ?? false,
                    new[]
                    {
                        nameof(PoiLightChangerPoiyomiSettings.ContactShadowFeatureMode),
                        nameof(PoiLightChangerPoiyomiSettings.ContactShadowAnimationToggle),
                        nameof(PoiLightChangerPoiyomiSettings.ContactShadowIntensity),
                        nameof(PoiLightChangerPoiyomiSettings.ContactShadowMaxDistance),
                        nameof(PoiLightChangerPoiyomiSettings.ContactShadowQuality),
                        nameof(PoiLightChangerPoiyomiSettings.ContactShadowThickness),
                        nameof(PoiLightChangerPoiyomiSettings.ContactShadowBias),
                        nameof(PoiLightChangerPoiyomiSettings.ContactShadowNormalBias),
                        nameof(PoiLightChangerPoiyomiSettings.ContactShadowHideInLight),
                        nameof(PoiLightChangerPoiyomiSettings.ContactShadowNoiseScale),
                        nameof(PoiLightChangerPoiyomiSettings.ContactShadowRejectionDepth),
                    },
                    inspectorTitleJapanese: "コンタクトシャドウ",
                    inspectorTitleEnglish: "Contact Shadows",
                    featureModePropertyName: nameof(PoiLightChangerPoiyomiSettings.ContactShadowFeatureMode),
                    featureModeLabelJapanese: "コンタクトシャドウを有効化",
                    featureModeLabelEnglish: "Contact Shadows Enable"),
                [PoiLightChangerControlSectionId.Proximity] = new(
                    PoiLightChangerControlSectionId.Proximity,
                    nameof(PoiLightChangerPoiyomiSettings.EnableProximityControl),
                    component => component?.Poiyomi?.EnableProximityControl ?? false,
                    new[]
                    {
                        nameof(PoiLightChangerPoiyomiSettings.ProximityFeatureMode),
                        nameof(PoiLightChangerPoiyomiSettings.ProximityToggle),
                        nameof(PoiLightChangerPoiyomiSettings.ProximityColorMinColor),
                        nameof(PoiLightChangerPoiyomiSettings.ProximityColorMaxColor),
                        nameof(PoiLightChangerPoiyomiSettings.ProximityColorMinDistance),
                        nameof(PoiLightChangerPoiyomiSettings.ProximityColorMaxDistance),
                        nameof(PoiLightChangerPoiyomiSettings.ProximityColorBackface),
                    },
                    inspectorTitleJapanese: "距離フェード",
                    inspectorTitleEnglish: "Proximity",
                    featureModePropertyName: nameof(PoiLightChangerPoiyomiSettings.ProximityFeatureMode),
                    featureModeLabelJapanese: "距離フェードを有効化",
                    featureModeLabelEnglish: "Proximity Enable"),
                [PoiLightChangerControlSectionId.Outline] = new(
                    PoiLightChangerControlSectionId.Outline,
                    nameof(PoiLightChangerPoiyomiSettings.EnableOutlineControl),
                    component => component?.Poiyomi?.EnableOutlineControl ?? false,
                    new[]
                    {
                        nameof(PoiLightChangerPoiyomiSettings.OutlineFeatureMode),
                        nameof(PoiLightChangerPoiyomiSettings.RemoveOutlineTexture),
                        nameof(PoiLightChangerPoiyomiSettings.OutlineToggle),
                        nameof(PoiLightChangerPoiyomiSettings.OutlineLineColor),
                        nameof(PoiLightChangerPoiyomiSettings.OutlineLineWidth),
                        nameof(PoiLightChangerPoiyomiSettings.OutlineFixedSize),
                        nameof(PoiLightChangerPoiyomiSettings.OutlineFixWidth),
                        nameof(PoiLightChangerPoiyomiSettings.OutlineEmission),
                        nameof(PoiLightChangerPoiyomiSettings.OutlineOffsetZ),
                    },
                    inspectorTitleJapanese: "輪郭線",
                    inspectorTitleEnglish: "Outline",
                    featureModePropertyName: nameof(PoiLightChangerPoiyomiSettings.OutlineFeatureMode),
                    featureModeLabelJapanese: "輪郭線を有効化",
                    featureModeLabelEnglish: "Outline Enable"),
                [PoiLightChangerControlSectionId.Backlight] = new(
                    PoiLightChangerControlSectionId.Backlight,
                    nameof(PoiLightChangerPoiyomiSettings.EnableBacklightControl),
                    component => component?.Poiyomi?.EnableBacklightControl ?? false,
                    new[]
                    {
                        nameof(PoiLightChangerPoiyomiSettings.BacklightFeatureMode),
                        nameof(PoiLightChangerPoiyomiSettings.BacklightToggle),
                        nameof(PoiLightChangerPoiyomiSettings.BacklightColor),
                        nameof(PoiLightChangerPoiyomiSettings.BacklightMainStrength),
                        nameof(PoiLightChangerPoiyomiSettings.BacklightBorder),
                        nameof(PoiLightChangerPoiyomiSettings.BacklightBlur),
                        nameof(PoiLightChangerPoiyomiSettings.BacklightDirectivity),
                        nameof(PoiLightChangerPoiyomiSettings.BacklightViewStrength),
                        nameof(PoiLightChangerPoiyomiSettings.BacklightReceiveShadow),
                        nameof(PoiLightChangerPoiyomiSettings.BacklightBackfaceMask),
                    },
                    inspectorTitleJapanese: "逆光ライト",
                    inspectorTitleEnglish: "Backlight",
                    featureModePropertyName: nameof(PoiLightChangerPoiyomiSettings.BacklightFeatureMode),
                    featureModeLabelJapanese: "逆光ライトを有効化",
                    featureModeLabelEnglish: "Backlight Enable"),
            };

        private static readonly IReadOnlyDictionary<PoiLightChangerControlId, PoiLightChangerControlMetadata> ControlMetadata =
            new Dictionary<PoiLightChangerControlId, PoiLightChangerControlMetadata>
            {
                [PoiLightChangerControlId.LightingMin] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "明るさの下限", "Min Brightness"),
                [PoiLightChangerControlId.LightingMax] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "明るさの上限", "Max Brightness"),
                [PoiLightChangerControlId.LightingMonochromatic] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "ライトのモノクロ化", "Monochrome Lighting"),
                [PoiLightChangerControlId.PPLightingMultiplier] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "ライティング乗数", "Lighting Multiplier"),
                [PoiLightChangerControlId.PPLightingAddition] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "ライティング加算", "Lighting Addition"),
                [PoiLightChangerControlId.PPEmissionMultiplier] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "エミッション乗数", "Emission Multiplier"),
                [PoiLightChangerControlId.PPFinalColorMultiplier] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "カラー乗数", "Final Color Multiplier"),
                [PoiLightChangerControlId.LightDirectionToggle] = CreateControlMetadata(PoiLightChangerControlKind.Toggle, "トグル", "Toggle"),
                [PoiLightChangerControlId.LightDirectionX] = CreateControlMetadata(PoiLightChangerControlKind.VectorComposite, "X", "X"),
                [PoiLightChangerControlId.LightDirectionY] = CreateControlMetadata(PoiLightChangerControlKind.VectorComposite, "Y", "Y"),
                [PoiLightChangerControlId.PPHueSelectOrShift] = CreateControlMetadata(PoiLightChangerControlKind.Toggle, "色相選択 / 色相シフト", "Hue Select Or Shift"),
                [PoiLightChangerControlId.PPHue] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "色相", "Hue"),
                [PoiLightChangerControlId.PPContrast] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "コントラスト", "Contrast"),
                [PoiLightChangerControlId.PPSaturation] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "彩度", "Saturation"),
                [PoiLightChangerControlId.PPBrightness] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "明るさ", "Brightness"),
                [PoiLightChangerControlId.PPLightness] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "明度", "Lightness"),
                [PoiLightChangerControlId.PPHDR] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "HDR", "HDR"),
                [PoiLightChangerControlId.SSAOAnimationToggle] = CreateControlMetadata(PoiLightChangerControlKind.LinkedToggle, "トグル", "Toggle"),
                [PoiLightChangerControlId.SSAOIntensity] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "強度", "Intensity"),
                [PoiLightChangerControlId.SSAORadius] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "半径", "Radius"),
                [PoiLightChangerControlId.SSAOQuality] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "品質", "Quality"),
                [PoiLightChangerControlId.SSAOCenterImportance] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "中心重み", "Center Importance"),
                [PoiLightChangerControlId.SSAOBias] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "深度バイアス", "Depth Bias"),
                [PoiLightChangerControlId.SSAOCone] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "コーンバイアス", "Cone Bias"),
                [PoiLightChangerControlId.SSAORandomScale] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "ランダムジッター", "Random Jitter"),
                [PoiLightChangerControlId.SSAOUseNormals] = CreateControlMetadata(PoiLightChangerControlKind.Toggle, "法線を使用", "Use Normals"),
                [PoiLightChangerControlId.ContactShadowAnimationToggle] = CreateControlMetadata(PoiLightChangerControlKind.Toggle, "トグル", "Toggle"),
                [PoiLightChangerControlId.ContactShadowIntensity] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "影の強度", "Shadow Intensity"),
                [PoiLightChangerControlId.ContactShadowMaxDistance] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "最大距離", "Max Distance"),
                [PoiLightChangerControlId.ContactShadowQuality] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "品質", "Quality"),
                [PoiLightChangerControlId.ContactShadowThickness] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "厚み", "Thickness"),
                [PoiLightChangerControlId.ContactShadowBias] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "深度バイアス", "Depth Bias"),
                [PoiLightChangerControlId.ContactShadowNormalBias] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "法線リジェクション", "Normal Rejection"),
                [PoiLightChangerControlId.ContactShadowHideInLight] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "明部で軽減", "Hide In Light"),
                [PoiLightChangerControlId.ContactShadowNoiseScale] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "ディザノイズ", "Dither Noise"),
                [PoiLightChangerControlId.ContactShadowRejectionDepth] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "除外深度", "Rejection Depth"),
                [PoiLightChangerControlId.ProximityToggle] = CreateControlMetadata(PoiLightChangerControlKind.PseudoToggle, "トグル", "Toggle"),
                [PoiLightChangerControlId.ProximityColorMinColor] = CreateControlMetadata(PoiLightChangerControlKind.NormalizedColor, "最小時カラー", "Min Color"),
                [PoiLightChangerControlId.ProximityColorMaxColor] = CreateControlMetadata(PoiLightChangerControlKind.NormalizedColor, "最大時カラー", "Max Color"),
                [PoiLightChangerControlId.ProximityColorMinDistance] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "最小距離", "Min Distance"),
                [PoiLightChangerControlId.ProximityColorMaxDistance] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "最大距離", "Max Distance"),
                [PoiLightChangerControlId.ProximityColorBackface] = CreateControlMetadata(PoiLightChangerControlKind.Toggle, "裏面を影にする", "Backface"),
                [PoiLightChangerControlId.OutlineToggle] = CreateControlMetadata(PoiLightChangerControlKind.PseudoToggle, "トグル", "Toggle"),
                [PoiLightChangerControlId.OutlineLineColor] = CreateControlMetadata(PoiLightChangerControlKind.NormalizedColor, "カラー", "Line Color"),
                [PoiLightChangerControlId.OutlineLineWidth] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "太さ", "Line Width"),
                [PoiLightChangerControlId.OutlineFixedSize] = CreateControlMetadata(PoiLightChangerControlKind.Toggle, "距離補正を有効", "Fixed Size"),
                [PoiLightChangerControlId.OutlineFixWidth] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "距離補正", "Fix Width"),
                [PoiLightChangerControlId.OutlineEmission] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "エミッション", "Emission"),
                [PoiLightChangerControlId.OutlineOffsetZ] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "Zオフセット", "Offset Z"),
                [PoiLightChangerControlId.BacklightColor] = CreateControlMetadata(PoiLightChangerControlKind.HdrColor, "カラー", "Color"),
                [PoiLightChangerControlId.BacklightToggle] = CreateControlMetadata(PoiLightChangerControlKind.PseudoToggle, "トグル", "Toggle"),
                [PoiLightChangerControlId.BacklightMainStrength] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "メインカラーの強度", "Main Color Blend"),
                [PoiLightChangerControlId.BacklightBorder] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "境界", "Border"),
                [PoiLightChangerControlId.BacklightBlur] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "ぼかし", "Blur"),
                [PoiLightChangerControlId.BacklightDirectivity] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "指向性", "Directivity"),
                [PoiLightChangerControlId.BacklightViewStrength] = CreateControlMetadata(PoiLightChangerControlKind.Scalar, "視線方向の強さ", "View direction strength"),
                [PoiLightChangerControlId.BacklightReceiveShadow] = CreateControlMetadata(PoiLightChangerControlKind.Toggle, "影を受け取る", "Receive Shadow"),
                [PoiLightChangerControlId.BacklightBackfaceMask] = CreateControlMetadata(PoiLightChangerControlKind.Toggle, "裏面で無効化", "Backface Mask"),
            };

        private static readonly IReadOnlyDictionary<PoiLightChangerControlId, PoiLightChangerControlSectionId> ControlSections =
            new Dictionary<PoiLightChangerControlId, PoiLightChangerControlSectionId>
            {
                [PoiLightChangerControlId.LightingMin] = PoiLightChangerControlSectionId.Lighting,
                [PoiLightChangerControlId.LightingMax] = PoiLightChangerControlSectionId.Lighting,
                [PoiLightChangerControlId.LightingMonochromatic] = PoiLightChangerControlSectionId.Lighting,
                [PoiLightChangerControlId.PPLightingMultiplier] = PoiLightChangerControlSectionId.Lighting,
                [PoiLightChangerControlId.PPLightingAddition] = PoiLightChangerControlSectionId.Lighting,
                [PoiLightChangerControlId.PPEmissionMultiplier] = PoiLightChangerControlSectionId.Lighting,
                [PoiLightChangerControlId.PPFinalColorMultiplier] = PoiLightChangerControlSectionId.Lighting,
                [PoiLightChangerControlId.LightDirectionToggle] = PoiLightChangerControlSectionId.LightDirection,
                [PoiLightChangerControlId.LightDirectionX] = PoiLightChangerControlSectionId.LightDirection,
                [PoiLightChangerControlId.LightDirectionY] = PoiLightChangerControlSectionId.LightDirection,
                [PoiLightChangerControlId.PPHueSelectOrShift] = PoiLightChangerControlSectionId.Color,
                [PoiLightChangerControlId.PPHue] = PoiLightChangerControlSectionId.Color,
                [PoiLightChangerControlId.PPContrast] = PoiLightChangerControlSectionId.Color,
                [PoiLightChangerControlId.PPSaturation] = PoiLightChangerControlSectionId.Color,
                [PoiLightChangerControlId.PPBrightness] = PoiLightChangerControlSectionId.Color,
                [PoiLightChangerControlId.PPLightness] = PoiLightChangerControlSectionId.Color,
                [PoiLightChangerControlId.PPHDR] = PoiLightChangerControlSectionId.Color,
                [PoiLightChangerControlId.SSAOAnimationToggle] = PoiLightChangerControlSectionId.SSAO,
                [PoiLightChangerControlId.SSAOIntensity] = PoiLightChangerControlSectionId.SSAO,
                [PoiLightChangerControlId.SSAORadius] = PoiLightChangerControlSectionId.SSAO,
                [PoiLightChangerControlId.SSAOQuality] = PoiLightChangerControlSectionId.SSAO,
                [PoiLightChangerControlId.SSAOCenterImportance] = PoiLightChangerControlSectionId.SSAO,
                [PoiLightChangerControlId.SSAOBias] = PoiLightChangerControlSectionId.SSAO,
                [PoiLightChangerControlId.SSAOCone] = PoiLightChangerControlSectionId.SSAO,
                [PoiLightChangerControlId.SSAORandomScale] = PoiLightChangerControlSectionId.SSAO,
                [PoiLightChangerControlId.SSAOUseNormals] = PoiLightChangerControlSectionId.SSAO,
                [PoiLightChangerControlId.ContactShadowAnimationToggle] = PoiLightChangerControlSectionId.ContactShadow,
                [PoiLightChangerControlId.ContactShadowIntensity] = PoiLightChangerControlSectionId.ContactShadow,
                [PoiLightChangerControlId.ContactShadowMaxDistance] = PoiLightChangerControlSectionId.ContactShadow,
                [PoiLightChangerControlId.ContactShadowQuality] = PoiLightChangerControlSectionId.ContactShadow,
                [PoiLightChangerControlId.ContactShadowThickness] = PoiLightChangerControlSectionId.ContactShadow,
                [PoiLightChangerControlId.ContactShadowBias] = PoiLightChangerControlSectionId.ContactShadow,
                [PoiLightChangerControlId.ContactShadowNormalBias] = PoiLightChangerControlSectionId.ContactShadow,
                [PoiLightChangerControlId.ContactShadowHideInLight] = PoiLightChangerControlSectionId.ContactShadow,
                [PoiLightChangerControlId.ContactShadowNoiseScale] = PoiLightChangerControlSectionId.ContactShadow,
                [PoiLightChangerControlId.ContactShadowRejectionDepth] = PoiLightChangerControlSectionId.ContactShadow,
                [PoiLightChangerControlId.ProximityToggle] = PoiLightChangerControlSectionId.Proximity,
                [PoiLightChangerControlId.ProximityColorMinColor] = PoiLightChangerControlSectionId.Proximity,
                [PoiLightChangerControlId.ProximityColorMaxColor] = PoiLightChangerControlSectionId.Proximity,
                [PoiLightChangerControlId.ProximityColorMinDistance] = PoiLightChangerControlSectionId.Proximity,
                [PoiLightChangerControlId.ProximityColorMaxDistance] = PoiLightChangerControlSectionId.Proximity,
                [PoiLightChangerControlId.ProximityColorBackface] = PoiLightChangerControlSectionId.Proximity,
                [PoiLightChangerControlId.OutlineToggle] = PoiLightChangerControlSectionId.Outline,
                [PoiLightChangerControlId.OutlineLineColor] = PoiLightChangerControlSectionId.Outline,
                [PoiLightChangerControlId.OutlineLineWidth] = PoiLightChangerControlSectionId.Outline,
                [PoiLightChangerControlId.OutlineFixedSize] = PoiLightChangerControlSectionId.Outline,
                [PoiLightChangerControlId.OutlineFixWidth] = PoiLightChangerControlSectionId.Outline,
                [PoiLightChangerControlId.OutlineEmission] = PoiLightChangerControlSectionId.Outline,
                [PoiLightChangerControlId.OutlineOffsetZ] = PoiLightChangerControlSectionId.Outline,
                [PoiLightChangerControlId.BacklightColor] = PoiLightChangerControlSectionId.Backlight,
                [PoiLightChangerControlId.BacklightToggle] = PoiLightChangerControlSectionId.Backlight,
                [PoiLightChangerControlId.BacklightMainStrength] = PoiLightChangerControlSectionId.Backlight,
                [PoiLightChangerControlId.BacklightBorder] = PoiLightChangerControlSectionId.Backlight,
                [PoiLightChangerControlId.BacklightBlur] = PoiLightChangerControlSectionId.Backlight,
                [PoiLightChangerControlId.BacklightDirectivity] = PoiLightChangerControlSectionId.Backlight,
                [PoiLightChangerControlId.BacklightViewStrength] = PoiLightChangerControlSectionId.Backlight,
                [PoiLightChangerControlId.BacklightReceiveShadow] = PoiLightChangerControlSectionId.Backlight,
                [PoiLightChangerControlId.BacklightBackfaceMask] = PoiLightChangerControlSectionId.Backlight,
            };

        private static readonly PoiLightChangerControlDefinition[] V1Definitions =
        {
            new(
                PoiLightChangerControlId.LightingMin,
                "Lighting/Min Brightness",
                "MinBrightness",
                "lighting.min",
                PoiLightChangerPoiyomiShaderConstants.LightingMinLightBrightness,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.MinBrightness),
            new(
                PoiLightChangerControlId.LightingMax,
                "Lighting/Max Brightness",
                "MaxBrightness",
                "lighting.max",
                PoiLightChangerPoiyomiShaderConstants.LightingCap,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.LightingMax),
            new(
                PoiLightChangerControlId.LightingMonochromatic,
                "Lighting/Grayscale",
                "Grayscale",
                "lighting.grayscale",
                PoiLightChangerPoiyomiShaderConstants.LightingMonochromatic,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.LightingMonochromatic),
            new(
                PoiLightChangerControlId.PPLightingMultiplier,
                "Lighting/PP Lighting Multiplier",
                "PPLightingMultiplier",
                "lighting.pp_lighting_multiplier",
                PoiLightChangerPoiyomiShaderConstants.PpLightingMultiplier,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.PPLightingMultiplier),
            new(
                PoiLightChangerControlId.PPLightingAddition,
                "Lighting/PP Lighting Addition",
                "PPLightingAddition",
                "lighting.pp_lighting_addition",
                PoiLightChangerPoiyomiShaderConstants.PpLightingAddition,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.PPLightingAddition),
            new(
                PoiLightChangerControlId.PPEmissionMultiplier,
                "Lighting/PP Emission Multiplier",
                "PPEmissionMultiplier",
                "lighting.pp_emission_multiplier",
                PoiLightChangerPoiyomiShaderConstants.PpEmissionMultiplier,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.PPEmissionMultiplier),
            new(
                PoiLightChangerControlId.PPFinalColorMultiplier,
                "Lighting/PP Final Color Multiplier",
                "PPFinalColorMultiplier",
                "lighting.pp_final_color_multiplier",
                PoiLightChangerPoiyomiShaderConstants.PpFinalColorMultiplier,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.PPFinalColorMultiplier),
            new(
                PoiLightChangerControlId.LightDirectionToggle,
                "Lighting/LightDirection/Toggle",
                "LightDirectionToggle",
                "lighting.light_direction_toggle",
                PoiLightChangerPoiyomiShaderConstants.LightingDirectionMode,
                true,
                AnimatorControllerParameterType.Bool,
                component => component.Poiyomi.LightDirectionToggle),
            new(
                PoiLightChangerControlId.LightDirectionX,
                "Lighting/LightDirection/X",
                "LightDirectionX",
                "lighting.light_direction_x",
                PoiLightChangerPoiyomiShaderConstants.LightngForcedDirectionX,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.LightDirectionX),
            new(
                PoiLightChangerControlId.LightDirectionY,
                "Lighting/LightDirection/Y",
                "LightDirectionY",
                "lighting.light_direction_y",
                PoiLightChangerPoiyomiShaderConstants.LightngForcedDirectionY,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.LightDirectionY),
            new(
                PoiLightChangerControlId.PPHueSelectOrShift,
                "Color/Hue Select Or Shift",
                "PPHueSelectOrShift",
                "color.pp_hue_select_or_shift",
                PoiLightChangerPoiyomiShaderConstants.PpHueSelectOrShift,
                true,
                AnimatorControllerParameterType.Bool,
                component => component.Poiyomi.PPHueSelectOrShift),
            new(
                PoiLightChangerControlId.PPHue,
                "Color/Hue",
                "PPHue",
                "color.pp_hue",
                PoiLightChangerPoiyomiShaderConstants.PpHue,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.PPHue),
            new(
                PoiLightChangerControlId.PPContrast,
                "Color/Contrast",
                "PPContrast",
                "color.pp_contrast",
                PoiLightChangerPoiyomiShaderConstants.PpContrast,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.PPContrast),
            new(
                PoiLightChangerControlId.PPSaturation,
                "Color/Saturation",
                "PPSaturation",
                "color.pp_saturation",
                PoiLightChangerPoiyomiShaderConstants.PpSaturation,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.PPSaturation),
            new(
                PoiLightChangerControlId.PPBrightness,
                "Color/Brightness",
                "PPBrightness",
                "color.pp_brightness",
                PoiLightChangerPoiyomiShaderConstants.PpBrightness,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.PPBrightness),
            new(
                PoiLightChangerControlId.PPLightness,
                "Color/Lightness",
                "PPLightness",
                "color.pp_lightness",
                PoiLightChangerPoiyomiShaderConstants.PpLightness,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.PPLightness),
            new(
                PoiLightChangerControlId.PPHDR,
                "Color/HDR",
                "PPHDR",
                "color.pp_hdr",
                PoiLightChangerPoiyomiShaderConstants.PpHdr,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.PPHDR),
            new(
                PoiLightChangerControlId.ProximityToggle,
                "Proximity/Toggle",
                "ProximityToggle",
                "proximity.toggle",
                PoiLightChangerPoiyomiShaderConstants.FxProximityColorMinDistance,
                true,
                AnimatorControllerParameterType.Bool,
                component => component.Poiyomi.ProximityToggle),
            new(
                PoiLightChangerControlId.ProximityColorMinColor,
                "Proximity/Min Color",
                "ProximityMinColor",
                "proximity.min_color",
                PoiLightChangerPoiyomiShaderConstants.FxProximityColorMinColor,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.ProximityColorMinColor),
            new(
                PoiLightChangerControlId.ProximityColorMaxColor,
                "Proximity/Max Color",
                "ProximityMaxColor",
                "proximity.max_color",
                PoiLightChangerPoiyomiShaderConstants.FxProximityColorMaxColor,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.ProximityColorMaxColor),
            new(
                PoiLightChangerControlId.ProximityColorMinDistance,
                "Proximity/Min Distance",
                "ProximityMinDistance",
                "proximity.min_distance",
                PoiLightChangerPoiyomiShaderConstants.FxProximityColorMinDistance,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.ProximityColorMinDistance),
            new(
                PoiLightChangerControlId.ProximityColorMaxDistance,
                "Proximity/Max Distance",
                "ProximityMaxDistance",
                "proximity.max_distance",
                PoiLightChangerPoiyomiShaderConstants.FxProximityColorMaxDistance,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.ProximityColorMaxDistance),
            new(
                PoiLightChangerControlId.ProximityColorBackface,
                "Proximity/Backface",
                "ProximityBackface",
                "proximity.backface",
                PoiLightChangerPoiyomiShaderConstants.FxProximityColorBackface,
                true,
                AnimatorControllerParameterType.Bool,
                component => component.Poiyomi.ProximityColorBackface),
            new(
                PoiLightChangerControlId.OutlineToggle,
                "Outline/Toggle",
                "OutlineToggle",
                "outline.toggle",
                PoiLightChangerPoiyomiShaderConstants.EnableOutlines,
                true,
                AnimatorControllerParameterType.Bool,
                component => component.Poiyomi.OutlineToggle),
            new(
                PoiLightChangerControlId.OutlineLineColor,
                "Outline/Line Color",
                "OutlineLineColor",
                "outline.line_color",
                PoiLightChangerPoiyomiShaderConstants.LineColor,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.OutlineLineColor),
            new(
                PoiLightChangerControlId.OutlineLineWidth,
                "Outline/Line Width",
                "OutlineLineWidth",
                "outline.line_width",
                PoiLightChangerPoiyomiShaderConstants.LineWidth,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.OutlineLineWidth),
            new(
                PoiLightChangerControlId.OutlineFixedSize,
                "Outline/Fixed Size",
                "OutlineFixedSize",
                "outline.fixed_size",
                PoiLightChangerPoiyomiShaderConstants.OutlineFixedSize,
                true,
                AnimatorControllerParameterType.Bool,
                component => component.Poiyomi.OutlineFixedSize),
            new(
                PoiLightChangerControlId.OutlineFixWidth,
                "Outline/Fix Width",
                "OutlineFixWidth",
                "outline.fix_width",
                PoiLightChangerPoiyomiShaderConstants.OutlineFixWidth,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.OutlineFixWidth),
            new(
                PoiLightChangerControlId.OutlineEmission,
                "Outline/Emission",
                "OutlineEmission",
                "outline.emission",
                PoiLightChangerPoiyomiShaderConstants.OutlineEmission,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.OutlineEmission),
            new(
                PoiLightChangerControlId.OutlineOffsetZ,
                "Outline/Offset Z",
                "OutlineOffsetZ",
                "outline.offset_z",
                PoiLightChangerPoiyomiShaderConstants.OffsetZ,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.OutlineOffsetZ),
            new(
                PoiLightChangerControlId.BacklightColor,
                "Backlight/Color",
                "BacklightColor",
                "backlight.color",
                PoiLightChangerPoiyomiShaderConstants.BacklightColor,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.BacklightColor),
            new(
                PoiLightChangerControlId.BacklightToggle,
                "Backlight/Toggle",
                "BacklightToggle",
                "backlight.toggle",
                PoiLightChangerPoiyomiShaderConstants.BacklightBorder,
                true,
                AnimatorControllerParameterType.Bool,
                component => component.Poiyomi.BacklightToggle),
            new(
                PoiLightChangerControlId.BacklightMainStrength,
                "Backlight/Main Strength",
                "BacklightMainStrength",
                "backlight.main_strength",
                PoiLightChangerPoiyomiShaderConstants.BacklightMainStrength,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.BacklightMainStrength),
            new(
                PoiLightChangerControlId.BacklightBorder,
                "Backlight/Border",
                "BacklightBorder",
                "backlight.border",
                PoiLightChangerPoiyomiShaderConstants.BacklightBorder,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.BacklightBorder),
            new(
                PoiLightChangerControlId.BacklightBlur,
                "Backlight/Blur",
                "BacklightBlur",
                "backlight.blur",
                PoiLightChangerPoiyomiShaderConstants.BacklightBlur,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.BacklightBlur),
            new(
                PoiLightChangerControlId.BacklightDirectivity,
                "Backlight/Directivity",
                "BacklightDirectivity",
                "backlight.directivity",
                PoiLightChangerPoiyomiShaderConstants.BacklightDirectivity,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.BacklightDirectivity),
            new(
                PoiLightChangerControlId.BacklightViewStrength,
                "Backlight/View Strength",
                "BacklightViewStrength",
                "backlight.view_strength",
                PoiLightChangerPoiyomiShaderConstants.BacklightViewStrength,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.BacklightViewStrength),
            new(
                PoiLightChangerControlId.BacklightReceiveShadow,
                "Backlight/Receive Shadow",
                "BacklightReceiveShadow",
                "backlight.receive_shadow",
                PoiLightChangerPoiyomiShaderConstants.BacklightReceiveShadow,
                true,
                AnimatorControllerParameterType.Bool,
                component => component.Poiyomi.BacklightReceiveShadow),
            new(
                PoiLightChangerControlId.BacklightBackfaceMask,
                "Backlight/Backface Mask",
                "BacklightBackfaceMask",
                "backlight.backface_mask",
                PoiLightChangerPoiyomiShaderConstants.BacklightBackfaceMask,
                true,
                AnimatorControllerParameterType.Bool,
                component => component.Poiyomi.BacklightBackfaceMask),
            new(
                PoiLightChangerControlId.SSAOAnimationToggle,
                "SSAO/Toggle",
                "SSAOAnimationToggle",
                "ssao.animation_toggle",
                PoiLightChangerPoiyomiShaderConstants.SsaoAnimationToggle,
                true,
                AnimatorControllerParameterType.Bool,
                component => component.Poiyomi.SSAOAnimationToggle),
            new(
                PoiLightChangerControlId.SSAOIntensity,
                "SSAO/Intensity",
                "SSAOIntensity",
                "ssao.intensity",
                PoiLightChangerPoiyomiShaderConstants.SsaoIntensity,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.SSAOIntensity),
            new(
                PoiLightChangerControlId.SSAORadius,
                "SSAO/Radius",
                "SSAORadius",
                "ssao.radius",
                PoiLightChangerPoiyomiShaderConstants.SsaoRadius,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.SSAORadius),
            new(
                PoiLightChangerControlId.SSAOQuality,
                "SSAO/Quality",
                "SSAOQuality",
                "ssao.quality",
                PoiLightChangerPoiyomiShaderConstants.SsaoQuality,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.SSAOQuality),
            new(
                PoiLightChangerControlId.SSAOCenterImportance,
                "SSAO/Center Importance",
                "SSAOCenterImportance",
                "ssao.center_importance",
                PoiLightChangerPoiyomiShaderConstants.SsaoCenterImportance,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.SSAOCenterImportance),
            new(
                PoiLightChangerControlId.SSAOBias,
                "SSAO/Depth Bias",
                "SSAOBias",
                "ssao.bias",
                PoiLightChangerPoiyomiShaderConstants.SsaoBias,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.SSAOBias),
            new(
                PoiLightChangerControlId.SSAOCone,
                "SSAO/Cone Bias",
                "SSAOCone",
                "ssao.cone",
                PoiLightChangerPoiyomiShaderConstants.SsaoCone,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.SSAOCone),
            new(
                PoiLightChangerControlId.SSAORandomScale,
                "SSAO/Random Jitter",
                "SSAORandomScale",
                "ssao.random_scale",
                PoiLightChangerPoiyomiShaderConstants.SsaoRandomScale,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.SSAORandomScale),
            new(
                PoiLightChangerControlId.SSAOUseNormals,
                "SSAO/Use Normals",
                "SSAOUseNormals",
                "ssao.use_normals",
                PoiLightChangerPoiyomiShaderConstants.SsaoUseNormals,
                true,
                AnimatorControllerParameterType.Bool,
                component => component.Poiyomi.SSAOUseNormals),
            new(
                PoiLightChangerControlId.ContactShadowAnimationToggle,
                "Contact Shadows/Toggle",
                "ContactShadowAnimationToggle",
                "contact_shadows.animation_toggle",
                PoiLightChangerPoiyomiShaderConstants.ContactShadowsAnimationToggle,
                true,
                AnimatorControllerParameterType.Bool,
                component => component.Poiyomi.ContactShadowAnimationToggle),
            new(
                PoiLightChangerControlId.ContactShadowIntensity,
                "Contact Shadows/Shadow Intensity",
                "ContactShadowIntensity",
                "contact_shadows.intensity",
                PoiLightChangerPoiyomiShaderConstants.ContactShadowsIntensity,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.ContactShadowIntensity),
            new(
                PoiLightChangerControlId.ContactShadowMaxDistance,
                "Contact Shadows/Max Distance",
                "ContactShadowMaxDistance",
                "contact_shadows.max_distance",
                PoiLightChangerPoiyomiShaderConstants.ContactShadowsMaxDistance,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.ContactShadowMaxDistance),
            new(
                PoiLightChangerControlId.ContactShadowQuality,
                "Contact Shadows/Quality",
                "ContactShadowQuality",
                "contact_shadows.quality",
                PoiLightChangerPoiyomiShaderConstants.ContactShadowsQuality,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.ContactShadowQuality),
            new(
                PoiLightChangerControlId.ContactShadowThickness,
                "Contact Shadows/Thickness",
                "ContactShadowThickness",
                "contact_shadows.thickness",
                PoiLightChangerPoiyomiShaderConstants.ContactShadowsThickness,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.ContactShadowThickness),
            new(
                PoiLightChangerControlId.ContactShadowBias,
                "Contact Shadows/Depth Bias",
                "ContactShadowBias",
                "contact_shadows.bias",
                PoiLightChangerPoiyomiShaderConstants.ContactShadowsBias,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.ContactShadowBias),
            new(
                PoiLightChangerControlId.ContactShadowNormalBias,
                "Contact Shadows/Normal Rejection",
                "ContactShadowNormalBias",
                "contact_shadows.normal_bias",
                PoiLightChangerPoiyomiShaderConstants.ContactShadowsNormalBias,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.ContactShadowNormalBias),
            new(
                PoiLightChangerControlId.ContactShadowHideInLight,
                "Contact Shadows/Hide In Light",
                "ContactShadowHideInLight",
                "contact_shadows.hide_in_light",
                PoiLightChangerPoiyomiShaderConstants.ContactShadowsHideInLight,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.ContactShadowHideInLight),
            new(
                PoiLightChangerControlId.ContactShadowNoiseScale,
                "Contact Shadows/Dither Noise",
                "ContactShadowNoiseScale",
                "contact_shadows.noise_scale",
                PoiLightChangerPoiyomiShaderConstants.ContactShadowsNoiseScale,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.ContactShadowNoiseScale),
            new(
                PoiLightChangerControlId.ContactShadowRejectionDepth,
                "Contact Shadows/Rejection Depth",
                "ContactShadowRejectionDepth",
                "contact_shadows.rejection_depth",
                PoiLightChangerPoiyomiShaderConstants.ContactShadowsRejectionDepth,
                true,
                AnimatorControllerParameterType.Float,
                component => component.Poiyomi.ContactShadowRejectionDepth),
        };

        public static IReadOnlyList<PoiLightChangerControlDefinition> V1Controls => V1Definitions;

        public static PoiLightChangerControlDefinition GetDefinition(PoiLightChangerControlId id)
        {
            return V1Definitions.FirstOrDefault(definition => definition.Id == id);
        }

        public static PoiLightChangerControlSectionId GetSectionId(PoiLightChangerControlDefinition definition)
        {
            if (definition == null || !ControlSections.TryGetValue(definition.Id, out var sectionId))
            {
                return default;
            }

            return sectionId;
        }

        public static PoiLightChangerControlSectionDefinition GetSectionDefinition(PoiLightChangerControlSectionId id)
        {
            SectionDefinitions.TryGetValue(id, out var definition);
            return definition;
        }

        public static bool IsSectionEnabled(PoiLightChangerComponent component, PoiLightChangerControlSectionId id)
        {
            if (component?.Poiyomi == null)
            {
                return false;
            }

            var sectionDefinition = GetSectionDefinition(id);
            return sectionDefinition != null && sectionDefinition.EvaluateIsEnabled(component);
        }

        public static bool IsSectionEnabled(PoiLightChangerComponent component, PoiLightChangerControlDefinition definition)
        {
            if (definition == null || !ControlSections.TryGetValue(definition.Id, out var sectionId))
            {
                return false;
            }

            return IsSectionEnabled(component, sectionId);
        }

        public static string GetSectionEnablePropertyName(PoiLightChangerControlSectionId id)
        {
            return GetSectionDefinition(id)?.EnablePropertyName;
        }

        public static IReadOnlyList<string> GetSectionPropertyNames(PoiLightChangerControlSectionId id)
        {
            return GetSectionDefinition(id)?.PropertyNames ?? Array.Empty<string>();
        }

        public static string GetInspectorSectionTitleJapanese(PoiLightChangerControlSectionId id)
        {
            return GetSectionDefinition(id)?.InspectorTitleJapanese ?? string.Empty;
        }

        public static string GetInspectorSectionTitleEnglish(PoiLightChangerControlSectionId id)
        {
            return GetSectionDefinition(id)?.InspectorTitleEnglish ?? string.Empty;
        }

        public static string GetSectionFeatureModePropertyName(PoiLightChangerControlSectionId id)
        {
            return GetSectionDefinition(id)?.FeatureModePropertyName ?? string.Empty;
        }

        public static string GetSectionFeatureModeLabelJapanese(PoiLightChangerControlSectionId id)
        {
            return GetSectionDefinition(id)?.FeatureModeLabelJapanese ?? string.Empty;
        }

        public static string GetSectionFeatureModeLabelEnglish(PoiLightChangerControlSectionId id)
        {
            return GetSectionDefinition(id)?.FeatureModeLabelEnglish ?? string.Empty;
        }

        public static string ComposeAnimatorParameterName(PoiLightChangerComponent component, PoiLightChangerControlDefinition definition)
        {
            var prefix = PoiLightChangerGeneralSettings.DefaultParameterPrefix;

            if (string.IsNullOrWhiteSpace(prefix))
            {
                return definition.ParameterSuffix;
            }

            return $"{prefix}/{definition.ParameterSuffix}";
        }

        public static PoiLightChangerControlMetadata GetControlMetadata(PoiLightChangerControlId id)
        {
            if (ControlMetadata.TryGetValue(id, out var metadata))
            {
                return metadata;
            }

            return CreateControlMetadata(PoiLightChangerControlKind.Scalar, id.ToString(), id.ToString());
        }

        private static PoiLightChangerControlMetadata CreateControlMetadata(
            PoiLightChangerControlKind kind,
            string inspectorJapanese,
            string inspectorEnglish,
            string menuJapanese = null,
            string menuEnglish = null)
        {
            return new PoiLightChangerControlMetadata
            {
                Kind = kind,
                InspectorLabelJapanese = inspectorJapanese,
                InspectorLabelEnglish = inspectorEnglish,
                MenuLabelJapanese = menuJapanese ?? inspectorJapanese,
                MenuLabelEnglish = menuEnglish ?? inspectorEnglish,
            };
        }
    }
}
