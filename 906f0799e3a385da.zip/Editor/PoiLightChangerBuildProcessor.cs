using System.Collections.Generic;
using System.Linq;
using ImplementedFloatControl = io.github.m8pix.poi_light_changer.PoiLightChangerImplementedControlBinding;
using nadena.dev.modular_avatar.core;
using nadena.dev.ndmf;
using nadena.dev.ndmf.util;
using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;
using VRC.SDK3.Avatars.Components;
using VRC.SDK3.Avatars.ScriptableObjects;
using VRC.SDKBase;
using System.Reflection;
using System;

namespace io.github.m8pix.poi_light_changer
{
    internal sealed class PoiLightChangerBuildProcessor
    {
        private const string GeneratedRootName = "__PoiLightChanger.Generated";
        private const string MaterialAnimationPropertyPrefix = "material.";
        private const string DefaultRootMenuIconGuid = "389c70ab40f264a1f9b860e5aea4f590";
        private const string DefaultChildMenuIconGuid = "cc4c13c05f8c4e943885903095b7474a";
        private static readonly IReadOnlyList<string> NoAdditionalAnimatedProperties = System.Array.Empty<string>();
        private static readonly IReadOnlyDictionary<string, float> NoConstantProperties = new Dictionary<string, float>();

        private enum MaterialAssociationSource
        {
            SharedMaterials = 0,
            AnimatedMaterialProvider = 1,
            MaterialSetterMaterialProvider = 2,
            MaterialSwapMaterialProvider = 3,
        }

        private sealed class AssociatedMaterialEntry
        {
            public Material Material { get; set; }

            public MaterialAssociationSource Source { get; set; }
        }

        private readonly BuildContext context;
        private readonly PoiLightChangerComponent component;
        private readonly PoiLightChangerLicenseSnapshot licenseSnapshot;
        private readonly Dictionary<Material, Material> clonedMaterials = new();
        private readonly Dictionary<Renderer, List<AssociatedMaterialEntry>> rendererAssociatedMaterials = new();
        private readonly HashSet<Renderer> targetRenderers = new();
        private readonly HashSet<Material> targetMaterials = new();
        private readonly HashSet<Material> originallyLockedMaterials = new();
        private readonly HashSet<string> reportedDiagnosticKeys = new(StringComparer.Ordinal);
        private readonly HashSet<string> unsupportedPoiyomiMaterialNames = new(StringComparer.Ordinal);
        private readonly HashSet<string> nonPoiyomiMaterialNames = new(StringComparer.Ordinal);
        private PoiColorAdjustV10BakerApi poiyomiV10BakerApi;
        private bool poiyomiV10BakerApiResolved;
        private bool materialEditSessionActive;
        private GameObject generatedRootObject;

        private sealed class PoiColorAdjustV10BakerApi
        {
            public MethodInfo SetBakerProperties { get; set; }

            public MethodInfo ResetColorAdjustProperties { get; set; }

            public Shader BakerShader { get; set; }
        }

        private readonly struct ColorAdjustBakeState
        {
            public ColorAdjustBakeState(
                bool hasAnyEffect,
                bool hasAnyHue,
                bool canBakeHue,
                bool hasHue,
                bool hasSaturation,
                bool hasBrightness,
                bool hasGamma,
                bool hasGradation,
                bool hasTint,
                bool hasAssignedColorAdjustTexture,
                bool hasAssignedGradationTexture,
                bool hasAssignedTintTexture)
            {
                HasAnyEffect = hasAnyEffect;
                HasAnyHue = hasAnyHue;
                CanBakeHue = canBakeHue;
                HasHue = hasHue;
                HasSaturation = hasSaturation;
                HasBrightness = hasBrightness;
                HasGamma = hasGamma;
                HasGradation = hasGradation;
                HasTint = hasTint;
                HasAssignedColorAdjustTexture = hasAssignedColorAdjustTexture;
                HasAssignedGradationTexture = hasAssignedGradationTexture;
                HasAssignedTintTexture = hasAssignedTintTexture;
            }

            public bool HasAnyEffect { get; }
            public bool HasAnyHue { get; }
            public bool CanBakeHue { get; }
            public bool HasHue { get; }
            public bool HasSaturation { get; }
            public bool HasBrightness { get; }
            public bool HasGamma { get; }
            public bool HasGradation { get; }
            public bool HasTint { get; }
            public bool HasAssignedColorAdjustTexture { get; }
            public bool HasAssignedGradationTexture { get; }
            public bool HasAssignedTintTexture { get; }

            public bool UsesColorAdjustMask => HasHue || HasSaturation || HasBrightness || HasGamma;
        }

        private sealed class BacklightAnimatorContext
        {
            public ImplementedFloatControl ToggleControl { get; set; }

            public ImplementedFloatControl BorderControl { get; set; }

            public bool UsesMergedSync { get; set; }

            public string StoredValueParameterName { get; set; }
        }

        private sealed class OutlineAnimatorContext
        {
            public ImplementedFloatControl ToggleControl { get; set; }

            public ImplementedFloatControl LineWidthControl { get; set; }

            public bool UsesMergedSync { get; set; }

            public string StoredValueParameterName { get; set; }
        }

        private sealed class ProximityAnimatorContext
        {
            public ImplementedFloatControl ToggleControl { get; set; }

            public ImplementedFloatControl MinDistanceControl { get; set; }

            public ImplementedFloatControl MaxDistanceControl { get; set; }
        }

        public PoiLightChangerBuildProcessor(
            BuildContext context,
            PoiLightChangerComponent component,
            PoiLightChangerLicenseSnapshot licenseSnapshot = null)
        {
            this.context = context;
            this.component = component;
            this.licenseSnapshot = licenseSnapshot ?? PoiLightChangerLicenseService.GetCurrentSnapshot();
        }

        public IReadOnlyCollection<Renderer> TargetRenderers => targetRenderers;

        public IReadOnlyCollection<Material> TargetMaterials => targetMaterials;

        public void ReportCollectedMaterialDiagnostics()
        {
            if (targetMaterials.Count == 0 || targetRenderers.Count == 0)
            {
                ReportDiagnosticOnce(
                    "AvatarNoSupportedPoiyomiMaterials",
                    PoiLightChangerDiagnostics.CreateProcessorDiagnostic(
                        PoiLightChangerDiagnosticId.AvatarNoSupportedPoiyomiMaterials,
                        string.Empty,
                        string.Empty,
                        "[Poi Light Changer] No Poiyomi materials supported by PLC were found in the avatar, so processing will not run.",
                        ErrorSeverity.Information,
                        false,
                        context.AvatarRootObject));
            }

            if (nonPoiyomiMaterialNames.Count > 0)
            {
                var examples = string.Join(", ", nonPoiyomiMaterialNames.OrderBy(name => name, StringComparer.Ordinal).Take(8));
                ReportDiagnosticOnce(
                    "AvatarHasNonPoiyomiMaterials",
                    PoiLightChangerDiagnostics.CreateProcessorDiagnostic(
                        PoiLightChangerDiagnosticId.AvatarHasNonPoiyomiMaterials,
                        string.Empty,
                        string.Empty,
                        $"[Poi Light Changer] Non-Poiyomi materials were found. PLC ignores them. Example: {examples}",
                        ErrorSeverity.Information,
                        false,
                        context.AvatarRootObject));
            }

        }

        public void CloneTargetMaterials()
        {
            if (component == null)
            {
                return;
            }

            IPoiLightChangerMaterialProvider[] providers =
            {
                new PoiLightChangerRendererSharedMaterialProvider(),
                new PoiLightChangerAnimatedMaterialProvider(),
                new PoiLightChangerMaterialSetterMaterialProvider(),
                new PoiLightChangerMaterialSwapMaterialProvider(),
            };

            try
            {
                for (var index = 0; index < providers.Length; index++)
                {
                    var provider = providers[index];
                    UpdateCloneTargetMaterialsProgress(index, providers.Length, provider);
                    provider.Collect(this);
                }
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        internal BuildContext Context => context;

        internal PoiLightChangerComponent Component => component;

        internal IEnumerable<Renderer> EnumerateAvatarRenderers()
        {
            if (component == null)
            {
                return Enumerable.Empty<Renderer>();
            }

            return context.AvatarRootObject.GetComponentsInChildren<Renderer>(component.Target.IncludeInactiveRenderers);
        }

        internal bool ShouldSkipRenderer(Renderer renderer)
        {
            if (renderer == null)
            {
                return true;
            }

            if (component.Target.IsGameObjectExcluded(renderer.gameObject))
            {
                return true;
            }

            if (!component.Target.IncludeInactiveRenderers && !renderer.gameObject.activeInHierarchy)
            {
                return true;
            }

            return component.General.ExcludeParticleSystem && renderer is ParticleSystemRenderer;
        }

        internal Material CloneMaterialForSharedRenderer(Material sourceMaterial, Renderer renderer)
        {
            return CloneMaterialInternal(sourceMaterial, renderer, MaterialAssociationSource.SharedMaterials);
        }

        internal Material CloneMaterialForAssociatedRenderer(
            Material sourceMaterial,
            Renderer renderer,
            string providerName)
        {
            return CloneMaterialInternal(sourceMaterial, renderer, ParseAssociationSource(providerName));
        }

        internal void RegisterAssociatedMaterial(Renderer renderer, Material material, string providerName)
        {
            if (renderer == null || material == null || !targetMaterials.Contains(material))
            {
                return;
            }

            RegisterRendererAndAssociation(renderer, material, ParseAssociationSource(providerName));
        }

        internal bool RendererUsesMaterial(Renderer renderer, Material sourceMaterial)
        {
            if (renderer == null)
            {
                return false;
            }

            foreach (var material in renderer.sharedMaterials)
            {
                var originalMaterial = ObjectRegistry.GetReference(material)?.Object as Material ?? material;
                if (originalMaterial == sourceMaterial)
                {
                    return true;
                }
            }

            return false;
        }

        private Material CloneMaterialInternal(
            Material sourceMaterial,
            Renderer renderer,
            MaterialAssociationSource associationSource)
        {
            if (sourceMaterial == null)
            {
                return null;
            }

            if (renderer != null && ShouldSkipRenderer(renderer))
            {
                return sourceMaterial;
            }

            if (targetMaterials.Contains(sourceMaterial))
            {
                RegisterRendererAndAssociation(renderer, sourceMaterial, associationSource);
                return sourceMaterial;
            }

            if (!clonedMaterials.TryGetValue(sourceMaterial, out var clonedMaterial))
            {
                if (!IsSupportedPoiyomiMaterial(sourceMaterial))
                {
                    RecordSkippedMaterial(sourceMaterial);
                    return sourceMaterial;
                }

                clonedMaterial = new Material(sourceMaterial)
                {
                    name = $"{sourceMaterial.name} (PLC Clone)",
                };

                if (IsMaterialLocked(clonedMaterial))
                {
                    originallyLockedMaterials.Add(clonedMaterial);
                }

                context.AssetSaver.SaveAsset(clonedMaterial);
                ObjectRegistry.RegisterReplacedObject(sourceMaterial, clonedMaterial);
                clonedMaterials[sourceMaterial] = clonedMaterial;
                clonedMaterials[clonedMaterial] = clonedMaterial;
            }

            targetMaterials.Add(clonedMaterial);
            RegisterRendererAndAssociation(renderer, clonedMaterial, associationSource);
            return clonedMaterial;
        }

        private void RegisterRendererAndAssociation(
            Renderer renderer,
            Material material,
            MaterialAssociationSource associationSource)
        {
            if (renderer == null || material == null)
            {
                return;
            }

            targetRenderers.Add(renderer);

            if (associationSource == MaterialAssociationSource.SharedMaterials)
            {
                return;
            }

            if (!rendererAssociatedMaterials.TryGetValue(renderer, out var entries))
            {
                entries = new List<AssociatedMaterialEntry>();
                rendererAssociatedMaterials.Add(renderer, entries);
            }

            if (entries.Any(entry => entry.Material == material && entry.Source == associationSource))
            {
                return;
            }

            entries.Add(new AssociatedMaterialEntry
            {
                Material = material,
                Source = associationSource,
            });
        }

        private float ResolveMaterialInitialFloatValue(Renderer renderer, string materialPropertyName)
        {
            if (renderer == null)
            {
                return 0f;
            }

            foreach (var material in renderer.sharedMaterials)
            {
                if (material == null || !targetMaterials.Contains(material) || !MaterialHasFloatProperty(material, materialPropertyName))
                {
                    continue;
                }

                return GetFloat(material, materialPropertyName, 0f);
            }

            if (!rendererAssociatedMaterials.TryGetValue(renderer, out var entries))
            {
                return 0f;
            }

            var seen = new HashSet<Material>();
            foreach (var entry in entries
                         .Where(entry => entry?.Material != null && MaterialHasFloatProperty(entry.Material, materialPropertyName))
                         .OrderBy(entry => entry.Source)
                         .ThenBy(entry => entry.Material.name, StringComparer.Ordinal))
            {
                if (!seen.Add(entry.Material))
                {
                    continue;
                }

                return GetFloat(entry.Material, materialPropertyName, 0f);
            }

            return 0f;
        }

        private static MaterialAssociationSource ParseAssociationSource(string providerName)
        {
            return providerName switch
            {
                nameof(PoiLightChangerAnimatedMaterialProvider) => MaterialAssociationSource.AnimatedMaterialProvider,
                nameof(PoiLightChangerMaterialSetterMaterialProvider) => MaterialAssociationSource.MaterialSetterMaterialProvider,
                nameof(PoiLightChangerMaterialSwapMaterialProvider) => MaterialAssociationSource.MaterialSwapMaterialProvider,
                _ => MaterialAssociationSource.SharedMaterials,
            };
        }

        public void ApplyAnimatedStaticMaterialValues()
        {
            ApplyRequiredSectionMaterialValues();
            ApplyStaticMaterialValues(includeAnimatedControls: true);
        }

        public void ApplyNonAnimatedStaticMaterialValues()
        {
            ApplyStaticMaterialValues(includeAnimatedControls: false);
        }

        private void ApplyStaticMaterialValues(bool includeAnimatedControls)
        {
            if (component == null)
            {
                return;
            }

            foreach (var implementedControl in GetImplementedFloatControls())
            {
                if (!implementedControl.SectionEnabled ||
                    !implementedControl.Control.Enable ||
                    implementedControl.Control.Animation != includeAnimatedControls ||
                    !ShouldApplyAnimatedStaticMaterialValue(implementedControl))
                {
                    continue;
                }

                if (implementedControl.IsBacklightColorIntensityControl)
                {
                    continue;
                }

                if (implementedControl.Definition.Id == PoiLightChangerControlId.OutlineLineWidth &&
                    component.Poiyomi.OutlineToggle is { Enable: true, Animation: false } &&
                    component.Poiyomi.OutlineToggle.Value < 0.5f)
                {
                    continue;
                }

                if ((implementedControl.Definition.Id == PoiLightChangerControlId.ProximityColorMinDistance ||
                     implementedControl.Definition.Id == PoiLightChangerControlId.ProximityColorMaxDistance) &&
                    component.Poiyomi.ProximityToggle is { Enable: true, Animation: false } &&
                    component.Poiyomi.ProximityToggle.Value < 0.5f)
                {
                    continue;
                }

                if (!TryResolveStaticMaterialInjection(implementedControl, out var effectivePropName, out var effectiveInitialValue))
                {
                    continue;
                }

                foreach (var material in targetMaterials.Where(material => material != null && MaterialHasFloatProperty(material, effectivePropName)))
                {
                    SetMaterialFloatProperty(
                        material,
                        effectivePropName,
                        effectiveInitialValue);

                    if (implementedControl.Definition.Id == PoiLightChangerControlId.ProximityToggle &&
                        implementedControl.Control.Value < 0.5f &&
                        MaterialHasFloatProperty(material, PoiLightChangerPoiyomiShaderConstants.FxProximityColorMaxDistance))
                    {
                        SetMaterialFloatProperty(material, PoiLightChangerPoiyomiShaderConstants.FxProximityColorMaxDistance, 0.0f);
                    }

                    foreach (var animatedProperty in implementedControl.AdditionalAnimatedProperties)
                    {
                        if (material.HasProperty(animatedProperty))
                        {
                            material.SetFloat(animatedProperty, implementedControl.Control.Value);
                        }
                    }

                    foreach (var constantProperty in implementedControl.ConstantProperties)
                    {
                        if (material.HasProperty(constantProperty.Key))
                        {
                            material.SetFloat(constantProperty.Key, constantProperty.Value);
                        }
                    }

                    ApplyCompanionStaticMaterialValues(material, implementedControl);
                }
            }
        }

        private void ApplyCompanionStaticMaterialValues(Material material, ImplementedFloatControl implementedControl)
        {
            if (material == null || implementedControl == null)
            {
                return;
            }

            if (implementedControl.Definition.Id != PoiLightChangerControlId.OutlineLineColor ||
                component?.Poiyomi?.OutlineLineColor == null ||
                !material.HasProperty(PoiLightChangerPoiyomiShaderConstants.LineColor))
            {
                return;
            }

            SetMaterialFloatProperty(
                material,
                PoiLightChangerPoiyomiShaderConstants.LineColorA,
                Mathf.Clamp01(component.Poiyomi.OutlineLineColor.Value.a));
        }

        private static bool ShouldApplyAnimatedStaticMaterialValue(ImplementedFloatControl implementedControl)
        {
            return true;
        }

        private bool TryResolveStaticMaterialInjection(
            ImplementedFloatControl implementedControl,
            out string materialPropertyName,
            out float materialValue)
        {
            materialPropertyName = implementedControl.OverrideMaterialPropertyName ?? implementedControl.Definition.MaterialPropertyName;
            materialValue = ResolveStaticMaterialValue(implementedControl);

            switch (implementedControl.Definition.Id)
            {
                case PoiLightChangerControlId.LightDirectionToggle:
                    materialValue = implementedControl.Control.Animation
                        ? ResolveLightDirectionToggleOffValue()
                        : ResolveCurrentToggleValue(implementedControl);
                    return true;

                case PoiLightChangerControlId.BacklightToggle:
                    if (implementedControl.Control.Value >= 0.5f)
                    {
                        return false;
                    }

                    materialPropertyName = PoiLightChangerPoiyomiShaderConstants.BacklightBorder;
                    materialValue = 1.0f;
                    return true;

                case PoiLightChangerControlId.OutlineToggle:
                    if (implementedControl.Control.Value >= 0.5f)
                    {
                        return false;
                    }

                    materialPropertyName = PoiLightChangerPoiyomiShaderConstants.LineWidth;
                    materialValue = 0.0f;
                    return true;

                case PoiLightChangerControlId.ProximityToggle:
                    if (implementedControl.Control.Value >= 0.5f)
                    {
                        return false;
                    }

                    materialPropertyName = PoiLightChangerPoiyomiShaderConstants.FxProximityColorMinDistance;
                    materialValue = 0.0f;
                    return true;

                default:
                    return true;
            }
        }

        private float ResolveStaticMaterialValue(ImplementedFloatControl implementedControl)
        {
            if (implementedControl.IsToggle)
            {
                return ResolveCurrentToggleValue(implementedControl);
            }

            if (implementedControl.IsAdditiveVectorControl)
            {
                return ResolveCurrentVectorComponentValue(implementedControl);
            }

            return implementedControl.MaterialInitialValueOverride ?? implementedControl.Control.Value;
        }

        private float ResolveCurrentToggleValue(ImplementedFloatControl implementedControl)
        {
            return implementedControl.Control.Value >= 0.5f
                ? ResolveOnClipValue(implementedControl)
                : ResolveOffClipValue(implementedControl);
        }

        private static float ResolveCurrentVectorComponentValue(ImplementedFloatControl implementedControl)
        {
            if (implementedControl.MaterialInitialValueOverride is { } initialValueOverride)
            {
                return initialValueOverride;
            }

            var normalizedValue = NormalizeFloatControlValue(implementedControl.Control);

            if (implementedControl.AdditiveVectorKeyframes is { Length: > 0 } keyframes)
            {
                if (normalizedValue <= keyframes[0].Threshold)
                {
                    return keyframes[0].ComponentValue;
                }

                for (var index = 1; index < keyframes.Length; index++)
                {
                    var previous = keyframes[index - 1];
                    var current = keyframes[index];
                    if (normalizedValue > current.Threshold)
                    {
                        continue;
                    }

                    if (Mathf.Approximately(previous.Threshold, current.Threshold))
                    {
                        return current.ComponentValue;
                    }

                    var t = Mathf.InverseLerp(previous.Threshold, current.Threshold, normalizedValue);
                    return Mathf.Lerp(previous.ComponentValue, current.ComponentValue, t);
                }

                return keyframes[keyframes.Length - 1].ComponentValue;
            }

            var minValue = implementedControl.OverrideMinValue ?? implementedControl.Control.Range.x;
            var maxValue = implementedControl.OverrideMaxValue ?? implementedControl.Control.Range.y;
            return Mathf.Lerp(minValue, maxValue, normalizedValue);
        }

        public void ApplyCommonMaterialOverrides()
        {
            if (component?.Overrides == null ||
                targetMaterials.Count == 0 ||
                !IsFeatureAvailable(PoiLightChangerLicensedFeatureId.MaterialOverrides))
            {
                return;
            }

            var overrides = component.Overrides;
            if (!overrides.HasAnyEnabled())
            {
                return;
            }

            foreach (var material in targetMaterials.Where(material => material != null))
            {
                var changed = false;

                changed |= TryApplyCommonIntOverride(
                    material,
                    PoiLightChangerPoiyomiShaderConstants.LightingColorMode,
                    overrides.LightColorMode);
                changed |= TryApplyCommonIntOverride(
                    material,
                    PoiLightChangerPoiyomiShaderConstants.LightingMapMode,
                    overrides.LightMapMode);
                changed |= TryApplyCommonIntOverride(
                    material,
                    PoiLightChangerPoiyomiShaderConstants.LightingDirectionMode,
                    overrides.LightDirectionMode);
                changed |= TryApplyCommonBoolOverride(
                    material,
                    PoiLightChangerPoiyomiShaderConstants.RenderingReduceClipDistance,
                    overrides.NearClipForce);
                changed |= TryApplyCommonBoolOverride(
                    material,
                    PoiLightChangerPoiyomiShaderConstants.LtcgiEnabled,
                    overrides.Ltcgi,
                    keyword: "POI_LTCGI");

                if (overrides.WorldAOBlock.Enable)
                {
                    changed |= TryApplyCommonFloatValue(
                        material,
                        PoiLightChangerPoiyomiShaderConstants.RenderingAoBlockerEnabled,
                        overrides.WorldAOBlock.Enabled ? 1f : 0f);
                    changed |= TryApplyCommonFloatValue(
                        material,
                        PoiLightChangerPoiyomiShaderConstants.RenderingAoBlockerUvChannel,
                        overrides.WorldAOBlock.UVChannel);
                    changed |= TryApplyCommonFloatValue(
                        material,
                        PoiLightChangerPoiyomiShaderConstants.RenderingAoBlockerFlipNormal,
                        overrides.WorldAOBlock.FlipNormal ? 1f : 0f);
                }

                if (changed)
                {
                    ApplyMaterialPropertyDrawers(material);
                }
            }
        }

        private void PrepareAnimatedProperties()
        {
            if (!component.General.AutoAddAnimated)
            {
                return;
            }

            foreach (var implementedControl in GetImplementedFloatControls())
            {
                if (!implementedControl.SectionEnabled || !implementedControl.Control.Enable || !implementedControl.Control.Animation)
                {
                    continue;
                }

                var effectivePropName = implementedControl.OverrideMaterialPropertyName ?? implementedControl.Definition.MaterialPropertyName;

                foreach (var material in targetMaterials.Where(material => material != null && MaterialHasFloatProperty(material, effectivePropName)))
                {
                    material.SetOverrideTag($"{GetBasePropertyName(effectivePropName)}Animated", "1");

                    foreach (var animatedProperty in implementedControl.AdditionalAnimatedProperties)
                    {
                        if (material.HasProperty(animatedProperty))
                        {
                            material.SetOverrideTag($"{animatedProperty}Animated", "1");
                        }
                    }
                }
            }
        }

        public void BakeColorAdjustments()
        {
            if (component == null ||
                !PoiLightChangerBuildFeatureOverrides.ShouldUseTextureBake(component, licenseSnapshot))
            {
                return;
            }

            var baker = new PoiLightChangerTextureBaker(context);
            Shader legacyColorBakerShader = null;
            var materials = targetMaterials.ToArray();

            try
            {
                for (var index = 0; index < materials.Length; index++)
                {
                    var material = materials[index];
                    if (material == null)
                    {
                        continue;
                    }

                    UpdateTextureBakeProgress(index, materials.Length, material);

                    var shaderInfo = PoiLightChangerDiagnostics.GetPoiyomiShaderInfo(material.shader);
                    if (shaderInfo.MajorVersion >= 10)
                    {
                        NormalizeColorAdjustV10(material, baker);
                        continue;
                    }

                    legacyColorBakerShader ??= Shader.Find("Hidden/PoiLightChanger/ColorBaker");
                    if (legacyColorBakerShader == null)
                    {
                        ReportDiagnosticOnce(
                            "TextureBakeShaderMissing",
                            PoiLightChangerDiagnostics.CreateProcessorDiagnostic(
                                PoiLightChangerDiagnosticId.TextureBakeShaderMissing,
                                string.Empty,
                                string.Empty,
                                "[Poi Light Changer] Color Bake shader does not exist, so Texture Bake will be skipped.",
                                ErrorSeverity.NonFatal,
                                false,
                                component));
                        return;
                    }

                    NormalizeColorAdjustLegacy(material, baker, legacyColorBakerShader);
                }
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }
        }

        private static void UpdateTextureBakeProgress(int index, int totalCount, Material material)
        {
            if (material == null)
            {
                return;
            }

            var normalizedProgress = totalCount <= 0
                ? 0f
                : Mathf.Clamp01((float)index / totalCount);

            EditorUtility.DisplayProgressBar(
                "Poi Light Changer",
                $"Texture Bake ({index + 1}/{Mathf.Max(totalCount, 1)}): {material.name}",
                normalizedProgress);
        }

        private static readonly string[] s_colorAdjustAnimatedPropertiesLegacy =
        {
            "_ColorThemeIndex",
            "_MainColorAdjustToggle",
            "_MainColorAdjustTextureUV",
            "_MainColorAdjustTexturePan",
            "_MainColorAdjustTexture_ST",
            "_MainHueShiftToggle",
            PoiLightChangerPoiyomiShaderConstants.MainHueShift,
            "_MainHueShiftSpeed",
            "_MainHueShiftColorSpace",
            "_MainHueShiftSelectOrShift",
            "_MainHueShiftReplace",
            "_MainHueALCTEnabled",
            "_MainHueALMotionSpeed",
            "_MainALHueShiftBand",
            "_MainALHueShiftCTIndex",
            PoiLightChangerPoiyomiShaderConstants.Saturation,
            PoiLightChangerPoiyomiShaderConstants.MainBrightness,
            "_MainGamma",
            "_ColorGradingToggle",
            "_MainGradationStrength",
            "_MainTexUV",
            "_MainTexPan",
            "_MainTex_ST",
            "_MainTexStochastic",
        };

    private static readonly string[] s_colorAdjustAnimatedPropertiesV10 =
    {
        "_ColorThemeIndex",
        "_MainColorAdjustToggle",
        "_MainColorAdjustTextureUV",
        "_MainColorAdjustTexturePan",
        "_MainColorAdjustTexture_ST",
        "_MainHueShiftToggle",
        PoiLightChangerPoiyomiShaderConstants.MainHueShift,
        "_MainHueShiftSpeed",
        "_MainHueShiftColorSpace",
        "_MainHueShiftSelectOrShift",
        "_MainHueShiftReplace",
        "_MainHueALCTEnabled",
        "_MainHueALMotionSpeed",
        "_MainALHueShiftBand",
        "_MainALHueShiftCTIndex",
        PoiLightChangerPoiyomiShaderConstants.Saturation,
        PoiLightChangerPoiyomiShaderConstants.MainBrightness,
        "_MainGamma",
        "_ColorGradingToggle",
        "_MainGradationStrength",
        "_MainTexUV",
        "_MainTexPan",
        "_MainTex_ST",
        "_MainTexStochastic",
        "_MainChromatize",
        "_MainTintColor",
        "_MainTintTexture",
        "_MainTintTexture_ST",
        "_MainTintTexturePan",
        "_MainTintTextureUV",
    };

    private void NormalizeColorAdjustLegacy(Material material, PoiLightChangerTextureBaker baker, Shader colorBakerShader)
    {
        if (HasAnimatedColorAdjust(material, isV10OrNewer: false))
            return;

        if (material.GetTexture("_MainTex") is not Texture2D mainTex)
            return;

        var state = EvaluateColorAdjustBakeState(material, isV10OrNewer: false);
        if (!state.HasAnyEffect)
            return;

        var shaderSat = GetFloat(material, PoiLightChangerPoiyomiShaderConstants.Saturation, 0f);
        var shaderBrightness = GetFloat(material, PoiLightChangerPoiyomiShaderConstants.MainBrightness, 0f);
        var shaderGamma = GetFloat(material, "_MainGamma", 1f);
        var shaderGradationStrength = state.HasGradation
            ? GetFloat(material, "_MainGradationStrength", 0f)
            : 0f;
        var shaderHue = state.HasHue
            ? GetFloat(material, PoiLightChangerPoiyomiShaderConstants.MainHueShift, 0f)
            : 0f;

        if (!CanBakeColorAdjustCommon(material, state))
            return;

        var bakeMat = new Material(colorBakerShader)
        {
            name = $"PLC ColorBake {material.name}",
        };

        try
        {
            bakeMat.SetTexture("_MainTex", mainTex);
            if (material.HasProperty("_MainTex_ST"))
                bakeMat.SetVector("_MainTex_ST", material.GetVector("_MainTex_ST"));
            bakeMat.SetFloat(PoiLightChangerPoiyomiShaderConstants.Saturation, shaderSat);
            bakeMat.SetFloat(PoiLightChangerPoiyomiShaderConstants.MainBrightness, shaderBrightness);
            bakeMat.SetFloat("_MainGamma", shaderGamma);
            bakeMat.SetFloat("_ColorGradingToggle", state.HasGradation ? 1f : 0f);
            bakeMat.SetFloat("_MainGradationStrength", shaderGradationStrength);

            bakeMat.SetFloat("_MainHueShiftToggle", state.HasHue ? 1f : 0f);
            if (state.HasHue)
            {
                bakeMat.SetFloat(PoiLightChangerPoiyomiShaderConstants.MainHueShift, shaderHue);
                if (material.HasProperty("_MainHueShiftColorSpace"))
                    bakeMat.SetFloat("_MainHueShiftColorSpace", material.GetFloat("_MainHueShiftColorSpace"));
                if (material.HasProperty("_MainHueShiftSelectOrShift"))
                    bakeMat.SetFloat("_MainHueShiftSelectOrShift", material.GetFloat("_MainHueShiftSelectOrShift"));
                if (material.HasProperty("_MainHueShiftReplace"))
                    bakeMat.SetFloat("_MainHueShiftReplace", material.GetFloat("_MainHueShiftReplace"));
            }

            if (material.HasProperty("_MainColorAdjustTexture"))
            {
                var maskTex = material.GetTexture("_MainColorAdjustTexture");
                if (maskTex != null)
                    bakeMat.SetTexture("_MainColorAdjustTexture", maskTex);
            }
            if (material.HasProperty("_MainColorAdjustTexture_ST"))
                bakeMat.SetVector("_MainColorAdjustTexture_ST", material.GetVector("_MainColorAdjustTexture_ST"));

            if (state.HasGradation && material.HasProperty("_MainGradationTex"))
            {
                var gradationTex = material.GetTexture("_MainGradationTex");
                if (gradationTex != null)
                    bakeMat.SetTexture("_MainGradationTex", gradationTex);
            }

            var baked = baker.BakeOrGetCached(mainTex, bakeMat);

            ResetLegacyColorAdjustProperties(material);
            baker.FinalizeBakedTexture(mainTex, baked);
            ApplyBakedMainTexture(material, mainTex, baked);
            CleanupBakedInputTextures(material, state);
        }
        catch (Exception ex)
        {
            ReportTextureBakeGenerationFailed(material, isV10OrNewer: false, ex);
        }
        finally
        {
            UnityEngine.Object.DestroyImmediate(bakeMat);
        }
    }

    private void NormalizeColorAdjustV10(Material material, PoiLightChangerTextureBaker baker)
    {
        if (HasAnimatedColorAdjust(material, isV10OrNewer: true))
            return;

        if (material.GetTexture("_MainTex") is not Texture2D mainTex)
            return;

        var state = EvaluateColorAdjustBakeState(material, isV10OrNewer: true);
        if (!state.HasAnyEffect)
            return;

        if (!CanBakeColorAdjustV10(material, state))
            return;

        var bakerApi = ResolvePoiyomiV10BakerApi();
        if (bakerApi == null)
            return;

        var bakeMat = new Material(bakerApi.BakerShader)
        {
            name = $"PLC ColorBake {material.name}",
        };

        try
        {
            try
            {
                bakerApi.SetBakerProperties.Invoke(null, new object[] { bakeMat, material, mainTex });
            }
            catch (Exception ex)
            {
                ReportPoiyomiV10BakeUnavailable(
                    "Invoke:SetBakerProperties",
                    $"[Poi Light Changer] Poiyomi v10 Bake was skipped because SetBakerProperties invocation failed. See Console for details. {ex.GetType().Name}: {ex.Message}");
                Debug.LogWarning($"[Poi Light Changer] Failed to invoke Poiyomi v10 SetBakerProperties. {ex}");
                return;
            }

            Texture2D baked;
            try
            {
                baked = baker.BakeOrGetCached(mainTex, mainTex, bakeMat);
            }
            catch (Exception ex)
            {
                ReportTextureBakeGenerationFailed(material, isV10OrNewer: true, ex);
                return;
            }

            try
            {
                bakerApi.ResetColorAdjustProperties.Invoke(null, new object[] { material });
            }
            catch (Exception ex)
            {
                ReportPoiyomiV10BakeUnavailable(
                    "Invoke:ResetColorAdjustProperties",
                    $"[Poi Light Changer] Poiyomi v10 Bake was skipped because ResetColorAdjustProperties invocation failed. See Console for details. {ex.GetType().Name}: {ex.Message}");
                Debug.LogWarning($"[Poi Light Changer] Failed to invoke Poiyomi v10 ResetColorAdjustProperties. {ex}");
                return;
            }

            baker.FinalizeBakedTexture(mainTex, baked);
            ApplyBakedMainTexture(material, mainTex, baked);
            CleanupBakedInputTextures(material, state);
        }
        catch (Exception ex)
        {
            ReportTextureBakeGenerationFailed(material, isV10OrNewer: true, ex);
        }
        finally
        {
            UnityEngine.Object.DestroyImmediate(bakeMat);
        }
    }

    private PoiColorAdjustV10BakerApi ResolvePoiyomiV10BakerApi()
    {
        if (poiyomiV10BakerApiResolved)
            return poiyomiV10BakerApi;

        poiyomiV10BakerApiResolved = true;

        var bakerType = Type.GetType("Poi.Tools.PoiColorAdjustBaker, Poi.Tools");
        if (bakerType == null)
        {
            foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
            {
                bakerType = assembly.GetType("Poi.Tools.PoiColorAdjustBaker");
                if (bakerType != null)
                    break;
            }
        }

        if (bakerType == null)
        {
            ReportPoiyomiV10BakeUnavailable(
                "ResolveType",
                "[Poi Light Changer] Poiyomi v10 Bake was skipped because Poi.Tools.PoiColorAdjustBaker could not be resolved.");
            return null;
        }

        var setBakerProperties = bakerType.GetMethod("SetBakerProperties", BindingFlags.NonPublic | BindingFlags.Static);
        var resetColorAdjustProperties = bakerType.GetMethod("ResetColorAdjustProperties", BindingFlags.NonPublic | BindingFlags.Static);
        var bakerShader = Shader.Find("Hidden/Poi/ColorAdjustBaker");

        var missing = new List<string>();
        if (setBakerProperties == null)
            missing.Add("SetBakerProperties");
        if (resetColorAdjustProperties == null)
            missing.Add("ResetColorAdjustProperties");
        if (bakerShader == null)
            missing.Add("Hidden/Poi/ColorAdjustBaker");

        if (missing.Count > 0)
        {
            ReportPoiyomiV10BakeUnavailable(
                "MissingMembers",
                $"[Poi Light Changer] Poiyomi v10 Bake was skipped because required baker members were missing: {string.Join(", ", missing)}.");
            return null;
        }

        poiyomiV10BakerApi = new PoiColorAdjustV10BakerApi
        {
            SetBakerProperties = setBakerProperties,
            ResetColorAdjustProperties = resetColorAdjustProperties,
            BakerShader = bakerShader,
        };
        return poiyomiV10BakerApi;
    }

    private void ReportPoiyomiV10BakeUnavailable(string keySuffix, string ndmfMessage)
    {
        ReportDiagnosticOnce(
            $"TextureBakePoiyomiV10Unavailable:{keySuffix}",
            PoiLightChangerDiagnostics.CreateProcessorDiagnostic(
                PoiLightChangerDiagnosticId.TextureBakePoiyomiV10Unavailable,
                string.Empty,
                string.Empty,
                ndmfMessage,
                ErrorSeverity.NonFatal,
                false,
                component));
    }

    private void ReportTextureBakeGenerationFailed(Material material, bool isV10OrNewer, Exception ex)
    {
        var flavor = isV10OrNewer ? "Poiyomi v10+" : "Poiyomi v9 and below";
        ReportDiagnosticOnce(
            $"TextureBakeGenerationFailed:{flavor}:{material.GetInstanceID()}",
            PoiLightChangerDiagnostics.CreateProcessorDiagnostic(
                PoiLightChangerDiagnosticId.TextureBakeGenerationFailed,
                string.Empty,
                string.Empty,
                $"[Poi Light Changer] {flavor} bake was skipped because PLC texture generation failed. See Console for details. {ex.GetType().Name}: {ex.Message}",
                ErrorSeverity.NonFatal,
                false,
                material,
                component));
        Debug.LogWarning($"[Poi Light Changer] {flavor} bake was skipped because PLC texture generation failed. {ex}");
    }

    private static bool HasAnimatedColorAdjust(Material material, bool isV10OrNewer)
    {
        var properties = isV10OrNewer
            ? s_colorAdjustAnimatedPropertiesV10
            : s_colorAdjustAnimatedPropertiesLegacy;

        foreach (var property in properties)
        {
            if (material.GetTag($"{property}Animated", false) == "1")
                return true;
        }

        return false;
    }

    private static bool CanBakeColorAdjustV10(
        Material material,
        ColorAdjustBakeState state)
    {
        if (!CanBakeColorAdjustCommon(material, state))
        {
            return false;
        }

        if (!state.HasTint || !state.HasAssignedTintTexture)
        {
            return true;
        }

        if (!Mathf.Approximately(GetFloat(material, "_MainTintTextureUV", 0f), 0f))
            return false;
        if (!IsZeroVector(GetVector(material, "_MainTintTexturePan")))
            return false;

        return true;
    }

    private static bool CanBakeColorAdjustCommon(
        Material material,
        ColorAdjustBakeState state)
    {
        if (!Mathf.Approximately(GetFloat(material, "_MainTexStochastic", 0f), 0f))
            return false;
        if (!IsZeroVector(GetVector(material, "_MainTexPan")))
            return false;

        var mainTexUv = GetFloat(material, "_MainTexUV", 0f);
        if (!Mathf.Approximately(mainTexUv, 0f))
            return false;
        if (!Mathf.Approximately(GetFloat(material, "_ColorThemeIndex", 0f), 0f))
            return false;
        if (!Mathf.Approximately(GetFloat(material, "_MainPixelMode", 0f), 0f))
            return false;
        if (!Mathf.Approximately(GetFloat(material, "_VideoEffectsEnable", 0f), 0f))
            return false;

        if (state.UsesColorAdjustMask)
        {
            if (!IsZeroVector(GetVector(material, "_MainColorAdjustTexturePan")))
                return false;

            var colorAdjustUv = GetFloat(material, "_MainColorAdjustTextureUV", 0f);
            if (!Mathf.Approximately(colorAdjustUv, 0f))
                return false;
            if (!Mathf.Approximately(mainTexUv, colorAdjustUv))
                return false;
        }

        if (state.HasAnyHue && !state.CanBakeHue)
            return false;
        if (state.HasAnyHue && !Mathf.Approximately(GetFloat(material, "_MainHueGlobalMask", 0f), 0f))
            return false;
        if (state.HasSaturation && !Mathf.Approximately(GetFloat(material, "_MainSaturationGlobalMask", 0f), 0f))
            return false;
        if (state.HasBrightness && !Mathf.Approximately(GetFloat(material, "_MainBrightnessGlobalMask", 0f), 0f))
            return false;
        if (state.HasGamma && !Mathf.Approximately(GetFloat(material, "_MainGammaGlobalMask", 0f), 0f))
            return false;

        return true;
    }

    private static ColorAdjustBakeState EvaluateColorAdjustBakeState(Material material, bool isV10OrNewer)
    {
        var colorAdjustEnabled = material.HasProperty("_MainColorAdjustToggle")
            && !Mathf.Approximately(material.GetFloat("_MainColorAdjustToggle"), 0f);

        var shaderSaturation = GetFloat(material, PoiLightChangerPoiyomiShaderConstants.Saturation, 0f);
        var shaderBrightness = GetFloat(material, PoiLightChangerPoiyomiShaderConstants.MainBrightness, 0f);
        var shaderGamma = GetFloat(material, "_MainGamma", 1f);
        var colorGradingToggle = GetFloat(material, "_ColorGradingToggle", 0f);
        var shaderGradationStrength = colorGradingToggle > 0.5f
            ? GetFloat(material, "_MainGradationStrength", 0f)
            : 0f;

        var hueShiftToggle = GetFloat(material, "_MainHueShiftToggle", 0f);
        var hueShiftSpeed = GetFloat(material, "_MainHueShiftSpeed", 0f);
        var hueShiftAudioLink = GetFloat(material, "_MainHueALCTEnabled", 0f);
        var canBakeHue = hueShiftToggle > 0.5f
            && Mathf.Approximately(hueShiftSpeed, 0f)
            && hueShiftAudioLink < 0.5f;
        var rawShaderHue = GetFloat(material, PoiLightChangerPoiyomiShaderConstants.MainHueShift, 0f);

        var hasAnyHue = hueShiftToggle > 0.5f && (
            Mathf.Abs(rawShaderHue) > 0.001f
            || !Mathf.Approximately(hueShiftSpeed, 0f)
            || hueShiftAudioLink >= 0.5f);
        var hasHue = canBakeHue && !Mathf.Approximately(rawShaderHue, 0f);
        var hasSaturation = !Mathf.Approximately(shaderSaturation, 0f);
        var hasBrightness = !Mathf.Approximately(shaderBrightness, 0f);
        var hasGamma = Mathf.Abs(shaderGamma - 1f) > 0.001f;
        var hasGradation = colorGradingToggle > 0.5f && !Mathf.Approximately(shaderGradationStrength, 0f);
        var hasChromatize = isV10OrNewer
            && !Mathf.Approximately(GetFloat(material, "_MainChromatize", 0f), 0f);
        var hasTint = false;
        if (isV10OrNewer && material.HasProperty("_MainTintColor"))
        {
            hasTint = material.GetColor("_MainTintColor").a > 0f;
        }

        var hasAnyEffect = colorAdjustEnabled
            && (hasAnyHue || hasSaturation || hasBrightness || hasGamma || hasGradation || hasChromatize || hasTint);

        return new ColorAdjustBakeState(
            hasAnyEffect,
            hasAnyHue,
            canBakeHue,
            hasHue,
            hasSaturation,
            hasBrightness,
            hasGamma,
            hasGradation,
            hasTint,
            material.HasProperty("_MainColorAdjustTexture") && material.GetTexture("_MainColorAdjustTexture") != null,
            material.HasProperty("_MainGradationTex") && material.GetTexture("_MainGradationTex") != null,
            isV10OrNewer && material.HasProperty("_MainTintTexture") && material.GetTexture("_MainTintTexture") != null);
    }

    private static float GetFloat(Material material, string propertyName, float defaultValue)
    {
        return material.HasProperty(propertyName)
            ? material.GetFloat(propertyName)
            : defaultValue;
    }

    private static string GetBasePropertyName(string propertyName)
    {
        var dot = propertyName.IndexOf('.');
        return dot >= 0 ? propertyName.Substring(0, dot) : propertyName;
    }

    private static bool MaterialHasFloatProperty(Material material, string propertyName)
    {
        return material.HasProperty(GetBasePropertyName(propertyName));
    }

    private void ApplyMaterialPropertyDrawers(Material material)
    {
        if (material == null)
        {
            return;
        }

        try
        {
            MaterialEditor.ApplyMaterialPropertyDrawers(material);
        }
        catch (Exception ex)
        {
            ReportDiagnosticOnce(
                $"MaterialDrawerApplyFailed:{material.name}",
                PoiLightChangerDiagnostics.CreateProcessorDiagnostic(
                    PoiLightChangerDiagnosticId.MaterialDrawerApplyFailed,
                    string.Empty,
                    string.Empty,
                    $"[Poi Light Changer] Failed to apply material property drawers for '{material.name}'. See Console for details.",
                    ErrorSeverity.NonFatal,
                    false,
                    material));
            Debug.LogWarning($"[Poi Light Changer] Failed to apply material property drawers for '{material.name}'. {ex}");
        }
    }

    private static void SetMaterialFloatProperty(Material material, string propertyName, float value)
    {
        var dot = propertyName.IndexOf('.');
        if (dot >= 0)
        {
            var vecName = propertyName.Substring(0, dot);
            if (!material.HasProperty(vecName)) return;
            var vec = material.GetVector(vecName);
            switch (propertyName.Substring(dot + 1))
            {
                case "x": case "r": vec.x = value; break;
                case "y": case "g": vec.y = value; break;
                case "z": case "b": vec.z = value; break;
                case "w": case "a": vec.w = value; break;
                default: return;
            }
            material.SetVector(vecName, vec);
        }
        else
        {
            material.SetFloat(propertyName, value);
        }
    }

    private static bool TryApplyCommonIntOverride(
        Material material,
        string propertyName,
        PoiLightChangerIntOverrideValue overrideValue)
    {
        if (overrideValue == null || !overrideValue.Enable)
        {
            return false;
        }

        return TryApplyCommonFloatValue(material, propertyName, overrideValue.Value);
    }

    private static bool TryApplyCommonBoolOverride(
        Material material,
        string propertyName,
        PoiLightChangerBoolOverrideValue overrideValue,
        string keyword = null)
    {
        if (overrideValue == null || !overrideValue.Enable)
        {
            return false;
        }

        var changed = TryApplyCommonFloatValue(material, propertyName, overrideValue.Value ? 1f : 0f);
        if (!string.IsNullOrEmpty(keyword))
        {
            if (overrideValue.Value)
            {
                material.EnableKeyword(keyword);
            }
            else
            {
                material.DisableKeyword(keyword);
            }

            changed = true;
        }

        return changed;
    }

    private static bool TryApplyCommonFloatValue(Material material, string propertyName, float value)
    {
        if (material == null || !MaterialHasFloatProperty(material, propertyName))
        {
            return false;
        }

        SetMaterialFloatProperty(material, propertyName, value);
        return true;
    }

    private static Vector4 GetVector(Material material, string propertyName)
    {
        return material.HasProperty(propertyName)
            ? material.GetVector(propertyName)
            : Vector4.zero;
    }

    private static bool IsZeroVector(Vector4 value)
    {
        return Mathf.Approximately(value.x, 0f)
            && Mathf.Approximately(value.y, 0f)
            && Mathf.Approximately(value.z, 0f)
            && Mathf.Approximately(value.w, 0f);
    }

    private void ApplyBakedMainTexture(Material material, Texture mainTex, Texture2D baked)
    {
        if (component.Bake.AllowForceOverrideSameReference)
        {
            PoiLightChangerTextureBaker.ReplaceAllTextureReferences(material, mainTex, baked);
        }
        else
        {
            material.SetTexture("_MainTex", baked);
        }
    }

    private static void ResetLegacyColorAdjustProperties(Material material)
    {
        if (material.HasProperty("_MainColorAdjustToggle"))
            material.SetFloat("_MainColorAdjustToggle", 0f);
        material.DisableKeyword("COLOR_GRADING_HDR");

        if (material.HasProperty("_MainHueShiftToggle"))
            material.SetFloat("_MainHueShiftToggle", 0f);
        if (material.HasProperty(PoiLightChangerPoiyomiShaderConstants.MainHueShift))
            material.SetFloat(PoiLightChangerPoiyomiShaderConstants.MainHueShift, 0f);
        if (material.HasProperty("_MainHueShiftSpeed"))
            material.SetFloat("_MainHueShiftSpeed", 0f);
        if (material.HasProperty(PoiLightChangerPoiyomiShaderConstants.Saturation))
            material.SetFloat(PoiLightChangerPoiyomiShaderConstants.Saturation, 0f);
        if (material.HasProperty(PoiLightChangerPoiyomiShaderConstants.MainBrightness))
            material.SetFloat(PoiLightChangerPoiyomiShaderConstants.MainBrightness, 0f);
        if (material.HasProperty("_MainGamma"))
            material.SetFloat("_MainGamma", 1f);
        if (material.HasProperty("_MainGradationStrength"))
            material.SetFloat("_MainGradationStrength", 0f);
        if (material.HasProperty("_ColorGradingToggle"))
            material.SetFloat("_ColorGradingToggle", 0f);
    }

    private static void CleanupBakedInputTextures(Material material, ColorAdjustBakeState state)
    {
        if (state.UsesColorAdjustMask
            && state.HasAssignedColorAdjustTexture
            && material.HasProperty("_MainColorAdjustTexture")
            && material.GetTag("_MainColorAdjustTextureAnimated", false) != "1")
        {
            material.SetTexture("_MainColorAdjustTexture", null);
        }

        if (state.HasGradation
            && state.HasAssignedGradationTexture
            && material.HasProperty("_MainGradationTex")
            && material.GetTag("_MainGradationTexAnimated", false) != "1")
        {
            material.SetTexture("_MainGradationTex", null);
        }

        if (state.HasTint
            && state.HasAssignedTintTexture
            && material.HasProperty("_MainTintTexture")
            && material.GetTag("_MainTintTextureAnimated", false) != "1")
        {
            material.SetTexture("_MainTintTexture", null);
        }
    }

    public void GenerateImplementedControls()
    {
        if (component == null) return;

        if (targetMaterials.Count == 0 || targetRenderers.Count == 0)
        {
            return;
        }

        try
        {
            UpdateGenerateImplementedControlsProgress(0.00f, "Preparing animated properties");
            PrepareAnimatedProperties();

            var implementedControls = GetAnimatedFloatControls();
            if (implementedControls.Length == 0)
            {
                Debug.Log("[Poi Light Changer] No enabled and animated controls were found. Skipping menu and parameter generation.");
                CleanupComponentMenuItems(component.gameObject);
                return;
            }

            UpdateGenerateImplementedControlsProgress(0.08f, "Preparing generated root");
            var generatedRoot = PrepareGeneratedRoot();

            UpdateGenerateImplementedControlsProgress(0.16f, "Configuring parameters");
            ConfigureParameters(generatedRoot);

            UpdateGenerateImplementedControlsProgress(0.28f, "Configuring menu");
            ConfigureMenu(generatedRoot, implementedControls);

            UpdateGenerateImplementedControlsProgress(0.40f, "Configuring animator");
            ConfigureAnimator(generatedRoot, implementedControls);

            UpdateGenerateImplementedControlsProgress(1.00f, "Finishing generated controls");
        }
        finally
        {
            EditorUtility.ClearProgressBar();
        }
    }

    private void ApplyRequiredSectionMaterialValues()
    {
        if (IsSectionAvailable(PoiLightChangerControlSectionId.Color))
        {
            foreach (var material in targetMaterials.Where(material => material != null))
            {
                if (MaterialHasFloatProperty(material, PoiLightChangerPoiyomiShaderConstants.PostProcess))
                {
                    SetMaterialFloatProperty(material, PoiLightChangerPoiyomiShaderConstants.PostProcess, 1.0f);
                }

                material.EnableKeyword("POSTPROCESS");
                ApplyMaterialPropertyDrawers(material);
            }
        }

        if (IsSectionAvailable(PoiLightChangerControlSectionId.Proximity) &&
            component.Poiyomi.ProximityFeatureMode == PoiLightChangerMaterialFeatureMode.ForceEnable)
        {
            foreach (var material in targetMaterials.Where(material => material != null))
            {
                if (MaterialHasFloatProperty(material, PoiLightChangerPoiyomiShaderConstants.FxProximityColor))
                {
                    SetMaterialFloatProperty(material, PoiLightChangerPoiyomiShaderConstants.FxProximityColor, 1.0f);
                }

                ApplyMaterialPropertyDrawers(material);
            }
        }

        if (IsSectionAvailable(PoiLightChangerControlSectionId.Outline))
        {
            var requiresOutlineRuntimeSupport =
                component.Poiyomi.OutlineToggle.Enable ||
                component.Poiyomi.OutlineLineColor.Enable ||
                component.Poiyomi.OutlineLineWidth.Enable ||
                component.Poiyomi.OutlineFixedSize.Enable ||
                component.Poiyomi.OutlineFixWidth.Enable ||
                component.Poiyomi.OutlineEmission.Enable ||
                component.Poiyomi.OutlineOffsetZ.Enable;
            var shouldForceOutlineFeature =
                component.Poiyomi.OutlineFeatureMode == PoiLightChangerMaterialFeatureMode.ForceEnable;

            foreach (var material in targetMaterials.Where(material => material != null))
            {
                var changed = false;

                if (shouldForceOutlineFeature &&
                    requiresOutlineRuntimeSupport &&
                    MaterialHasFloatProperty(material, PoiLightChangerPoiyomiShaderConstants.EnableOutlines))
                {
                    SetMaterialFloatProperty(material, PoiLightChangerPoiyomiShaderConstants.EnableOutlines, 1.0f);
                    changed = true;
                }

                if (component.Poiyomi.RemoveOutlineTexture && material.HasProperty(PoiLightChangerPoiyomiShaderConstants.OutlineTexture))
                {
                    material.SetTexture(PoiLightChangerPoiyomiShaderConstants.OutlineTexture, null);
                    changed = true;
                }

                if (changed)
                {
                    ApplyMaterialPropertyDrawers(material);
                }
            }
        }

        if (IsSectionAvailable(PoiLightChangerControlSectionId.Backlight) &&
            component.Poiyomi.BacklightFeatureMode == PoiLightChangerMaterialFeatureMode.ForceEnable)
        {
            foreach (var material in targetMaterials.Where(material => material != null))
            {
                if (MaterialHasFloatProperty(material, PoiLightChangerPoiyomiShaderConstants.BacklightEnabled))
                {
                    SetMaterialFloatProperty(material, PoiLightChangerPoiyomiShaderConstants.BacklightEnabled, 1.0f);
                }

                material.EnableKeyword("POI_BACKLIGHT");
                ApplyMaterialPropertyDrawers(material);
            }
        }

        if (IsSectionAvailable(PoiLightChangerControlSectionId.SSAO) &&
            component.Poiyomi.SSAOFeatureMode == PoiLightChangerMaterialFeatureMode.ForceEnable)
        {
            foreach (var material in targetMaterials.Where(material => material != null))
            {
                if (MaterialHasFloatProperty(material, PoiLightChangerPoiyomiShaderConstants.SsaoEnabled))
                {
                    SetMaterialFloatProperty(material, PoiLightChangerPoiyomiShaderConstants.SsaoEnabled, 1.0f);
                }

                material.EnableKeyword("POI_SSAO");
                ApplyMaterialPropertyDrawers(material);
            }
        }

        if (IsSectionAvailable(PoiLightChangerControlSectionId.ContactShadow) &&
            component.Poiyomi.ContactShadowFeatureMode == PoiLightChangerMaterialFeatureMode.ForceEnable)
        {
            foreach (var material in targetMaterials.Where(material => material != null))
            {
                if (MaterialHasFloatProperty(material, PoiLightChangerPoiyomiShaderConstants.ContactShadowsEnabled))
                {
                    SetMaterialFloatProperty(material, PoiLightChangerPoiyomiShaderConstants.ContactShadowsEnabled, 1.0f);
                }

                material.EnableKeyword("POI_CONTACT_SHADOWS");
                ApplyMaterialPropertyDrawers(material);
            }
        }
    }

    private bool IsSupportedPoiyomiMaterial(Material material)
    {
        if (material == null || material.shader == null)
        {
            return false;
        }

        var shaderInfo = PoiLightChangerDiagnostics.GetPoiyomiShaderInfo(material.shader);
        if (!shaderInfo.IsPoiyomiShader)
        {
            return false;
        }

        return true;
    }

    private void RecordSkippedMaterial(Material material)
    {
        if (material == null || material.shader == null)
        {
            return;
        }

        var shaderInfo = PoiLightChangerDiagnostics.GetPoiyomiShaderInfo(material.shader);
        if (shaderInfo.IsPoiyomiShader)
        {
            unsupportedPoiyomiMaterialNames.Add(material.name);
            return;
        }

        nonPoiyomiMaterialNames.Add(material.name);
    }

    private void ReportDiagnosticOnce(string key, PoiLightChangerDiagnosticEntry diagnostic)
    {
        if (string.IsNullOrEmpty(key) || diagnostic == null || !reportedDiagnosticKeys.Add(key))
        {
            return;
        }

        PoiLightChangerDiagnostics.ReportNdmfDiagnostic(diagnostic);
    }

    private GameObject PrepareGeneratedRoot()
    {
        if (generatedRootObject != null)
        {
            return generatedRootObject;
        }

        var existing = component.transform.Find(GeneratedRootName);
        if (existing != null)
        {
            UnityEngine.Object.DestroyImmediate(existing.gameObject);
        }

        generatedRootObject = new GameObject(GeneratedRootName);
        generatedRootObject.transform.SetParent(component.transform, false);
        return generatedRootObject;
    }

    private void ConfigureParameters(GameObject generatedRoot)
    {
        var parameters = generatedRoot.GetComponent<ModularAvatarParameters>();
        if (parameters == null)
        {
            parameters = generatedRoot.AddComponent<ModularAvatarParameters>();
        }

        var prefix = PoiLightChangerGeneralSettings.DefaultParameterPrefix;
        parameters.parameters.Clear();
        parameters.parameters.Add(new ParameterConfig
        {
            nameOrPrefix = $"{prefix}/Weight",
            syncType = ParameterSyncType.NotSynced,
            saved = false,
            defaultValue = 1.0f,
            hasExplicitDefaultValue = true,
            localOnly = true,
        });

        var directLayout = PoiLightChangerParameterProvider.GetDirectParameterLayout(component, licenseSnapshot);
        var compressionPlan = PoiLightChangerBuildFeatureOverrides.ShouldUseParameterCompression(component, licenseSnapshot)
            ? PoiLightChangerParameterCompression.BuildPlanFromSlots(directLayout, component.Sync.CompressionChannelCount)
            : null;

        foreach (var slot in PoiLightChangerParameterCompression.RewriteSlots(directLayout, compressionPlan))
        {
            parameters.parameters.Add(new ParameterConfig
            {
                nameOrPrefix = slot.Name,
                syncType = ResolveParameterSyncType(slot),
                saved = slot.Saved,
                defaultValue = slot.DefaultValue,
                hasExplicitDefaultValue = true,
                localOnly = !slot.Synced,
            });
        }
    }

        private void ConfigureMenu(GameObject generatedRoot, IReadOnlyList<ImplementedFloatControl> implementedControls)
        {
            var go = component.gameObject;

            var rootMenuItem = go.GetComponent<ModularAvatarMenuItem>();
            if (rootMenuItem == null)
            {
                rootMenuItem = go.AddComponent<ModularAvatarMenuItem>();
            }

            rootMenuItem.Control = rootMenuItem.Control ?? new VRCExpressionsMenu.Control();
            rootMenuItem.Control.type = VRCExpressionsMenu.Control.ControlType.SubMenu;
            rootMenuItem.Control.name = PoiLightChangerPlugin.Title;
            rootMenuItem.Control.icon = LoadDefaultRootMenuIcon();
            rootMenuItem.label = PoiLightChangerPlugin.Title;
            rootMenuItem.MenuSource = SubmenuSource.Children;

            if (!go.TryGetComponent<ModularAvatarMenuInstaller>(out _))
            {
                go.AddComponent<ModularAvatarMenuInstaller>();
            }

            CleanupManagedMenuItems(go, GetImplementedFloatControls(), implementedControls);
            var directLayout = PoiLightChangerParameterProvider.GetDirectParameterLayout(component, licenseSnapshot);
            var slotByName = directLayout
                .GroupBy(slot => slot.Name, StringComparer.Ordinal)
                .ToDictionary(group => group.Key, group => group.Last(), StringComparer.Ordinal);

            foreach (var implementedControl in implementedControls.Where(c => !c.IsSecondaryComponent))
            {
                var animatorParameterName = implementedControl.OverrideParameterName
                    ?? PoiLightChangerControlRegistry.ComposeAnimatorParameterName(component, implementedControl.Definition);
                var menuParameterName = implementedControl.OverrideMenuParameterName ?? animatorParameterName;
                var item = GetOrCreateControlMenuItem(go, implementedControl);

                if (implementedControl.IsToggle)
                {
                    item.Control.type = VRCExpressionsMenu.Control.ControlType.Toggle;
                    item.Control.parameter = new VRCExpressionsMenu.Control.Parameter { name = menuParameterName };
                    item.Control.value = 1f;
                }
                else
                {
                    item.Control.type = VRCExpressionsMenu.Control.ControlType.RadialPuppet;
                    item.Control.subParameters = new[]
                    {
                        new VRCExpressionsMenu.Control.Parameter { name = menuParameterName },
                    };
                }

                if (slotByName.TryGetValue(menuParameterName, out var slot))
                {
                    item.isSynced = slot.Synced;
                    item.isSaved = slot.Saved;
                }
                else
                {
                    item.isSynced = implementedControl.Control.Synced;
                    item.isSaved = implementedControl.Control.Saved;
                }
            }
    }

    private void ConfigureAnimator(GameObject generatedRoot, IReadOnlyList<ImplementedFloatControl> implementedControls)
    {
        var controller = new AnimatorController
        {
            name = "Poi Light Changer Controls",
        };
        context.AssetSaver.SaveAsset(controller);

        var prefix = PoiLightChangerGeneralSettings.DefaultParameterPrefix;
        var weightParam = $"{prefix}/Weight";
        controller.AddParameter(weightParam, AnimatorControllerParameterType.Float);
        SetAnimatorParameterDefault(controller, weightParam, 1.0f);

        var directBlendTree = new BlendTree
        {
            name = "Poi Light Changer Root",
            blendType = BlendTreeType.Direct,
            blendParameter = weightParam,
            useAutomaticThresholds = false,
        };

        var rootLayer = AddLayer(controller, "Poi Light Changer Controls");
        rootLayer.defaultWeight = 1.0f;
        var rootState = rootLayer.stateMachine.AddState("Poi Light Changer Controls");
        rootState.motion = directBlendTree;
        rootState.writeDefaultValues = component.General.WriteDefaults != PoiLightChangerWriteDefaultsMode.ForceOff;
        rootState.timeParameterActive = false;
        rootLayer.stateMachine.defaultState = rootState;
        ReplaceLastLayer(controller, rootLayer);

        var serializedBlendTree = new SerializedObject(directBlendTree);
        var childrenProp = serializedBlendTree.FindProperty("m_Childs");
        var backlightAnimatorContext = GetBacklightAnimatorContext(implementedControls);
        var outlineAnimatorContext = GetOutlineAnimatorContext(implementedControls);
        var proximityAnimatorContext = GetProximityAnimatorContext(implementedControls);
        var animatedOutlineLineColorControl = implementedControls.FirstOrDefault(control =>
            control.Definition.Id == PoiLightChangerControlId.OutlineLineColor &&
            control.Control is { Enable: true, Animation: true });

        for (var index = 0; index < implementedControls.Count; index++)
        {
            var implementedControl = implementedControls[index];
            UpdateGenerateImplementedControlsAnimatorProgress(index, implementedControls.Count, implementedControl);

            if (backlightAnimatorContext != null &&
                !backlightAnimatorContext.UsesMergedSync &&
                ReferenceEquals(implementedControl, backlightAnimatorContext.BorderControl))
            {
                continue;
            }

            if (outlineAnimatorContext != null &&
                !outlineAnimatorContext.UsesMergedSync &&
                ReferenceEquals(implementedControl, outlineAnimatorContext.LineWidthControl))
            {
                continue;
            }

            if (proximityAnimatorContext != null &&
                (ReferenceEquals(implementedControl, proximityAnimatorContext.MinDistanceControl) ||
                 ReferenceEquals(implementedControl, proximityAnimatorContext.MaxDistanceControl)))
            {
                continue;
            }

            var parameterName = implementedControl.OverrideParameterName
                ?? PoiLightChangerControlRegistry.ComposeAnimatorParameterName(component, implementedControl.Definition);
            var normalizedDefaultValue = NormalizeFloatControlValue(implementedControl.Control);
            var effectiveMaterialPropertyName = implementedControl.OverrideMaterialPropertyName ?? implementedControl.Definition.MaterialPropertyName;

            AnimationClip clipZero, clipOne;

            if (proximityAnimatorContext != null &&
                ReferenceEquals(implementedControl, proximityAnimatorContext.ToggleControl))
            {
                var onBlendTree = new BlendTree
                {
                    name = $"{implementedControl.Label} BlendTree",
                    blendType = BlendTreeType.Simple1D,
                    blendParameter = parameterName,
                    useAutomaticThresholds = false,
                };
                onBlendTree.AddChild(
                    CreateMaterialFloatPropertiesClip(
                        $"{implementedControl.Label} Off",
                        new Dictionary<string, float?>
                        {
                            [PoiLightChangerPoiyomiShaderConstants.FxProximityColorMinDistance] = 0.0f,
                            [PoiLightChangerPoiyomiShaderConstants.FxProximityColorMaxDistance] = 0.0f,
                        }),
                    0.0f);
                onBlendTree.AddChild(
                    CreateProximityToggleOnMotion(controller, weightParam, proximityAnimatorContext),
                    1.0f);
                context.AssetSaver.SaveAsset(onBlendTree);

                controller.AddParameter(parameterName, AnimatorControllerParameterType.Float);
                SetAnimatorParameterDefault(controller, parameterName, normalizedDefaultValue);
                directBlendTree.AddChild(onBlendTree);

                serializedBlendTree.Update();
                var proximityChildProp = childrenProp.GetArrayElementAtIndex(directBlendTree.children.Length - 1);
                proximityChildProp.FindPropertyRelative("m_DirectBlendParameter").stringValue = weightParam;
                serializedBlendTree.ApplyModifiedPropertiesWithoutUndo();
                continue;
            }

            if (backlightAnimatorContext != null &&
                ReferenceEquals(implementedControl, backlightAnimatorContext.ToggleControl))
            {
                if (backlightAnimatorContext.UsesMergedSync)
                {
                    EnsureControllerFloatParameter(controller, parameterName, normalizedDefaultValue);
                    continue;
                }

                var onParameterName = parameterName;
                var borderPropertyName = backlightAnimatorContext.BorderControl?.OverrideMaterialPropertyName
                    ?? PoiLightChangerPoiyomiShaderConstants.BacklightBorder;
                Motion onMotion;

                if (backlightAnimatorContext.BorderControl != null)
                {
                    var borderParameterName = backlightAnimatorContext.BorderControl.OverrideParameterName
                        ?? PoiLightChangerControlRegistry.ComposeAnimatorParameterName(component, backlightAnimatorContext.BorderControl.Definition);
                    var borderControl = backlightAnimatorContext.BorderControl.Control;

                    var borderBlendTree = new BlendTree
                    {
                        name = $"{backlightAnimatorContext.BorderControl.Label} BlendTree",
                        blendType = BlendTreeType.Simple1D,
                        blendParameter = borderParameterName,
                        useAutomaticThresholds = false,
                    };
                    borderBlendTree.AddChild(
                        CreateMaterialFloatClip(
                            $"{backlightAnimatorContext.BorderControl.Label} Min",
                            borderPropertyName,
                            backlightAnimatorContext.BorderControl.OverrideMinValue ?? borderControl.Range.x,
                            backlightAnimatorContext.BorderControl.AdditionalAnimatedProperties,
                            backlightAnimatorContext.BorderControl.ConstantProperties),
                        0.0f);
                    borderBlendTree.AddChild(
                        CreateMaterialFloatClip(
                            $"{backlightAnimatorContext.BorderControl.Label} Max",
                            borderPropertyName,
                            backlightAnimatorContext.BorderControl.OverrideMaxValue ?? borderControl.Range.y,
                            backlightAnimatorContext.BorderControl.AdditionalAnimatedProperties,
                            backlightAnimatorContext.BorderControl.ConstantProperties),
                        1.0f);
                    context.AssetSaver.SaveAsset(borderBlendTree);

                    controller.AddParameter(borderParameterName, AnimatorControllerParameterType.Float);
                    SetAnimatorParameterDefault(controller, borderParameterName, NormalizeFloatControlValue(borderControl));
                    onMotion = borderBlendTree;
                }
                else
                {
                    onMotion = CreateMaterialFloatClip(
                        $"{implementedControl.Label} On",
                        borderPropertyName,
                        null,
                        NoAdditionalAnimatedProperties,
                        NoConstantProperties);
                }

                var onBlendTree = new BlendTree
                {
                    name = $"{implementedControl.Label} BlendTree",
                    blendType = BlendTreeType.Simple1D,
                    blendParameter = onParameterName,
                    useAutomaticThresholds = false,
                };
                onBlendTree.AddChild(
                    CreateMaterialFloatClip(
                        $"{implementedControl.Label} Off",
                        borderPropertyName,
                        1.0f,
                        NoAdditionalAnimatedProperties,
                        NoConstantProperties),
                    0.0f);
                onBlendTree.AddChild(onMotion, 1.0f);
                context.AssetSaver.SaveAsset(onBlendTree);

                controller.AddParameter(onParameterName, AnimatorControllerParameterType.Float);
                SetAnimatorParameterDefault(controller, onParameterName, normalizedDefaultValue);

                directBlendTree.AddChild(onBlendTree);

                serializedBlendTree.Update();
                var backlightChildProp = childrenProp.GetArrayElementAtIndex(directBlendTree.children.Length - 1);
                backlightChildProp.FindPropertyRelative("m_DirectBlendParameter").stringValue = weightParam;
                serializedBlendTree.ApplyModifiedPropertiesWithoutUndo();
                continue;
            }

            if (outlineAnimatorContext != null &&
                ReferenceEquals(implementedControl, outlineAnimatorContext.ToggleControl))
            {
                if (outlineAnimatorContext.UsesMergedSync)
                {
                    EnsureControllerFloatParameter(controller, parameterName, normalizedDefaultValue);
                    continue;
                }

                var onParameterName = parameterName;
                var lineWidthPropertyName = outlineAnimatorContext.LineWidthControl?.OverrideMaterialPropertyName
                    ?? PoiLightChangerPoiyomiShaderConstants.LineWidth;
                Motion onMotion;

                if (outlineAnimatorContext.LineWidthControl != null)
                {
                    var lineWidthParameterName = outlineAnimatorContext.LineWidthControl.OverrideParameterName
                        ?? PoiLightChangerControlRegistry.ComposeAnimatorParameterName(component, outlineAnimatorContext.LineWidthControl.Definition);
                    var lineWidthControl = outlineAnimatorContext.LineWidthControl.Control;

                    var lineWidthBlendTree = new BlendTree
                    {
                        name = $"{outlineAnimatorContext.LineWidthControl.Label} BlendTree",
                        blendType = BlendTreeType.Simple1D,
                        blendParameter = lineWidthParameterName,
                        useAutomaticThresholds = false,
                    };
                    lineWidthBlendTree.AddChild(
                        CreateMaterialFloatClip(
                            $"{outlineAnimatorContext.LineWidthControl.Label} Min",
                            lineWidthPropertyName,
                            outlineAnimatorContext.LineWidthControl.OverrideMinValue ?? lineWidthControl.Range.x,
                            outlineAnimatorContext.LineWidthControl.AdditionalAnimatedProperties,
                            outlineAnimatorContext.LineWidthControl.ConstantProperties),
                        0.0f);
                    lineWidthBlendTree.AddChild(
                        CreateMaterialFloatClip(
                            $"{outlineAnimatorContext.LineWidthControl.Label} Max",
                            lineWidthPropertyName,
                            outlineAnimatorContext.LineWidthControl.OverrideMaxValue ?? lineWidthControl.Range.y,
                            outlineAnimatorContext.LineWidthControl.AdditionalAnimatedProperties,
                            outlineAnimatorContext.LineWidthControl.ConstantProperties),
                        1.0f);
                    context.AssetSaver.SaveAsset(lineWidthBlendTree);

                    controller.AddParameter(lineWidthParameterName, AnimatorControllerParameterType.Float);
                    SetAnimatorParameterDefault(controller, lineWidthParameterName, NormalizeFloatControlValue(lineWidthControl));
                    onMotion = lineWidthBlendTree;
                }
                else
                {
                    onMotion = CreateMaterialFloatClip(
                        $"{implementedControl.Label} On",
                        lineWidthPropertyName,
                        null,
                        NoAdditionalAnimatedProperties,
                        NoConstantProperties);
                }

                var onBlendTree = new BlendTree
                {
                    name = $"{implementedControl.Label} BlendTree",
                    blendType = BlendTreeType.Simple1D,
                    blendParameter = onParameterName,
                    useAutomaticThresholds = false,
                };
                onBlendTree.AddChild(
                    CreateMaterialFloatClip(
                        $"{implementedControl.Label} Off",
                        lineWidthPropertyName,
                        0.0f,
                        NoAdditionalAnimatedProperties,
                        NoConstantProperties),
                    0.0f);
                onBlendTree.AddChild(onMotion, 1.0f);
                context.AssetSaver.SaveAsset(onBlendTree);

                controller.AddParameter(onParameterName, AnimatorControllerParameterType.Float);
                SetAnimatorParameterDefault(controller, onParameterName, normalizedDefaultValue);

                directBlendTree.AddChild(onBlendTree);

                serializedBlendTree.Update();
                var outlineChildProp = childrenProp.GetArrayElementAtIndex(directBlendTree.children.Length - 1);
                outlineChildProp.FindPropertyRelative("m_DirectBlendParameter").stringValue = weightParam;
                serializedBlendTree.ApplyModifiedPropertiesWithoutUndo();
                continue;
            }

            if (implementedControl.IsBacklightColorIntensityControl)
            {
                controller.AddParameter(parameterName, AnimatorControllerParameterType.Float);
                SetAnimatorParameterDefault(controller, parameterName, normalizedDefaultValue);

                var extraIntensityMax = Mathf.Max(0f, implementedControl.BacklightColorIntensityExtraMax);
                if (Mathf.Approximately(extraIntensityMax, 0f))
                {
                    continue;
                }

                var intensityDirectBlendTree = new BlendTree
                {
                    name = $"{implementedControl.Label} BlendTree",
                    blendType = BlendTreeType.Direct,
                    blendParameter = weightParam,
                    useAutomaticThresholds = false,
                };
                context.AssetSaver.SaveAsset(intensityDirectBlendTree);

                var serializedIntensityBlendTree = new SerializedObject(intensityDirectBlendTree);
                var intensityChildrenProp = serializedIntensityBlendTree.FindProperty("m_Childs");
                var colorChannels = new[]
                {
                    ("r", PoiLightChangerPoiyomiShaderConstants.BacklightColorR),
                    ("g", PoiLightChangerPoiyomiShaderConstants.BacklightColorG),
                    ("b", PoiLightChangerPoiyomiShaderConstants.BacklightColorB),
                };

                foreach (var (channelSuffix, materialProperty) in colorChannels)
                {
                    var channelParameterName = $"{prefix}/BacklightColor/{channelSuffix}";
                    var intensityBlendTree = new BlendTree
                    {
                        name = $"{implementedControl.Label} {channelSuffix} x{1f + extraIntensityMax:0.###}",
                        blendType = BlendTreeType.Simple1D,
                        blendParameter = channelParameterName,
                        useAutomaticThresholds = false,
                    };

                    intensityBlendTree.AddChild(
                        CreateMaterialFloatClip(
                            $"{implementedControl.Label} {channelSuffix} Min",
                            materialProperty,
                            0f,
                            NoAdditionalAnimatedProperties,
                            NoConstantProperties),
                        0.0f);
                    intensityBlendTree.AddChild(
                        CreateMaterialFloatClip(
                            $"{implementedControl.Label} {channelSuffix} Max",
                            materialProperty,
                            extraIntensityMax,
                            NoAdditionalAnimatedProperties,
                            NoConstantProperties),
                        1.0f);

                    context.AssetSaver.SaveAsset(intensityBlendTree);
                    intensityDirectBlendTree.AddChild(intensityBlendTree);

                    serializedIntensityBlendTree.Update();
                    var intensityChildProp = intensityChildrenProp.GetArrayElementAtIndex(intensityDirectBlendTree.children.Length - 1);
                    intensityChildProp.FindPropertyRelative("m_DirectBlendParameter").stringValue = parameterName;
                    serializedIntensityBlendTree.ApplyModifiedPropertiesWithoutUndo();
                }

                directBlendTree.AddChild(intensityDirectBlendTree);
                serializedBlendTree.Update();
                var intensityRootChildProp = childrenProp.GetArrayElementAtIndex(directBlendTree.children.Length - 1);
                intensityRootChildProp.FindPropertyRelative("m_DirectBlendParameter").stringValue = weightParam;
                serializedBlendTree.ApplyModifiedPropertiesWithoutUndo();

                continue;
            }
            else if (implementedControl.IsAdditiveVectorControl && implementedControl.AdditiveVectorKeyframes != null)
            {
                var multiKeyBlendTree = new BlendTree
                {
                    name = $"{implementedControl.Label} BlendTree",
                    blendType = BlendTreeType.Simple1D,
                    blendParameter = parameterName,
                    useAutomaticThresholds = false,
                };
                foreach (var kf in implementedControl.AdditiveVectorKeyframes)
                {
                    var clip = CreateVectorComponentClip(
                        $"{implementedControl.Label} {kf.Threshold:F2}",
                        implementedControl.VectorBasePropertyName,
                        implementedControl.VectorComponentIndex,
                        kf.ComponentValue);
                    multiKeyBlendTree.AddChild(clip, kf.Threshold);
                }
                context.AssetSaver.SaveAsset(multiKeyBlendTree);

                if (!implementedControl.IsSecondaryComponent)
                {
                    controller.AddParameter(parameterName, AnimatorControllerParameterType.Float);
                }
                directBlendTree.AddChild(multiKeyBlendTree);

                serializedBlendTree.Update();
                var childPropKf = childrenProp.GetArrayElementAtIndex(directBlendTree.children.Length - 1);
                childPropKf.FindPropertyRelative("m_DirectBlendParameter").stringValue = weightParam;
                serializedBlendTree.ApplyModifiedPropertiesWithoutUndo();

                if (!implementedControl.IsSecondaryComponent)
                {
                    SetAnimatorParameterDefault(controller, parameterName, normalizedDefaultValue);
                }
                continue;
            }
            else if (implementedControl.IsAdditiveVectorControl)
            {
                var minVal = implementedControl.OverrideMinValue ?? implementedControl.Control.Range.x;
                var maxVal = implementedControl.OverrideMaxValue ?? implementedControl.Control.Range.y;

                clipZero = CreateVectorComponentClip($"{implementedControl.Label} Min", implementedControl.VectorBasePropertyName, implementedControl.VectorComponentIndex, minVal);
                clipOne  = CreateVectorComponentClip($"{implementedControl.Label} Max", implementedControl.VectorBasePropertyName, implementedControl.VectorComponentIndex, maxVal);
            }
            else
            {
                clipZero = CreateMaterialFloatClip(
                    $"{implementedControl.Label} Min",
                    effectiveMaterialPropertyName,
                    ResolveOffClipValue(implementedControl),
                    implementedControl.AdditionalAnimatedProperties,
                    implementedControl.ConstantProperties,
                    implementedControl.LinkedToggleObject,
                    implementedControl.IsToggle ? false : null);
                clipOne = CreateMaterialFloatClip(
                    $"{implementedControl.Label} Max",
                    effectiveMaterialPropertyName,
                    ResolveOnClipValue(implementedControl),
                    implementedControl.AdditionalAnimatedProperties,
                    implementedControl.ConstantProperties,
                    implementedControl.LinkedToggleObject,
                    implementedControl.IsToggle ? true : null);
            }

            var blendTree = new BlendTree
            {
                name = $"{implementedControl.Label} BlendTree",
                blendType = BlendTreeType.Simple1D,
                blendParameter = parameterName,
                useAutomaticThresholds = false,
            };
            blendTree.AddChild(clipZero, 0.0f);
            blendTree.AddChild(clipOne, 1.0f);
            context.AssetSaver.SaveAsset(blendTree);

            controller.AddParameter(parameterName, AnimatorControllerParameterType.Float);
            directBlendTree.AddChild(blendTree);

            serializedBlendTree.Update();
            var childProp = childrenProp.GetArrayElementAtIndex(directBlendTree.children.Length - 1);
            childProp.FindPropertyRelative("m_DirectBlendParameter").stringValue = weightParam;
            serializedBlendTree.ApplyModifiedPropertiesWithoutUndo();

            SetAnimatorParameterDefault(controller, parameterName, normalizedDefaultValue);
        }

        if (animatedOutlineLineColorControl != null)
        {
            AddDirectBlendTreeChildMotion(
                directBlendTree,
                serializedBlendTree,
                childrenProp,
                weightParam,
                CreateMaterialFloatClip(
                    "Outline Line Color Alpha",
                    PoiLightChangerPoiyomiShaderConstants.LineColorA,
                    Mathf.Clamp01(component.Poiyomi.OutlineLineColor.Value.a),
                    NoAdditionalAnimatedProperties,
                    NoConstantProperties));
        }

        context.AssetSaver.SaveAsset(directBlendTree);
        EditorUtility.SetDirty(directBlendTree);

        ConfigureMergedPseudoToggleLayers(controller, backlightAnimatorContext, outlineAnimatorContext);

        if (PoiLightChangerBuildFeatureOverrides.ShouldUseParameterCompression(component, licenseSnapshot))
        {
            var directLayout = PoiLightChangerParameterProvider.GetDirectParameterLayout(component, licenseSnapshot);
            var compressionPlan = PoiLightChangerParameterCompression.BuildPlanFromSlots(
                directLayout,
                component.Sync.CompressionChannelCount);
            PoiLightChangerParameterCompression.ApplyToAnimatorController(controller, compressionPlan);
        }

        var mergeAnimator = generatedRoot.GetComponent<ModularAvatarMergeAnimator>();
        if (mergeAnimator == null)
        {
            mergeAnimator = generatedRoot.AddComponent<ModularAvatarMergeAnimator>();
        }

        mergeAnimator.animator = controller;
        mergeAnimator.layerType = VRCAvatarDescriptor.AnimLayerType.FX;
        mergeAnimator.pathMode = MergeAnimatorPathMode.Absolute;
        mergeAnimator.matchAvatarWriteDefaults = component.General.WriteDefaults == PoiLightChangerWriteDefaultsMode.MatchAvatar;
    }

    private static void UpdateCloneTargetMaterialsProgress(int index, int totalCount, IPoiLightChangerMaterialProvider provider)
    {
        var providerName = provider switch
        {
            PoiLightChangerRendererSharedMaterialProvider => "Renderer Shared Materials",
            PoiLightChangerAnimatedMaterialProvider => "Animated Material Curves",
            PoiLightChangerMaterialSetterMaterialProvider => "Material Setter References",
            PoiLightChangerMaterialSwapMaterialProvider => "Material Swap References",
            _ => provider?.GetType().Name ?? "Unknown",
        };

        var normalizedProgress = totalCount <= 0
            ? 0f
            : Mathf.Clamp01((float)index / totalCount);

        EditorUtility.DisplayProgressBar(
            "Poi Light Changer",
            $"Collecting target materials ({index + 1}/{Mathf.Max(totalCount, 1)}): {providerName}",
            normalizedProgress);
    }

    private static void UpdateGenerateImplementedControlsProgress(float progress, string status)
    {
        EditorUtility.DisplayProgressBar(
            "Poi Light Changer",
            $"Generating controls: {status}",
            Mathf.Clamp01(progress));
    }

    private static void UpdateGenerateImplementedControlsAnimatorProgress(
        int index,
        int totalCount,
        ImplementedFloatControl implementedControl)
    {
        var normalizedLoopProgress = totalCount <= 0
            ? 0f
            : (float)index / totalCount;
        var progress = Mathf.Lerp(0.45f, 0.95f, normalizedLoopProgress);
        var label = implementedControl?.Label;

        if (string.IsNullOrWhiteSpace(label))
        {
            label = implementedControl?.Definition?.MenuPath ?? "Unknown";
        }

        EditorUtility.DisplayProgressBar(
            "Poi Light Changer",
            $"Generating animator controls ({index + 1}/{Mathf.Max(totalCount, 1)}): {label}",
            Mathf.Clamp01(progress));
    }

    private void ConfigureMergedPseudoToggleLayers(
        AnimatorController controller,
        BacklightAnimatorContext backlightAnimatorContext,
        OutlineAnimatorContext outlineAnimatorContext)
    {
        if (backlightAnimatorContext?.UsesMergedSync == true)
        {
            ConfigureMergedPseudoToggleLayer(
                controller,
                "Poi Light Changer Backlight Toggle",
                backlightAnimatorContext.ToggleControl,
                backlightAnimatorContext.BorderControl,
                backlightAnimatorContext.StoredValueParameterName,
                1.0f);
        }

        if (outlineAnimatorContext?.UsesMergedSync == true)
        {
            ConfigureMergedPseudoToggleLayer(
                controller,
                "Poi Light Changer Outline Toggle",
                outlineAnimatorContext.ToggleControl,
                outlineAnimatorContext.LineWidthControl,
                outlineAnimatorContext.StoredValueParameterName,
                0.0f);
        }
    }

    private void ConfigureMergedPseudoToggleLayer(
        AnimatorController controller,
        string layerName,
        ImplementedFloatControl toggleControl,
        ImplementedFloatControl valueControl,
        string storedValueParameterName,
        float offValue)
    {
        if (controller == null || toggleControl == null || valueControl == null || string.IsNullOrWhiteSpace(storedValueParameterName))
        {
            return;
        }

        var toggleParameterName = toggleControl.OverrideParameterName
            ?? PoiLightChangerControlRegistry.ComposeAnimatorParameterName(component, toggleControl.Definition);
        var valueParameterName = valueControl.OverrideParameterName
            ?? PoiLightChangerControlRegistry.ComposeAnimatorParameterName(component, valueControl.Definition);

        EnsureControllerFloatParameter(controller, toggleParameterName, NormalizeFloatControlValue(toggleControl.Control));
        EnsureControllerFloatParameter(controller, valueParameterName, NormalizeFloatControlValue(valueControl.Control));
        EnsureControllerFloatParameter(controller, storedValueParameterName, NormalizeFloatControlValue(valueControl.Control));
        EnsureControllerParameter(controller, "IsLocal", AnimatorControllerParameterType.Bool);

        var loopClip = CreateTimingClip(controller, $"{layerName} Loop", 1f / 60f);

        var layer = AddLayer(controller, layerName);
        var stateMachine = layer.stateMachine;
        stateMachine.states = Array.Empty<ChildAnimatorState>();

        var onLoop = stateMachine.AddState("OnLoop", new Vector3(0f, 0f));
        onLoop.motion = loopClip;
        onLoop.writeDefaultValues = true;
        var onDriver = onLoop.AddStateMachineBehaviour<VRCAvatarParameterDriver>();
        onDriver.localOnly = true;
        onDriver.parameters = new List<VRC_AvatarParameterDriver.Parameter>
        {
            new()
            {
                type = VRC_AvatarParameterDriver.ChangeType.Copy,
                source = storedValueParameterName,
                name = valueParameterName,
            },
        };

        var offLoop = stateMachine.AddState("OffLoop", new Vector3(260f, 0f));
        offLoop.motion = loopClip;
        offLoop.writeDefaultValues = true;
        var offDriver = offLoop.AddStateMachineBehaviour<VRCAvatarParameterDriver>();
        offDriver.localOnly = true;
        offDriver.parameters = new List<VRC_AvatarParameterDriver.Parameter>
        {
            new()
            {
                type = VRC_AvatarParameterDriver.ChangeType.Set,
                name = valueParameterName,
                value = offValue,
            },
        };

        stateMachine.defaultState = toggleControl.Control.Value >= 0.5f ? onLoop : offLoop;

        var onToOn = onLoop.AddTransition(onLoop);
        onToOn.hasExitTime = true;
        onToOn.exitTime = 1f;
        onToOn.duration = 0f;
        onToOn.AddCondition(AnimatorConditionMode.If, 0f, "IsLocal");
        onToOn.AddCondition(AnimatorConditionMode.Greater, 0.5f, toggleParameterName);

        var onToOff = onLoop.AddTransition(offLoop);
        onToOff.hasExitTime = false;
        onToOff.duration = 0f;
        onToOff.AddCondition(AnimatorConditionMode.If, 0f, "IsLocal");
        onToOff.AddCondition(AnimatorConditionMode.Less, 0.5f, toggleParameterName);

        var offToOff = offLoop.AddTransition(offLoop);
        offToOff.hasExitTime = true;
        offToOff.exitTime = 1f;
        offToOff.duration = 0f;
        offToOff.AddCondition(AnimatorConditionMode.If, 0f, "IsLocal");
        offToOff.AddCondition(AnimatorConditionMode.Less, 0.5f, toggleParameterName);

        var offToOn = offLoop.AddTransition(onLoop);
        offToOn.hasExitTime = false;
        offToOn.duration = 0f;
        offToOn.AddCondition(AnimatorConditionMode.If, 0f, "IsLocal");
        offToOn.AddCondition(AnimatorConditionMode.Greater, 0.5f, toggleParameterName);

        ReplaceLastLayer(controller, layer);
    }

    private AnimationClip CreateTimingClip(AnimatorController controller, string clipName, float durationSeconds)
    {
        var clip = new AnimationClip
        {
            name = clipName,
            hideFlags = HideFlags.HideInHierarchy,
        };

        clip.SetCurve(
            "__PoiLightChanger_PseudoTogglePulse__",
            typeof(GameObject),
            "m_IsActive",
            AnimationCurve.Constant(0f, durationSeconds, 0f));

        AssetDatabase.AddObjectToAsset(clip, controller);
        return clip;
    }

    private AnimationClip CreateVectorComponentClip(string clipName, string vectorPropertyName, int componentIndex, float value)
    {
        var clip = new AnimationClip { name = clipName };
        var suffix = "xyzw"[componentIndex].ToString();

        foreach (var renderer in targetRenderers)
        {
            if (renderer == null) continue;

            var binding = EditorCurveBinding.FloatCurve(
                renderer.AvatarRootPath(),
                renderer.GetType(),
                $"{MaterialAnimationPropertyPrefix}{vectorPropertyName}.{suffix}");
            AnimationUtility.SetEditorCurve(clip, binding, AnimationCurve.Constant(0, 0, value));
        }

        context.AssetSaver.SaveAsset(clip);
        return clip;
    }

    private AnimationClip CreateMaterialFloatClip(
        string clipName,
        string materialPropertyName,
        float? fixedValue,
        IReadOnlyList<string> additionalAnimatedProperties,
        IReadOnlyDictionary<string, float> constantProperties,
        GameObject linkedToggleObject = null,
        bool? linkedToggleObjectActive = null)
    {
        var clip = new AnimationClip
        {
            name = clipName,
        };

        foreach (var renderer in targetRenderers)
        {
            if (renderer == null)
            {
                continue;
            }

            float value = fixedValue ?? 0f;
            if (!fixedValue.HasValue)
            {
                value = ResolveMaterialInitialFloatValue(renderer, materialPropertyName);
            }

            var binding = EditorCurveBinding.FloatCurve(
                renderer.AvatarRootPath(),
                renderer.GetType(),
                $"{MaterialAnimationPropertyPrefix}{materialPropertyName}");

            AnimationUtility.SetEditorCurve(clip, binding, AnimationCurve.Constant(0, 0, value));

            foreach (var animatedProperty in additionalAnimatedProperties)
            {
                var animatedBinding = EditorCurveBinding.FloatCurve(
                    renderer.AvatarRootPath(),
                    renderer.GetType(),
                    $"{MaterialAnimationPropertyPrefix}{animatedProperty}");

                AnimationUtility.SetEditorCurve(clip, animatedBinding, AnimationCurve.Constant(0, 0, value));
            }

            foreach (var constantProperty in constantProperties)
            {
                var constantBinding = EditorCurveBinding.FloatCurve(
                    renderer.AvatarRootPath(),
                    renderer.GetType(),
                    $"{MaterialAnimationPropertyPrefix}{constantProperty.Key}");

                AnimationUtility.SetEditorCurve(clip, constantBinding, AnimationCurve.Constant(0, 1.0f / 60.0f, constantProperty.Value));
            }
        }

        if (linkedToggleObject != null &&
            linkedToggleObjectActive.HasValue &&
            TryGetAvatarRelativeObjectPath(linkedToggleObject, out var linkedObjectPath))
        {
            var activeBinding = EditorCurveBinding.FloatCurve(
                linkedObjectPath,
                typeof(GameObject),
                "m_IsActive");
            AnimationUtility.SetEditorCurve(
                clip,
                activeBinding,
                AnimationCurve.Constant(0, 0, linkedToggleObjectActive.Value ? 1f : 0f));
        }

        context.AssetSaver.SaveAsset(clip);
        return clip;
    }

    private AnimationClip CreateMaterialFloatPropertiesClip(
        string clipName,
        IReadOnlyDictionary<string, float?> materialPropertyValues,
        IReadOnlyDictionary<string, float> constantProperties = null,
        GameObject linkedToggleObject = null,
        bool? linkedToggleObjectActive = null)
    {
        var clip = new AnimationClip
        {
            name = clipName,
        };

        foreach (var renderer in targetRenderers)
        {
            if (renderer == null)
            {
                continue;
            }

            foreach (var propertyValue in materialPropertyValues)
            {
                var value = propertyValue.Value ?? ResolveMaterialInitialFloatValue(renderer, propertyValue.Key);
                var binding = EditorCurveBinding.FloatCurve(
                    renderer.AvatarRootPath(),
                    renderer.GetType(),
                    $"{MaterialAnimationPropertyPrefix}{propertyValue.Key}");

                AnimationUtility.SetEditorCurve(clip, binding, AnimationCurve.Constant(0, 0, value));
            }

            if (constantProperties == null)
            {
                continue;
            }

            foreach (var constantProperty in constantProperties)
            {
                var constantBinding = EditorCurveBinding.FloatCurve(
                    renderer.AvatarRootPath(),
                    renderer.GetType(),
                    $"{MaterialAnimationPropertyPrefix}{constantProperty.Key}");

                AnimationUtility.SetEditorCurve(clip, constantBinding, AnimationCurve.Constant(0, 1.0f / 60.0f, constantProperty.Value));
            }
        }

        if (linkedToggleObject != null &&
            linkedToggleObjectActive.HasValue &&
            TryGetAvatarRelativeObjectPath(linkedToggleObject, out var linkedObjectPath))
        {
            var activeBinding = EditorCurveBinding.FloatCurve(
                linkedObjectPath,
                typeof(GameObject),
                "m_IsActive");
            AnimationUtility.SetEditorCurve(
                clip,
                activeBinding,
                AnimationCurve.Constant(0, 0, linkedToggleObjectActive.Value ? 1f : 0f));
        }

        context.AssetSaver.SaveAsset(clip);
        return clip;
    }

    private bool TryGetAvatarRelativeObjectPath(GameObject targetObject, out string path)
    {
        path = string.Empty;

        if (targetObject == null || context?.AvatarRootTransform == null)
        {
            return false;
        }

        var rootTransform = context.AvatarRootTransform;
        var current = targetObject.transform;
        if (current == rootTransform)
        {
            path = string.Empty;
            return true;
        }

        var segments = new List<string>();
        while (current != null && current != rootTransform)
        {
            segments.Add(current.name);
            current = current.parent;
        }

        if (current != rootTransform)
        {
            return false;
        }

        segments.Reverse();
        path = string.Join("/", segments);
        return true;
    }

    private float ResolveOffClipValue(ImplementedFloatControl implementedControl)
    {
        if (implementedControl.Definition.Id == PoiLightChangerControlId.LightDirectionToggle)
        {
            return ResolveLightDirectionToggleOffValue();
        }

        return implementedControl.OverrideMinValue ?? implementedControl.Control.Range.x;
    }

    private static float ResolveOnClipValue(ImplementedFloatControl implementedControl)
    {
        return implementedControl.OverrideMaxValue ?? implementedControl.Control.Range.y;
    }

    private float ResolveLightDirectionToggleOffValue()
    {
        if (component?.Overrides?.LightDirectionMode is { Enable: true } lightDirectionModeOverride)
        {
            return lightDirectionModeOverride.Value;
        }

        var modeCounts = new Dictionary<int, int>();
        foreach (var renderer in targetRenderers)
        {
            if (renderer == null)
            {
                continue;
            }

            var modeValue = Mathf.RoundToInt(ResolveMaterialInitialFloatValue(
                renderer,
                PoiLightChangerPoiyomiShaderConstants.LightingDirectionMode));

            if (!modeCounts.TryAdd(modeValue, 1))
            {
                modeCounts[modeValue]++;
            }
        }

        if (modeCounts.Count == 0)
        {
            return 0f;
        }

        return modeCounts
            .OrderByDescending(pair => pair.Value)
            .ThenBy(pair => Mathf.Abs(pair.Key))
            .ThenBy(pair => pair.Key)
            .First()
            .Key;
    }

    private IReadOnlyList<ImplementedFloatControl> GetImplementedFloatControls()
    {
        return PoiLightChangerControlBindingResolver.GetImplementedBindings(component, licenseSnapshot);
    }

    private ImplementedFloatControl[] GetAnimatedFloatControls()
    {
        return PoiLightChangerControlBindingResolver.GetAnimatedBindings(component, licenseSnapshot);
    }

    private bool IsFeatureAvailable(PoiLightChangerLicensedFeatureId featureId)
    {
        return PoiLightChangerLicenseFeatureGate.IsFeatureAvailable(featureId, licenseSnapshot);
    }

    private bool IsSectionAvailable(PoiLightChangerControlSectionId sectionId)
    {
        return PoiLightChangerControlRegistry.IsSectionEnabled(component, sectionId) &&
            PoiLightChangerLicenseFeatureGate.IsSectionAvailable(sectionId, licenseSnapshot);
    }

    private BacklightAnimatorContext GetBacklightAnimatorContext(IReadOnlyList<ImplementedFloatControl> implementedControls)
    {
        var toggleControl = implementedControls.FirstOrDefault(control =>
            control.Definition.Id == PoiLightChangerControlId.BacklightToggle &&
            control.Control is { Enable: true, Animation: true });
        var borderControl = implementedControls.FirstOrDefault(control =>
            control.Definition.Id == PoiLightChangerControlId.BacklightBorder &&
            control.Control is { Enable: true, Animation: true });

        if (toggleControl == null)
        {
            return null;
        }

        return new BacklightAnimatorContext
        {
            ToggleControl = toggleControl,
            BorderControl = borderControl,
            UsesMergedSync = PoiLightChangerPseudoToggleUtility.UsesMergedBacklightSync(component),
            StoredValueParameterName = PoiLightChangerPseudoToggleUtility.GetStoredValueParameterName(PoiLightChangerControlId.BacklightBorder),
        };
    }

    private OutlineAnimatorContext GetOutlineAnimatorContext(IReadOnlyList<ImplementedFloatControl> implementedControls)
    {
        var toggleControl = implementedControls.FirstOrDefault(control =>
            control.Definition.Id == PoiLightChangerControlId.OutlineToggle &&
            control.Control is { Enable: true, Animation: true });
        var lineWidthControl = implementedControls.FirstOrDefault(control =>
            control.Definition.Id == PoiLightChangerControlId.OutlineLineWidth &&
            control.Control is { Enable: true, Animation: true });

        if (toggleControl == null)
        {
            return null;
        }

        return new OutlineAnimatorContext
        {
            ToggleControl = toggleControl,
            LineWidthControl = lineWidthControl,
            UsesMergedSync = PoiLightChangerPseudoToggleUtility.UsesMergedOutlineSync(component),
            StoredValueParameterName = PoiLightChangerPseudoToggleUtility.GetStoredValueParameterName(PoiLightChangerControlId.OutlineLineWidth),
        };
    }

    private ProximityAnimatorContext GetProximityAnimatorContext(IReadOnlyList<ImplementedFloatControl> implementedControls)
    {
        var toggleControl = implementedControls.FirstOrDefault(control =>
            control.Definition.Id == PoiLightChangerControlId.ProximityToggle &&
            control.Control is { Enable: true, Animation: true });
        var minDistanceControl = implementedControls.FirstOrDefault(control =>
            control.Definition.Id == PoiLightChangerControlId.ProximityColorMinDistance &&
            control.Control is { Enable: true, Animation: true });
        var maxDistanceControl = implementedControls.FirstOrDefault(control =>
            control.Definition.Id == PoiLightChangerControlId.ProximityColorMaxDistance &&
            control.Control is { Enable: true, Animation: true });

        if (toggleControl == null)
        {
            return null;
        }

        return new ProximityAnimatorContext
        {
            ToggleControl = toggleControl,
            MinDistanceControl = minDistanceControl,
            MaxDistanceControl = maxDistanceControl,
        };
    }

    private Motion CreateProximityToggleOnMotion(
        AnimatorController controller,
        string weightParameterName,
        ProximityAnimatorContext proximityAnimatorContext)
    {
        if (proximityAnimatorContext == null)
        {
            return CreateMaterialFloatPropertiesClip(
                "Proximity Toggle On",
                new Dictionary<string, float?>
                {
                    [PoiLightChangerPoiyomiShaderConstants.FxProximityColorMinDistance] = null,
                    [PoiLightChangerPoiyomiShaderConstants.FxProximityColorMaxDistance] = null,
                });
        }

        var onMotion = new BlendTree
        {
            name = $"{proximityAnimatorContext.ToggleControl.Label} On Composite",
            blendType = BlendTreeType.Direct,
            blendParameter = weightParameterName,
            useAutomaticThresholds = false,
        };
        context.AssetSaver.SaveAsset(onMotion);

        var serializedOnMotion = new SerializedObject(onMotion);
        var onChildrenProp = serializedOnMotion.FindProperty("m_Childs");

        AddProximityDistanceMotion(
            controller,
            weightParameterName,
            onMotion,
            serializedOnMotion,
            onChildrenProp,
            proximityAnimatorContext.MinDistanceControl,
            PoiLightChangerPoiyomiShaderConstants.FxProximityColorMinDistance,
            "Proximity Min Distance");
        AddProximityDistanceMotion(
            controller,
            weightParameterName,
            onMotion,
            serializedOnMotion,
            onChildrenProp,
            proximityAnimatorContext.MaxDistanceControl,
            PoiLightChangerPoiyomiShaderConstants.FxProximityColorMaxDistance,
            "Proximity Max Distance");

        return onMotion;
    }

    private void AddProximityDistanceMotion(
        AnimatorController controller,
        string weightParameterName,
        BlendTree directBlendTree,
        SerializedObject serializedBlendTree,
        SerializedProperty childrenProp,
        ImplementedFloatControl distanceControl,
        string materialPropertyName,
        string fallbackLabel)
    {
        Motion childMotion;

        if (distanceControl != null)
        {
            var parameterName = distanceControl.OverrideParameterName
                ?? PoiLightChangerControlRegistry.ComposeAnimatorParameterName(component, distanceControl.Definition);
            var control = distanceControl.Control;
            var propertyName = distanceControl.OverrideMaterialPropertyName ?? materialPropertyName;

            var distanceBlendTree = new BlendTree
            {
                name = $"{distanceControl.Label} BlendTree",
                blendType = BlendTreeType.Simple1D,
                blendParameter = parameterName,
                useAutomaticThresholds = false,
            };
            distanceBlendTree.AddChild(
                CreateMaterialFloatClip(
                    $"{distanceControl.Label} Min",
                    propertyName,
                    distanceControl.OverrideMinValue ?? control.Range.x,
                    distanceControl.AdditionalAnimatedProperties,
                    distanceControl.ConstantProperties),
                0.0f);
            distanceBlendTree.AddChild(
                CreateMaterialFloatClip(
                    $"{distanceControl.Label} Max",
                    propertyName,
                    distanceControl.OverrideMaxValue ?? control.Range.y,
                    distanceControl.AdditionalAnimatedProperties,
                    distanceControl.ConstantProperties),
                1.0f);
            context.AssetSaver.SaveAsset(distanceBlendTree);

            controller.AddParameter(parameterName, AnimatorControllerParameterType.Float);
            SetAnimatorParameterDefault(controller, parameterName, NormalizeFloatControlValue(control));
            childMotion = distanceBlendTree;
        }
        else
        {
            childMotion = CreateMaterialFloatPropertiesClip(
                $"{fallbackLabel} Current",
                new Dictionary<string, float?>
                {
                    [materialPropertyName] = null,
                });
        }

        directBlendTree.AddChild(childMotion);
        serializedBlendTree.Update();
        var childProp = childrenProp.GetArrayElementAtIndex(directBlendTree.children.Length - 1);
        childProp.FindPropertyRelative("m_DirectBlendParameter").stringValue = weightParameterName;
        serializedBlendTree.ApplyModifiedPropertiesWithoutUndo();
    }

    private static void AddDirectBlendTreeChildMotion(
        BlendTree directBlendTree,
        SerializedObject serializedBlendTree,
        SerializedProperty childrenProp,
        string weightParameterName,
        Motion childMotion)
    {
        if (directBlendTree == null || serializedBlendTree == null || childrenProp == null || childMotion == null)
        {
            return;
        }

        directBlendTree.AddChild(childMotion);
        serializedBlendTree.Update();
        var childProp = childrenProp.GetArrayElementAtIndex(directBlendTree.children.Length - 1);
        childProp.FindPropertyRelative("m_DirectBlendParameter").stringValue = weightParameterName;
        serializedBlendTree.ApplyModifiedPropertiesWithoutUndo();
    }

    private static float NormalizeFloatControlValue(PoiLightChangerFloatControlValue control)
    {
        return PoiLightChangerControlBindingUtility.NormalizeFloatControlValue(control);
    }

    private static ParameterSyncType ResolveParameterSyncType(PoiLightChangerParameterSlot slot)
    {
        if (slot == null)
        {
            return ParameterSyncType.NotSynced;
        }

        return slot.ParameterType switch
        {
            AnimatorControllerParameterType.Int => ParameterSyncType.Int,
            AnimatorControllerParameterType.Bool => ParameterSyncType.Bool,
            _ => ParameterSyncType.Float,
        };
    }

    private static AnimatorControllerLayer AddLayer(AnimatorController controller, string layerName)
    {
        controller.AddLayer(layerName);
        var layers = controller.layers;
        var layer = layers[^1];
        layer.defaultWeight = 1.0f;
        layer.stateMachine.name = $"{layerName} StateMachine";
        layers[^1] = layer;
        controller.layers = layers;
        return layer;
    }

    private ModularAvatarMenuItem GetOrCreateControlMenuItem(GameObject componentObject, ImplementedFloatControl implementedControl)
    {
        return GetOrCreateMenuPath(
            componentObject,
            GetMenuPath(implementedControl),
            GetDisplayMenuPath(implementedControl),
            VRCExpressionsMenu.Control.ControlType.RadialPuppet);
    }

    private static void ReplaceLastLayer(AnimatorController controller, AnimatorControllerLayer layer)
    {
        var layers = controller.layers;
        if (layers.Length == 0)
        {
            controller.layers = new[] { layer };
            return;
        }

        layers[^1] = layer;
        controller.layers = layers;
    }

    private static void SetAnimatorParameterDefault(AnimatorController controller, string parameterName, float defaultValue)
    {
        var parameters = controller.parameters;
        for (var index = 0; index < parameters.Length; index++)
        {
            var parameter = parameters[index];
            if (parameter.name != parameterName)
            {
                continue;
            }

            parameter.defaultFloat = defaultValue;
            parameters[index] = parameter;
            controller.parameters = parameters;
            return;
        }
    }

    private static void EnsureControllerFloatParameter(AnimatorController controller, string parameterName, float defaultValue)
    {
        if (controller == null || string.IsNullOrWhiteSpace(parameterName))
        {
            return;
        }

        EnsureControllerParameter(controller, parameterName, AnimatorControllerParameterType.Float);

        SetAnimatorParameterDefault(controller, parameterName, defaultValue);
    }

    private static void EnsureControllerParameter(AnimatorController controller, string parameterName, AnimatorControllerParameterType parameterType)
    {
        if (controller == null || string.IsNullOrWhiteSpace(parameterName))
        {
            return;
        }

        if (controller.parameters.Any(parameter => parameter.name == parameterName))
        {
            return;
        }

        controller.AddParameter(parameterName, parameterType);
    }

    private static void CleanupComponentMenuItems(GameObject componentObject)
    {
        if (componentObject == null)
            return;

        var installer = componentObject.GetComponent<ModularAvatarMenuInstaller>();
        if (installer != null)
            UnityEngine.Object.DestroyImmediate(installer);

        var rootMenuItem = componentObject.GetComponent<ModularAvatarMenuItem>();
        if (rootMenuItem != null)
            UnityEngine.Object.DestroyImmediate(rootMenuItem);

        foreach (Transform child in componentObject.transform)
        {
            if (child.TryGetComponent<ModularAvatarMenuItem>(out _))
                UnityEngine.Object.DestroyImmediate(child.gameObject);
        }
    }

    private void CleanupManagedMenuItems(
        GameObject componentObject,
        IEnumerable<ImplementedFloatControl> allImplementedControls,
        IEnumerable<ImplementedFloatControl> activeImplementedControls)
    {
        var possiblePaths = BuildManagedMenuPathSet(allImplementedControls);
        var desiredPaths = BuildManagedMenuPathSet(activeImplementedControls);

        foreach (var path in possiblePaths
                     .Where(path => !desiredPaths.Contains(path))
                     .OrderByDescending(GetMenuPathDepth))
        {
            var existing = componentObject.transform.Find(path.Replace("//", "/"));
            if (existing != null && existing.TryGetComponent<ModularAvatarMenuItem>(out _))
            {
                UnityEngine.Object.DestroyImmediate(existing.gameObject);
            }
        }
    }

    private static string GetMenuPath(ImplementedFloatControl implementedControl)
    {
        return !string.IsNullOrEmpty(implementedControl.OverrideMenuPath)
            ? implementedControl.OverrideMenuPath
            : $"{implementedControl.MenuCategory}//{implementedControl.MenuLabel}";
    }

    private string GetDisplayMenuPath(ImplementedFloatControl implementedControl)
    {
        var isEnglish = ResolveExMenuLanguage() == PoiLightChangerInspectorLanguageMode.English;
        var overrideDisplayPath = isEnglish
            ? implementedControl.OverrideDisplayMenuPathEnglish
            : implementedControl.OverrideDisplayMenuPathJapanese;
        if (!string.IsNullOrEmpty(overrideDisplayPath))
        {
            return overrideDisplayPath;
        }

        var category = isEnglish
            ? implementedControl.MenuCategoryEnglish
            : implementedControl.MenuCategoryJapanese;
        var label = isEnglish
            ? implementedControl.MenuLabelEnglish
            : implementedControl.MenuLabelJapanese;
        if (!string.IsNullOrEmpty(category) && !string.IsNullOrEmpty(label))
        {
            return $"{category}//{label}";
        }

        var menuPath = GetMenuPath(implementedControl);
        if (string.IsNullOrEmpty(menuPath))
        {
            return string.Empty;
        }

        return menuPath;
    }

    private PoiLightChangerInspectorLanguageMode ResolveExMenuLanguage()
    {
        component?.EnsureInitialized();

        var menuSettings = component?.Menu;
        if (menuSettings == null)
        {
            return PoiLightChangerInspectorLanguageMode.Japanese;
        }

        var resolvedLanguage = menuSettings.InspectorLanguage;
        var language = menuSettings.ExMenuLanguage;
        if (language != PoiLightChangerExMenuLanguageMode.MatchInspector)
        {
            resolvedLanguage = language == PoiLightChangerExMenuLanguageMode.English
                ? PoiLightChangerInspectorLanguageMode.English
                : PoiLightChangerInspectorLanguageMode.Japanese;
        }

        return resolvedLanguage;
    }

    private static HashSet<string> BuildManagedMenuPathSet(IEnumerable<ImplementedFloatControl> controls)
    {
        var paths = new HashSet<string>();

        foreach (var control in controls)
        {
            var fullPath = GetMenuPath(control);
            if (string.IsNullOrEmpty(fullPath))
            {
                continue;
            }

            var segments = fullPath.Split(new[] { "//" }, StringSplitOptions.None);
            for (var index = 0; index < segments.Length; index++)
            {
                paths.Add(string.Join("//", segments.Take(index + 1)));
            }
        }

        return paths;
    }

    private static int GetMenuPathDepth(string path)
    {
        return string.IsNullOrEmpty(path)
            ? 0
            : path.Split(new[] { "//" }, StringSplitOptions.None).Length;
    }

    private static ModularAvatarMenuItem GetOrCreateMenuPath(
        GameObject rootObject,
        string menuPath,
        string displayMenuPath,
        VRCExpressionsMenu.Control.ControlType leafControlType)
    {
        var segments = menuPath.Split(new[] { "//" }, StringSplitOptions.None);
        var displaySegments = displayMenuPath.Split(new[] { "//" }, StringSplitOptions.None);
        var currentObject = rootObject;

        for (var index = 0; index < segments.Length; index++)
        {
            var segment = segments[index];
            var displaySegment = index < displaySegments.Length ? displaySegments[index] : segment;
            var isLeaf = index == segments.Length - 1;
            var controlType = isLeaf ? leafControlType : VRCExpressionsMenu.Control.ControlType.SubMenu;
            var menuItem = GetOrCreateMenuItem(currentObject, segment, displaySegment, controlType);

            if (!isLeaf)
            {
                menuItem.MenuSource = SubmenuSource.Children;
            }

            currentObject = menuItem.gameObject;
        }

        return currentObject.GetComponent<ModularAvatarMenuItem>();
    }

    private static ModularAvatarMenuItem GetOrCreateMenuItem(
        GameObject parent,
        string objectName,
        string displayName,
        VRCExpressionsMenu.Control.ControlType controlType)
    {
        var child = parent.transform.Find(objectName);
        GameObject gameObject;
        if (child == null)
        {
            gameObject = new GameObject(objectName);
            gameObject.transform.SetParent(parent.transform, false);
        }
        else
        {
            gameObject = child.gameObject;
        }

        var menuItem = gameObject.GetComponent<ModularAvatarMenuItem>();
        if (menuItem == null)
        {
            menuItem = gameObject.AddComponent<ModularAvatarMenuItem>();
        }

        menuItem.Control ??= new VRCExpressionsMenu.Control();
        if (controlType == VRCExpressionsMenu.Control.ControlType.SubMenu)
        {
            menuItem.MenuSource = SubmenuSource.Children;
        }
        menuItem.Control.type = controlType;
        menuItem.Control.name = displayName;
        menuItem.Control.icon = LoadMenuIcon(DefaultChildMenuIconGuid);
        menuItem.label = displayName;
        return menuItem;
    }

    private static Texture2D LoadDefaultRootMenuIcon()
    {
        return LoadMenuIcon(DefaultRootMenuIconGuid);
    }

    private static Texture2D LoadMenuIcon(string guid)
    {
        var path = AssetDatabase.GUIDToAssetPath(guid);
        if (string.IsNullOrWhiteSpace(path))
        {
            return null;
        }

        return AssetDatabase.LoadAssetAtPath<Texture2D>(path);
    }

    private static bool IsMaterialLocked(Material material)
    {
        if (material == null)
        {
            return false;
        }

        try
        {
            var type = ResolveShaderOptimizerType();
            var method = type?.GetMethod("IsMaterialLocked", BindingFlags.Public | BindingFlags.Static);
            if (method != null)
            {
                var result = method.Invoke(null, new object[] { material });
                if (result is bool isLocked)
                {
                    return isLocked;
                }
            }
        }
        catch
        {
        }

        if (material.HasProperty("thry_is_locked"))
        {
            return material.GetFloat("thry_is_locked") == 1.0f;
        }

        var shaderName = material.shader != null ? material.shader.name : string.Empty;
        if (shaderName.EndsWith("-Locked", StringComparison.OrdinalIgnoreCase))
        {
            return true;
        }

        if (shaderName.StartsWith("Hidden/Locked/", StringComparison.Ordinal))
        {
            return true;
        }

        return false;
    }

    public void BeginMaterialEditSession()
    {
        if (materialEditSessionActive)
        {
            return;
        }

        if (originallyLockedMaterials.Count > 0 && !UnlockPoiyomiMaterials(originallyLockedMaterials))
        {
            throw new InvalidOperationException("[Poi Light Changer] Failed to unlock locked Poiyomi materials before PLC processing.");
        }

        materialEditSessionActive = true;
    }

    public void EndMaterialEditSession()
    {
        if (!materialEditSessionActive)
        {
            return;
        }

        try
        {
            if (originallyLockedMaterials.Count > 0 && !LockPoiyomiMaterials(originallyLockedMaterials))
            {
                throw new InvalidOperationException("[Poi Light Changer] Failed to relock Poiyomi materials after PLC processing.");
            }
        }
        finally
        {
            materialEditSessionActive = false;
        }
    }

    private static Type ResolveShaderOptimizerType()
    {
        var candidateTypeNames = new[]
        {
            "Thry.ThryEditor.ShaderOptimizer",
            "Thry.ShaderOptimizer",
        };

        foreach (var assembly in AppDomain.CurrentDomain.GetAssemblies())
        {
            foreach (var candidateTypeName in candidateTypeNames)
            {
                var type = assembly.GetType(candidateTypeName);
                if (type != null)
                {
                    return type;
                }
            }
        }

        return null;
    }

    private static object[] BuildUnlockArguments(MethodInfo method, IEnumerable<Material> materials)
    {
        var parameters = method.GetParameters();
        if (parameters.Length <= 1)
        {
            return new object[] { materials };
        }

        var progressType = parameters[1].ParameterType;
        var progressValue = progressType.IsEnum
            ? Enum.ToObject(progressType, 0)
            : 0;

        return new object[] { materials, progressValue };
    }

    private bool ValidateUnlockedMaterials(IEnumerable<Material> materials)
    {
        foreach (var material in materials)
        {
            if (material == null)
            {
                continue;
            }

            if (IsMaterialLocked(material))
            {
                ReportDiagnosticOnce(
                    $"MaterialStillLockedAfterUnlock:{material.name}",
                    PoiLightChangerDiagnostics.CreateProcessorDiagnostic(
                        PoiLightChangerDiagnosticId.MaterialStillLockedAfterUnlock,
                        string.Empty,
                        string.Empty,
                        $"[Poi Light Changer] Material '{material.name}' is still locked after the unlock attempt. PLC processing was aborted.",
                        ErrorSeverity.NonFatal,
                        true,
                        material));
                Debug.LogWarning(
                    $"[Poi Light Changer] Material '{material.name}' is still locked after unlock attempt: '{material.shader?.name}'.",
                    material);
                return false;
            }
        }

        return true;
    }

    private bool UnlockPoiyomiMaterials(IEnumerable<Material> materials)
    {
        try
        {
            var type = ResolveShaderOptimizerType();

            if (type == null)
            {
                ReportDiagnosticOnce(
                    "MaterialUnlockFailed.ResolveType",
                    PoiLightChangerDiagnostics.CreateProcessorDiagnostic(
                        PoiLightChangerDiagnosticId.MaterialUnlockFailed,
                        string.Empty,
                        string.Empty,
                        "[Poi Light Changer] Failed to resolve Thry ShaderOptimizer type for material unlock. PLC processing was aborted.",
                        ErrorSeverity.NonFatal,
                        true,
                        context.AvatarRootObject));
                Debug.LogError("[Poi Light Changer] Failed to resolve Thry ShaderOptimizer type for unlock.");
                return false;
            }

            var method = type.GetMethod("UnlockMaterials", BindingFlags.Public | BindingFlags.Static);
            if (method == null)
            {
                ReportDiagnosticOnce(
                    "MaterialUnlockFailed.MissingMethod",
                    PoiLightChangerDiagnostics.CreateProcessorDiagnostic(
                        PoiLightChangerDiagnosticId.MaterialUnlockFailed,
                        string.Empty,
                        string.Empty,
                        $"[Poi Light Changer] '{type.FullName}' does not expose UnlockMaterials. PLC processing was aborted.",
                        ErrorSeverity.NonFatal,
                        true,
                        context.AvatarRootObject));
                Debug.LogError($"[Poi Light Changer] '{type.FullName}' does not expose UnlockMaterials.");
                return false;
            }

            var result = method.Invoke(null, BuildUnlockArguments(method, materials));
            var success = result is not bool boolResult || boolResult;
            return success && ValidateUnlockedMaterials(materials);
        }
        catch (Exception ex)
        {
            ReportDiagnosticOnce(
                "MaterialUnlockFailed.Exception",
                PoiLightChangerDiagnostics.CreateProcessorDiagnostic(
                    PoiLightChangerDiagnosticId.MaterialUnlockFailed,
                    string.Empty,
                    string.Empty,
                    "[Poi Light Changer] Failed to unlock materials using Thry.ShaderOptimizer. See Console for details. PLC processing was aborted.",
                    ErrorSeverity.NonFatal,
                    true,
                    context.AvatarRootObject));
            Debug.LogError($"[Poi Light Changer] Failed to unlock materials using Thry.ShaderOptimizer. {ex}");
            return false;
        }
    }

    private bool LockPoiyomiMaterials(IEnumerable<Material> materials)
    {
        try
        {
            var type = ResolveShaderOptimizerType();

            if (type == null)
            {
                ReportDiagnosticOnce(
                    "MaterialRelockFailed.ResolveType",
                    PoiLightChangerDiagnostics.CreateProcessorDiagnostic(
                        PoiLightChangerDiagnosticId.MaterialRelockFailed,
                        string.Empty,
                        string.Empty,
                        "[Poi Light Changer] Failed to resolve Thry ShaderOptimizer type for material relock. PLC processing was aborted.",
                        ErrorSeverity.NonFatal,
                        true,
                        context.AvatarRootObject));
                Debug.LogError("[Poi Light Changer] Failed to resolve Thry ShaderOptimizer type for relock.");
                return false;
            }

            var method = type.GetMethod("SetLockedForAllMaterials", BindingFlags.Public | BindingFlags.Static);
            if (method == null)
            {
                ReportDiagnosticOnce(
                    "MaterialRelockFailed.MissingMethod",
                    PoiLightChangerDiagnostics.CreateProcessorDiagnostic(
                        PoiLightChangerDiagnosticId.MaterialRelockFailed,
                        string.Empty,
                        string.Empty,
                        $"[Poi Light Changer] '{type.FullName}' does not expose SetLockedForAllMaterials. PLC processing was aborted.",
                        ErrorSeverity.NonFatal,
                        true,
                        context.AvatarRootObject));
                Debug.LogError($"[Poi Light Changer] '{type.FullName}' does not expose SetLockedForAllMaterials.");
                return false;
            }

            var result = method.Invoke(null, new object[] { materials, 1, false, false, false, null });
            return result is not bool success || success;
        }
        catch (Exception ex)
        {
            ReportDiagnosticOnce(
                "MaterialRelockFailed.Exception",
                PoiLightChangerDiagnostics.CreateProcessorDiagnostic(
                    PoiLightChangerDiagnosticId.MaterialRelockFailed,
                    string.Empty,
                    string.Empty,
                    "[Poi Light Changer] Failed to relock materials using Thry.ShaderOptimizer. See Console for details. PLC processing was aborted.",
                    ErrorSeverity.NonFatal,
                    true,
                    context.AvatarRootObject));
            Debug.LogError($"[Poi Light Changer] Failed to lock materials using Thry.ShaderOptimizer. {ex}");
            return false;
        }
    }
}

}
