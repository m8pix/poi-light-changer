# Poi Light Changer
VRChatで使用する Poiyomi Shader アバター向けに、ゲーム内メニューから各種マテリアル制御を行うツールです。

## 目次
- [特徴](#特徴)
- [インストール](#インストール)
- [規約](#規約)
- [各種リンク](#各種リンク)
- [免責事項](#免責事項)

## 特徴
Modular Avatar と NDMF を前提として、非破壊でアバター内のマテリアル制御ギミックを生成します。  

- Poiyomi Shader 9.3+ に対応
- VRChat PC アバター向け
- Lighting / Light Direction / Color / SSAO / Contact Shadow / Proximity / Outline / Backlight などの制御に対応
- build 時に menu / animator / parameter を生成

一部機能は Poiyomi の variant や version に依存します。  

- `SSAO` は Poiyomi Pro 前提
- `Contact Shadow` は Poiyomi Pro v10+ 前提

## インストール
Poi Light Changer は VPM package として導入する想定です。  
配布時に案内される VPM repository を VCC / ALCOM に追加し、Unity project へ導入してください。  

導入後は package 内の `Poi Light Changer.prefab` をアバター配下へ配置するか、`NDMF/Poi Light Changer` から component を追加して使用します。  

## 規約
この package は proprietary license です。  
ライセンスや配布条件は、配布時に案内される内容に従ってください。  

また、ライセンスが有効ではない場合、build 時に利用できる機能は `Lighting` と `Light Direction` のみになります。  

## 各種リンク
### Docs
準備中

### Booth
準備中

## 免責事項
この説明文および配布内容は、事前の予告なく変更される可能性があります。
