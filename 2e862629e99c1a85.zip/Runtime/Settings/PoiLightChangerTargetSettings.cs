using System.Collections.Generic;
using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    [System.Serializable]
    public sealed class PoiLightChangerExcludedObjectEntry
    {
        public GameObject Object;
        public bool IncludeChildren = false;
    }

    [System.Serializable]
    public sealed class PoiLightChangerTargetSettings : IPoiLightChangerSettingsNode
    {
        public bool AutoCollectPoiyomiMaterials = true;
        public bool IncludeInactiveRenderers = true;
        public List<PoiLightChangerExcludedObjectEntry> ExcludedObjects = new();

        public bool EnsureInitialized()
        {
            if (ExcludedObjects != null)
            {
                return false;
            }

            ExcludedObjects = new List<PoiLightChangerExcludedObjectEntry>();
            return true;
        }

        public bool IsGameObjectExcluded(GameObject targetObject)
        {
            if (targetObject == null || ExcludedObjects == null || ExcludedObjects.Count == 0)
            {
                return false;
            }

            var targetTransform = targetObject.transform;
            for (var index = 0; index < ExcludedObjects.Count; index++)
            {
                var entry = ExcludedObjects[index];
                var excludedObject = entry?.Object;
                if (excludedObject == null)
                {
                    continue;
                }

                var excludedTransform = excludedObject.transform;
                if (targetTransform == excludedTransform)
                {
                    return true;
                }

                if (entry.IncludeChildren && targetTransform.IsChildOf(excludedTransform))
                {
                    return true;
                }
            }

            return false;
        }
    }
}
