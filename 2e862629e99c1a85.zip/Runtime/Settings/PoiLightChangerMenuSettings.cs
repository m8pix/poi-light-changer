namespace io.github.m8pix.poi_light_changer
{
    [System.Serializable]
    public sealed class PoiLightChangerMenuSettings : IPoiLightChangerSettingsNode
    {
        public PoiLightChangerInspectorLanguageMode InspectorLanguage = PoiLightChangerInspectorLanguageMode.Japanese;
        public PoiLightChangerExMenuLanguageMode ExMenuLanguage = PoiLightChangerExMenuLanguageMode.MatchInspector;

        public bool Normalize()
        {
            var changed = false;

            if (InspectorLanguage != PoiLightChangerInspectorLanguageMode.English &&
                InspectorLanguage != PoiLightChangerInspectorLanguageMode.Japanese)
            {
                InspectorLanguage = PoiLightChangerInspectorLanguageMode.Japanese;
                changed = true;
            }

            if (ExMenuLanguage != PoiLightChangerExMenuLanguageMode.MatchInspector &&
                ExMenuLanguage != PoiLightChangerExMenuLanguageMode.English &&
                ExMenuLanguage != PoiLightChangerExMenuLanguageMode.Japanese)
            {
                ExMenuLanguage = PoiLightChangerExMenuLanguageMode.MatchInspector;
                changed = true;
            }

            return changed;
        }
    }

    public enum PoiLightChangerInspectorLanguageMode
    {
        English = 1,
        Japanese = 2,
    }

    public enum PoiLightChangerExMenuLanguageMode
    {
        MatchInspector = 0,
        English = 1,
        Japanese = 2,
    }
}
