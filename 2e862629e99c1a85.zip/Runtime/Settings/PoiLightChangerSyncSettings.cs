namespace io.github.m8pix.poi_light_changer
{
    [System.Serializable]
    public sealed class PoiLightChangerSyncSettings : IPoiLightChangerSettingsNode
    {
        public bool UseParameterCompression = true;
        public int CompressionChannelCount = 1;
        public bool AddManualSyncButton = false;
    }
}
