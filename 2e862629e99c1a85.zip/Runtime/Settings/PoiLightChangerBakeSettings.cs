namespace io.github.m8pix.poi_light_changer
{
    [System.Serializable]
    public sealed class PoiLightChangerBakeSettings : IPoiLightChangerSettingsNode
    {
        public bool EnableColorBake = true;

        public bool AllowForceOverrideSameReference = true;
    }
}
