using System.Collections.Generic;

namespace io.github.m8pix.poi_light_changer
{
    [System.Serializable]
    public sealed class PoiLightChangerBoolOverrideValue
    {
        public bool Enable = false;
        public bool Value = true;
    }

    [System.Serializable]
    public sealed class PoiLightChangerIntOverrideValue
    {
        public bool Enable = false;
        public int Value = 0;
    }

    [System.Serializable]
    public sealed class PoiLightChangerWorldAoBlockOverrideValue
    {
        public bool Enable = false;
        public bool Enabled = true;
        public int UVChannel = 0;
        public bool FlipNormal = false;
    }

    [System.Serializable]
    public sealed class PoiLightChangerOverrideSettings : IPoiLightChangerSettingsNode
    {
        public PoiLightChangerWorldAoBlockOverrideValue WorldAOBlock = new();
        public PoiLightChangerBoolOverrideValue NearClipForce = new();
        public PoiLightChangerBoolOverrideValue Ltcgi = new();
        public PoiLightChangerIntOverrideValue LightColorMode = new();
        public PoiLightChangerIntOverrideValue LightMapMode = new();
        public PoiLightChangerIntOverrideValue LightDirectionMode = new();

        public bool HasAnyEnabled()
        {
            return WorldAOBlock.Enable
                || NearClipForce.Enable
                || Ltcgi.Enable
                || LightColorMode.Enable
                || LightMapMode.Enable
                || LightDirectionMode.Enable;
        }

        public IEnumerable<string> EnumerateEnabledLabels()
        {
            if (WorldAOBlock.Enable)
            {
                yield return "WorldAOBlock";
            }

            if (NearClipForce.Enable)
            {
                yield return "ニヤクリップ強制";
            }

            if (Ltcgi.Enable)
            {
                yield return "LTCGI";
            }

            if (LightColorMode.Enable)
            {
                yield return "Light Color Mode";
            }

            if (LightMapMode.Enable)
            {
                yield return "Light Map Mode";
            }

            if (LightDirectionMode.Enable)
            {
                yield return "Light Direction Mode";
            }
        }

        IEnumerable<IPoiLightChangerSettingsNode> IPoiLightChangerSettingsNode.Children
        {
            get
            {
                yield break;
            }
        }
    }
}
