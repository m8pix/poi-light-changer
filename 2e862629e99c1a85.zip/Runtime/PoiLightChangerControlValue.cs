using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    public interface IPoiLightChangerSettingsNode
    {
        System.Collections.Generic.IEnumerable<IPoiLightChangerSettingsNode> Children => System.Array.Empty<IPoiLightChangerSettingsNode>();
    }

    public interface IPoiLightChangerControlValue
    {
        bool Enable { get; }

        bool Animation { get; }

        bool Saved { get; }

        bool Synced { get; }

        AnimatorControllerParameterType ParameterType { get; }
    }

    [System.Serializable]
    public abstract class PoiLightChangerControlValue : IPoiLightChangerControlValue
    {
        public bool Enable = true;
        public bool Animation = true;
        public bool Saved = true;
        public bool Synced = true;

        bool IPoiLightChangerControlValue.Enable => Enable;

        bool IPoiLightChangerControlValue.Animation => Animation;

        bool IPoiLightChangerControlValue.Saved => Saved;

        bool IPoiLightChangerControlValue.Synced => Synced;

        public abstract AnimatorControllerParameterType ParameterType { get; }
    }

    [System.Serializable]
    public sealed class PoiLightChangerFloatControlValue : PoiLightChangerControlValue
    {
        public PoiLightChangerFloatControlValue()
        {
        }

        public PoiLightChangerFloatControlValue(float value, float minValue, float maxValue)
        {
            Value = value;
            Range = new Vector2(minValue, maxValue);
        }

        public float Value;
        public Vector2 Range = new(0.0f, 1.0f);

        public override AnimatorControllerParameterType ParameterType => AnimatorControllerParameterType.Float;
    }

    [System.Serializable]
    public sealed class PoiLightChangerBoolControlValue : PoiLightChangerControlValue
    {
        public PoiLightChangerBoolControlValue()
        {
        }

        public PoiLightChangerBoolControlValue(bool value)
        {
            Value = value;
        }

        public bool Value;

        public override AnimatorControllerParameterType ParameterType => AnimatorControllerParameterType.Bool;
    }

    [System.Serializable]
    public sealed class PoiLightChangerColorControlValue : PoiLightChangerControlValue
    {
        public PoiLightChangerColorControlValue()
        {
        }

        public PoiLightChangerColorControlValue(Color value)
        {
            Value = value;
        }

        public Color Value = Color.white;
        public Vector2 Range = new(0.0f, 2.0f);

        public override AnimatorControllerParameterType ParameterType => AnimatorControllerParameterType.Float;
    }
}
