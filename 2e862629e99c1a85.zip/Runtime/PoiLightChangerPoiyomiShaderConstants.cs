namespace io.github.m8pix.poi_light_changer
{
    public static class PoiLightChangerPoiyomiShaderConstants
    {
        public const string PackageName = "com.poiyomi.toon";

        public const string LightingMinLightBrightness = "_LightingMinLightBrightness";
        public const string LightingCapEnabled = "_LightingCapEnabled";
        public const string LightingCap = "_LightingCap";
        public const string LightingAdditiveLimited = "_LightingAdditiveLimited";
        public const string LightingAdditiveLimit = "_LightingAdditiveLimit";
        public const string PpLightingMultiplier = "_PPLightingMultiplier";
        public const string PpLightingAddition = "_PPLightingAddition";
        public const string PpEmissionMultiplier = "_PPEmissionMultiplier";
        public const string PpFinalColorMultiplier = "_PPFinalColorMultiplier";
        public const string LightingMonochromatic = "_LightingMonochromatic";
        public const string LightingAdditiveMonochromatic = "_LightingAdditiveMonochromatic";
        public const string LightngForcedDirection = "_LightngForcedDirection";
        public const string LightngForcedDirectionX = "_LightngForcedDirection.x";
        public const string LightngForcedDirectionY = "_LightngForcedDirection.y";
        public const string LightngForcedDirectionZ = "_LightngForcedDirection.z";
        public const string LightingColorMode = "_LightingColorMode";
        public const string LightingMapMode = "_LightingMapMode";
        public const string LightingDirectionMode = "_LightingDirectionMode";
        public const string LightingViewDirOffsetYaw = "_LightingViewDirOffsetYaw";
        public const string LightingViewDirOffsetPitch = "_LightingViewDirOffsetPitch";
        public const string LtcgiEnabled = "_LTCGIEnabled";
        public const string RenderingReduceClipDistance = "_RenderingReduceClipDistance";
        public const string RenderingAoBlockerEnabled = "_RenderingAOBlockerEnabled";
        public const string RenderingAoBlockerUvChannel = "_RenderingAOBlockerUVChannel";
        public const string RenderingAoBlockerFlipNormal = "_RenderingAOBlockerFlipNormal";
        public const string PostProcess = "_PostProcess";
        public const string MainHueShift = "_MainHueShift";
        public const string Saturation = "_Saturation";
        public const string MainBrightness = "_MainBrightness";
        public const string PpHueShiftColorSpace = "_PPHueShiftColorSpace";
        public const string PpHueSelectOrShift = "_ppHueSelectOrShift";
        public const string PpHue = "_PPHue";
        public const string PpContrast = "_PPContrast";
        public const string PpSaturation = "_PPSaturation";
        public const string PpBrightness = "_PPBrightness";
        public const string PpLightness = "_PPLightness";
        public const string PpHdr = "_PPHDR";

        public const string SsaoEnabled = "_SSAOEnabled";
        public const string SsaoAnimationToggle = "_SSAOAnimationToggle";
        public const string SsaoIntensity = "_SSAOIntensity";
        public const string SsaoRadius = "_SSAORadius";
        public const string SsaoQuality = "_SSAOQuality";
        public const string SsaoCenterImportance = "_SSAOCenterImportance";
        public const string SsaoBias = "_SSAOBias";
        public const string SsaoCone = "_SSAOCone";
        public const string SsaoRandomScale = "_SSAORandomScale";
        public const string SsaoUseNormals = "_SSAOUseNormals";

        public const string ContactShadowsEnabled = "_ContactShadowsEnabled";
        public const string ContactShadowsAnimationToggle = "_ContactShadowsAnimationToggle";
        public const string ContactShadowsIntensity = "_ContactShadowsIntensity";
        public const string ContactShadowsMaxDistance = "_ContactShadowsMaxDistance";
        public const string ContactShadowsQuality = "_ContactShadowsQuality";
        public const string ContactShadowsThickness = "_ContactShadowsThickness";
        public const string ContactShadowsBias = "_ContactShadowsBias";
        public const string ContactShadowsNormalBias = "_ContactShadowsNormalBias";
        public const string ContactShadowsHideInLight = "_ContactShadowsHideInLight";
        public const string ContactShadowsNoiseScale = "_ContactShadowsNoiseScale";
        public const string ContactShadowsRejectionDepth = "_ContactShadowsRejectionDepth";

        public const string FxProximityColor = "_FXProximityColor";
        public const string FxProximityColorMinColor = "_FXProximityColorMinColor";
        public const string FxProximityColorMinColorR = "_FXProximityColorMinColor.r";
        public const string FxProximityColorMinColorG = "_FXProximityColorMinColor.g";
        public const string FxProximityColorMinColorB = "_FXProximityColorMinColor.b";
        public const string FxProximityColorMaxColor = "_FXProximityColorMaxColor";
        public const string FxProximityColorMaxColorR = "_FXProximityColorMaxColor.r";
        public const string FxProximityColorMaxColorG = "_FXProximityColorMaxColor.g";
        public const string FxProximityColorMaxColorB = "_FXProximityColorMaxColor.b";
        public const string FxProximityColorMinDistance = "_FXProximityColorMinDistance";
        public const string FxProximityColorMaxDistance = "_FXProximityColorMaxDistance";
        public const string FxProximityColorBackface = "_FXProximityColorBackFace";

        public const string EnableOutlines = "_EnableOutlines";
        public const string OutlineTexture = "_OutlineTexture";
        public const string LineColor = "_LineColor";
        public const string LineColorR = "_LineColor.r";
        public const string LineColorG = "_LineColor.g";
        public const string LineColorB = "_LineColor.b";
        public const string LineWidth = "_LineWidth";
        public const string OutlineFixedSize = "_OutlineFixedSize";
        public const string OutlineFixWidth = "_OutlineFixWidth";
        public const string OutlineEmission = "_OutlineEmission";
        public const string OffsetZ = "_Offset_Z";

        public const string BacklightEnabled = "_BacklightEnabled";
        public const string BacklightColor = "_BacklightColor";
        public const string BacklightColorR = "_BacklightColor.r";
        public const string BacklightColorG = "_BacklightColor.g";
        public const string BacklightColorB = "_BacklightColor.b";
        public const string BacklightMainStrength = "_BacklightMainStrength";
        public const string BacklightBorder = "_BacklightBorder";
        public const string BacklightBlur = "_BacklightBlur";
        public const string BacklightDirectivity = "_BacklightDirectivity";
        public const string BacklightViewStrength = "_BacklightViewStrength";
        public const string BacklightReceiveShadow = "_BacklightReceiveShadow";
        public const string BacklightBackfaceMask = "_BacklightBackfaceMask";
    }
}
