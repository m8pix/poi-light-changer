Shader "Hidden/PoiLightChanger/ColorBaker"
{
    Properties
    {
        [sRGBWarning(true)]
        _MainTex    ("Main Texture",  2D)    = "white" {}
        _MainTex_ST ("Main Texture ST", Vector) = (1, 1, 0, 0)

        _MainColorAdjustTexture ("ColorAdjust Mask", 2D) = "white" {}
        _MainGradationTex ("Gradation Map", 2D) = "white" {}

        _Saturation          ("Saturation",          Range(-1, 10)) = 0
        _MainBrightness      ("Brightness",          Range(-1, 2))  = 0
        _MainGamma           ("Gamma",               Range(0.01, 5)) = 1
        _ColorGradingToggle  ("Color Grading Toggle", Float) = 0
        _MainGradationStrength ("Gradation Strength", Range(0, 1)) = 0

        _MainHueShiftToggle      ("Hue Shift Toggle",     Float) = 0
        _MainHueShift            ("Hue Shift",            Range(0, 1)) = 0
        _MainHueShiftColorSpace  ("Color Space (0=OKLab 1=HSV)", Float) = 0
        _MainHueShiftSelectOrShift ("Select or Shift",   Float) = 1
        _MainHueShiftReplace     ("Hue Replace",         Float) = 1
    }

    SubShader
    {
        Tags
        {
            "RenderType" = "Opaque"
            "Queue"      = "Geometry"
        }
        Cull Off
        ZWrite On
        ZTest LEqual
        Blend Off

        Pass
        {
            Name "PLC_BAKE_COLOR"
            Tags { "LightMode" = "Always" }

            CGPROGRAM
            #pragma vertex   vert
            #pragma fragment frag
            #pragma target   3.0

            #include "UnityCG.cginc"

            sampler2D _MainTex;
            float4 _MainTex_ST;

            sampler2D _MainColorAdjustTexture;
            float4 _MainColorAdjustTexture_ST;
            sampler2D _MainGradationTex;

            float _Saturation;
            float _MainBrightness;
            float _MainGamma;
            float _ColorGradingToggle;
            float _MainGradationStrength;
            float _MainHueShiftToggle;
            float _MainHueShift;
            float _MainHueShiftColorSpace;
            float _MainHueShiftSelectOrShift;
            float _MainHueShiftReplace;

            struct appdata
            {
                float4 vertex : POSITION;
                float2 uv     : TEXCOORD0;
            };

            struct v2f
            {
                float4 pos : SV_POSITION;
                float2 uv  : TEXCOORD0;
            };

            v2f vert(appdata v)
            {
                v2f o;
                o.pos = UnityObjectToClipPos(v.vertex);
                o.uv  = v.uv;
                return o;
            }

            float3 LinearToOKLab(float3 c)
            {
                float l = 0.4122214708 * c.x + 0.5363325363 * c.y + 0.0514459929 * c.z;
                float m = 0.2119034982 * c.x + 0.6806995451 * c.y + 0.1073969566 * c.z;
                float s = 0.0883024619 * c.x + 0.2817188376 * c.y + 0.6299787005 * c.z;
                float l_ = pow(l, 1.0 / 3.0);
                float m_ = pow(m, 1.0 / 3.0);
                float s_ = pow(s, 1.0 / 3.0);
                return float3(
                    0.2104542553 * l_ + 0.7936177850 * m_ - 0.0040720468 * s_,
                    1.9779984951 * l_ - 2.4285922050 * m_ + 0.4505937099 * s_,
                    0.0259040371 * l_ + 0.7827717662 * m_ - 0.8086757660 * s_);
            }

            float3 OKLabToLinear(float3 c)
            {
                float l_ = c.x + 0.3963377774 * c.y + 0.2158037573 * c.z;
                float m_ = c.x - 0.1055613458 * c.y - 0.0638541728 * c.z;
                float s_ = c.x - 0.0894841775 * c.y - 1.2914855480 * c.z;
                float l = l_ * l_ * l_;
                float m = m_ * m_ * m_;
                float s = s_ * s_ * s_;
                return float3(
                    +4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
                    -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
                    -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s);
            }

            float3 HueShiftOKLab(float3 color, float shift, float selectOrShift)
            {
                float3 oklab  = LinearToOKLab(color);
                float  chroma = length(oklab.yz);
                oklab.y = selectOrShift > 0.5 ? oklab.y : chroma;
                oklab.z = selectOrShift > 0.5 ? oklab.z : 0.0;
                float s, c;
                sincos(shift * UNITY_TWO_PI, s, c);
                oklab.yz = float2(c * oklab.y - s * oklab.z, s * oklab.y + c * oklab.z);
                return OKLabToLinear(oklab);
            }

            float3 RGBtoHSV(float3 c)
            {
                float4 K = float4(0.0, -1.0 / 3.0, 2.0 / 3.0, -1.0);
                float4 p = lerp(float4(c.bg, K.wz), float4(c.gb, K.xy), step(c.b, c.g));
                float4 q = lerp(float4(p.xyw, c.r), float4(c.r, p.yzx), step(p.x, c.r));
                float d = q.x - min(q.w, q.y);
                float e = 1.0e-10;
                return float3(abs(q.z + (q.w - q.y) / (6.0 * d + e)), d / (q.x + e), q.x);
            }

            float3 HSVtoRGB(float3 c)
            {
                float4 K = float4(1.0, 2.0 / 3.0, 1.0 / 3.0, 3.0);
                float3 p = abs(frac(c.xxx + K.xyz) * 6.0 - K.www);
                return c.z * lerp(K.xxx, saturate(p - K.xxx), c.y);
            }

            float3 HueShiftHSV(float3 color, float hueOffset, float selectOrShift)
            {
                float3 hsv = RGBtoHSV(color);
                hsv.x = hsv.x * selectOrShift + hueOffset;
                return HSVtoRGB(hsv);
            }

            float3 LinearToSRGB(float3 color)
            {
                return LinearToGammaSpace(color);
            }

            float3 SRGBToLinear(float3 color)
            {
                return GammaToLinearSpace(color);
            }

            float2 PoiUv(float2 uv, float4 tex_st)
            {
                return uv * tex_st.xy + tex_st.zw;
            }

            float3 DoHueShift(float3 color, float shift, float colorSpace, float selectOrShift)
            {
                if (colorSpace < 0.5)
                    return HueShiftOKLab(color, shift, selectOrShift);
                return HueShiftHSV(color, shift, selectOrShift);
            }

            fixed4 frag(v2f i) : SV_Target
            {
                float4 tex  = tex2D(_MainTex, PoiUv(i.uv, _MainTex_ST));
                float3 col  = tex.rgb;

                float4 mask = tex2D(_MainColorAdjustTexture, PoiUv(i.uv, _MainColorAdjustTexture_ST));

                if (_MainHueShiftToggle > 0.5)
                {
                    float shift = _MainHueShift;
                    if (_MainHueShiftReplace > 0.5)
                    {
                        col = lerp(col,
                            DoHueShift(col, shift, _MainHueShiftColorSpace, _MainHueShiftSelectOrShift),
                            mask.r);
                    }
                    else
                    {
                        col = DoHueShift(col,
                            frac(shift - (1.0 - mask.r)),
                            _MainHueShiftColorSpace,
                            _MainHueShiftSelectOrShift);
                    }
                }

                if (_MainGradationStrength > 0.0 && _ColorGradingToggle > 0.5)
                {
                    #if !defined(UNITY_COLORSPACE_GAMMA)
                    float3 tempColor = LinearToSRGB(col);
                    #else
                    float3 tempColor = col;
                    #endif

                    tempColor.r = tex2D(_MainGradationTex, float2(tempColor.r, 0.5)).r;
                    tempColor.g = tex2D(_MainGradationTex, float2(tempColor.g, 0.5)).g;
                    tempColor.b = tex2D(_MainGradationTex, float2(tempColor.b, 0.5)).b;

                    #if !defined(UNITY_COLORSPACE_GAMMA)
                    tempColor = SRGBToLinear(tempColor);
                    #endif

                    col = lerp(col, tempColor, _MainGradationStrength);
                }

                col = lerp(col, pow(abs(col), _MainGamma), mask.a);

                float lum = dot(col, float3(0.3, 0.59, 0.11));
                col = lerp(col, float3(lum, lum, lum), -_Saturation * mask.b);

                col = saturate(lerp(col, col * (_MainBrightness + 1.0), mask.g));

                return float4(col, tex.a);
            }
            ENDCG
        }
    }
}
