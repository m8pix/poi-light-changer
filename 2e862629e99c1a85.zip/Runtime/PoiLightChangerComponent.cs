using System.Collections.Generic;
using UnityEngine;
using VRC.SDKBase;

namespace io.github.m8pix.poi_light_changer
{
    [DisallowMultipleComponent]
    [AddComponentMenu("NDMF/Poi Light Changer")]
    public sealed class PoiLightChangerComponent : MonoBehaviour, IEditorOnly, IPoiLightChangerSettingsNode
    {
        [SerializeField]
        [HideInInspector]
        private int serializedDataVersion = 1;

        public PoiLightChangerGeneralSettings General = new();
        public PoiLightChangerMenuSettings Menu = new();
        public PoiLightChangerSyncSettings Sync = new();
        public PoiLightChangerTargetSettings Target = new();
        public PoiLightChangerBakeSettings Bake = new();
        public PoiLightChangerOverrideSettings Overrides = new();
        public PoiLightChangerPoiyomiSettings Poiyomi = new();

        public int SerializedDataVersion => serializedDataVersion;

        private void Reset()
        {
            EnsureInitialized();
        }

        private void OnValidate()
        {
            EnsureInitialized();
        }

        public bool EnsureInitialized()
        {
            var changed = false;

            if (General == null)
            {
                General = new PoiLightChangerGeneralSettings();
                changed = true;
            }

            if (Menu == null)
            {
                Menu = new PoiLightChangerMenuSettings();
                changed = true;
            }

            if (Sync == null)
            {
                Sync = new PoiLightChangerSyncSettings();
                changed = true;
            }

            if (Target == null)
            {
                Target = new PoiLightChangerTargetSettings();
                changed = true;
            }
            else
            {
                changed |= Target.EnsureInitialized();
            }

            if (Bake == null)
            {
                Bake = new PoiLightChangerBakeSettings();
                changed = true;
            }

            if (Overrides == null)
            {
                Overrides = new PoiLightChangerOverrideSettings();
                changed = true;
            }

            if (Poiyomi == null)
            {
                Poiyomi = new PoiLightChangerPoiyomiSettings();
                changed = true;
            }

            changed |= Menu.Normalize();
            changed |= Poiyomi.Normalize();

            return changed;
        }

        IEnumerable<IPoiLightChangerSettingsNode> IPoiLightChangerSettingsNode.Children
        {
            get
            {
                yield return General;
                yield return Menu;
                yield return Sync;
                yield return Target;
                yield return Bake;
                yield return Overrides;
                yield return Poiyomi;
            }
        }
    }
}
