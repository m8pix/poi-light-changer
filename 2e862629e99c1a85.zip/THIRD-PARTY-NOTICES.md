# Third-Party Notices

## ThryEditor

この package は ThryEditor 本体を同梱しておらず、依存関係としても配布していません。

ただし、Editor UI の見た目や操作感の一部については、ThryEditor を参照しながら調整している箇所があります。

Referenced project:
- ThryEditor
- Copyright (c) 2022 Thryrallo
- License: MIT
- Source: https://github.com/Thryrallo/ThryEditor
