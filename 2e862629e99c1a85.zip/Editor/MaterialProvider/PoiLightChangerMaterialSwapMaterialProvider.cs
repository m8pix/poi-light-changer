using nadena.dev.modular_avatar.core;
using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    internal sealed class PoiLightChangerMaterialSwapMaterialProvider : IPoiLightChangerMaterialProvider
    {
        public void Collect(PoiLightChangerBuildProcessor processor)
        {
            var components = processor.Context.AvatarRootObject.GetComponentsInChildren<ModularAvatarMaterialSwap>(true);
            foreach (var component in components)
            {
                if (component.Swaps == null)
                {
                    continue;
                }

                var swapRoot = component.Root?.Get(component);
                for (var swapIndex = 0; swapIndex < component.Swaps.Count; swapIndex++)
                {
                    var swap = component.Swaps[swapIndex];
                    Material clonedMaterial = null;
                    foreach (var renderer in processor.EnumerateAvatarRenderers())
                    {
                        if (processor.ShouldSkipRenderer(renderer))
                        {
                            continue;
                        }

                        if (swapRoot != null && !renderer.transform.IsChildOf(swapRoot.transform))
                        {
                            continue;
                        }

                        if (!processor.RendererUsesMaterial(renderer, swap.From))
                        {
                            continue;
                        }

                        if (clonedMaterial == null)
                        {
                            clonedMaterial = processor.CloneMaterialForAssociatedRenderer(
                                swap.To,
                                renderer,
                                nameof(PoiLightChangerMaterialSwapMaterialProvider));
                            if (!ReferenceEquals(clonedMaterial, swap.To))
                            {
                                swap.To = clonedMaterial;
                                component.Swaps[swapIndex] = swap;
                            }
                        }
                        else
                        {
                            processor.RegisterAssociatedMaterial(
                                renderer,
                                clonedMaterial,
                                nameof(PoiLightChangerMaterialSwapMaterialProvider));
                        }
                    }
                }
            }
        }
    }
}
