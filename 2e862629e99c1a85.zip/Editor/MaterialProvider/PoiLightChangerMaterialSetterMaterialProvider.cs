using nadena.dev.modular_avatar.core;
using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    internal sealed class PoiLightChangerMaterialSetterMaterialProvider : IPoiLightChangerMaterialProvider
    {
        public void Collect(PoiLightChangerBuildProcessor processor)
        {
            var components = processor.Context.AvatarRootObject.GetComponentsInChildren<ModularAvatarMaterialSetter>(true);
            foreach (var component in components)
            {
                if (component.Objects == null)
                {
                    continue;
                }

                foreach (var targetObject in component.Objects)
                {
                    var rendererObject = targetObject.Object?.Get(component);
                    var renderer = rendererObject != null ? rendererObject.GetComponent<Renderer>() : null;
                    if (renderer == null || processor.ShouldSkipRenderer(renderer))
                    {
                        continue;
                    }

                    if (targetObject.MaterialIndex < 0 || targetObject.MaterialIndex >= renderer.sharedMaterials.Length)
                    {
                        continue;
                    }

                    targetObject.Material = processor.CloneMaterialForAssociatedRenderer(
                        targetObject.Material,
                        renderer,
                        nameof(PoiLightChangerMaterialSetterMaterialProvider));
                }
            }
        }
    }
}
