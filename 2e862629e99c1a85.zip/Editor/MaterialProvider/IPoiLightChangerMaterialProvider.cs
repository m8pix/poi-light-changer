using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    internal interface IPoiLightChangerMaterialProvider
    {
        void Collect(PoiLightChangerBuildProcessor processor);
    }
}
