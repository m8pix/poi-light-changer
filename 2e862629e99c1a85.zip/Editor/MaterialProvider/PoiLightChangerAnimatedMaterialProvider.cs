using nadena.dev.ndmf.animator;
using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    internal sealed class PoiLightChangerAnimatedMaterialProvider : IPoiLightChangerMaterialProvider
    {
        public void Collect(PoiLightChangerBuildProcessor processor)
        {
            var animatorServices = processor.Context.Extension<AnimatorServicesContext>();
            var animationIndex = animatorServices.AnimationIndex;
            var pathRemapper = animatorServices.ObjectPathRemapper;
            animationIndex.RewriteObjectCurves((binding, obj) =>
            {
                if (!typeof(Renderer).IsAssignableFrom(binding.type))
                {
                    return obj;
                }

                var rendererObject = pathRemapper.GetObjectForPath(binding.path)
                    ?? processor.Context.AvatarRootTransform.Find(binding.path)?.gameObject;
                var renderer = rendererObject != null ? rendererObject.GetComponent<Renderer>() : null;
                if (renderer == null || processor.ShouldSkipRenderer(renderer))
                {
                    return obj;
                }

                return obj is Material material
                    ? processor.CloneMaterialForAssociatedRenderer(material, renderer, nameof(PoiLightChangerAnimatedMaterialProvider))
                    : obj;
            });
        }
    }
}
