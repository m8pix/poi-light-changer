namespace io.github.m8pix.poi_light_changer
{
    internal sealed class PoiLightChangerRendererSharedMaterialProvider : IPoiLightChangerMaterialProvider
    {
        public void Collect(PoiLightChangerBuildProcessor processor)
        {
            foreach (var renderer in processor.EnumerateAvatarRenderers())
            {
                if (processor.ShouldSkipRenderer(renderer))
                {
                    continue;
                }

                var sharedMaterials = renderer.sharedMaterials;
                var changed = false;
                for (var index = 0; index < sharedMaterials.Length; index++)
                {
                    var clonedMaterial = processor.CloneMaterialForSharedRenderer(sharedMaterials[index], renderer);
                    if (ReferenceEquals(clonedMaterial, sharedMaterials[index]))
                    {
                        continue;
                    }

                    sharedMaterials[index] = clonedMaterial;
                    changed = true;
                }

                if (changed)
                {
                    renderer.sharedMaterials = sharedMaterials;
                }
            }
        }
    }
}
