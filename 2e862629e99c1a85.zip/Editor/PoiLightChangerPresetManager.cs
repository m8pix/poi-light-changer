using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    internal static class PoiLightChangerPresetManager
    {
        public static IReadOnlyList<string> Keys
        {
            get
            {
                PoiLightChangerGlobalPresetStore.Instance.RefreshFromDisk();
                return PoiLightChangerGlobalPresetStore.Instance.Keys;
            }
        }

        public static bool TrySave(string presetName, PoiLightChangerComponent component)
        {
            if (component == null || string.IsNullOrWhiteSpace(presetName))
            {
                return false;
            }

            component.EnsureInitialized();
            var componentJson = CreatePresetComponentJson(component);
            var envelope = new PoiLightChangerPresetEnvelope
            {
                Version = PoiLightChangerPresetEnvelope.CurrentVersion,
                SavedAtUtc = DateTime.UtcNow.ToString("O"),
                Data = componentJson,
            };

            PoiLightChangerGlobalPresetStore.Instance.SavePreset(presetName.Trim(), JsonUtility.ToJson(envelope));
            return true;
        }

        public static bool TryLoad(string presetName, PoiLightChangerComponent component)
        {
            if (component == null || string.IsNullOrWhiteSpace(presetName))
            {
                return false;
            }

            PoiLightChangerGlobalPresetStore.Instance.RefreshFromDisk();
            if (!PoiLightChangerGlobalPresetStore.Instance.TryGetPresetJson(presetName.Trim(), out var presetJson))
            {
                return false;
            }

            if (!PoiLightChangerPresetEnvelope.TryParseAndMigrate(presetJson, out var envelope))
            {
                return false;
            }

            Undo.RecordObject(component, $"Load PLC Preset {presetName}");
            var preservedTarget = CloneTargetSettings(component.Target);
            ResetComponentForPresetLoad(component);
            JsonUtility.FromJsonOverwrite(envelope.Data, component);
            component.Target = preservedTarget;
            component.EnsureInitialized();
            EditorUtility.SetDirty(component);
            return true;
        }

        public static bool Remove(string presetName)
        {
            if (string.IsNullOrWhiteSpace(presetName))
            {
                return false;
            }

            PoiLightChangerGlobalPresetStore.Instance.RefreshFromDisk();
            return PoiLightChangerGlobalPresetStore.Instance.RemovePreset(presetName.Trim());
        }

        private static void ResetComponentForPresetLoad(PoiLightChangerComponent component)
        {
            component.General = new PoiLightChangerGeneralSettings();
            component.Menu = new PoiLightChangerMenuSettings();
            component.Sync = new PoiLightChangerSyncSettings();
            component.Target = new PoiLightChangerTargetSettings();
            component.Bake = new PoiLightChangerBakeSettings();
            component.Overrides = new PoiLightChangerOverrideSettings();
            component.Poiyomi = new PoiLightChangerPoiyomiSettings();
        }

        private static string CreatePresetComponentJson(PoiLightChangerComponent component)
        {
            var temporaryObject = new GameObject("__PoiLightChanger.PresetTemp")
            {
                hideFlags = HideFlags.HideAndDontSave,
            };

            try
            {
                var temporaryComponent = temporaryObject.AddComponent<PoiLightChangerComponent>();
                JsonUtility.FromJsonOverwrite(JsonUtility.ToJson(component), temporaryComponent);
                temporaryComponent.Target = new PoiLightChangerTargetSettings();
                temporaryComponent.EnsureInitialized();
                return JsonUtility.ToJson(temporaryComponent);
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(temporaryObject);
            }
        }

        private static PoiLightChangerTargetSettings CloneTargetSettings(PoiLightChangerTargetSettings source)
        {
            var clone = new PoiLightChangerTargetSettings();
            if (source == null)
            {
                return clone;
            }

            clone.AutoCollectPoiyomiMaterials = source.AutoCollectPoiyomiMaterials;
            clone.IncludeInactiveRenderers = source.IncludeInactiveRenderers;
            clone.ExcludedObjects = source.ExcludedObjects == null
                ? new List<PoiLightChangerExcludedObjectEntry>()
                : source.ExcludedObjects
                    .Where(entry => entry != null)
                    .Select(entry => new PoiLightChangerExcludedObjectEntry
                    {
                        Object = entry.Object,
                        IncludeChildren = entry.IncludeChildren,
                    })
                    .ToList();
            return clone;
        }
    }

    [Serializable]
    internal sealed class PoiLightChangerPresetEnvelope
    {
        public const int CurrentVersion = 1;

        public int Version = CurrentVersion;
        public string SavedAtUtc;
        public string Data;

        public static bool TryParseAndMigrate(string json, out PoiLightChangerPresetEnvelope envelope)
        {
            envelope = null;
            if (string.IsNullOrWhiteSpace(json))
            {
                return false;
            }

            var parsed = JsonUtility.FromJson<PoiLightChangerPresetEnvelope>(json);
            if (parsed == null || string.IsNullOrWhiteSpace(parsed.Data))
            {
                return false;
            }

            if (parsed.Version <= 0)
            {
                parsed.Version = CurrentVersion;
            }

            if (parsed.Version > CurrentVersion)
            {
                return false;
            }

            envelope = parsed;
            return true;
        }
    }

    internal sealed class PoiLightChangerGlobalPresetStore : ScriptableObject, ISerializationCallbackReceiver
    {
        private const string LegacySerializedFilePath = "PoiLightChanger/GlobalPresets";
        private const string JsonFilePath = "PoiLightChanger/GlobalPresets.json";
        private static PoiLightChangerGlobalPresetStore instance;

        [SerializeField]
        private PresetEntry[] presets;

        private Dictionary<string, string> presetMap = new(StringComparer.Ordinal);

        [Serializable]
        private sealed class PresetFileEnvelope
        {
            public PresetEntry[] Presets;
        }

        public static PoiLightChangerGlobalPresetStore Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = CreateInstance<PoiLightChangerGlobalPresetStore>();
                    instance.Refresh();
                }

                return instance;
            }
        }

        public IReadOnlyList<string> Keys => presetMap.Keys.OrderBy(key => key, StringComparer.Ordinal).ToArray();

        public void SavePreset(string presetName, string presetJson)
        {
            presetMap[presetName] = presetJson;
            Save();
        }

        public bool TryGetPresetJson(string presetName, out string presetJson)
        {
            return presetMap.TryGetValue(presetName, out presetJson);
        }

        public bool RemovePreset(string presetName)
        {
            if (!presetMap.Remove(presetName))
            {
                return false;
            }

            Save();
            return true;
        }

        public void OnBeforeSerialize()
        {
            presets = presetMap
                .OrderBy(pair => pair.Key, StringComparer.Ordinal)
                .Select(pair => new PresetEntry
                {
                    Name = pair.Key,
                    Json = pair.Value,
                })
                .ToArray();
        }

        public void OnAfterDeserialize()
        {
            presetMap = presets == null
                ? new Dictionary<string, string>(StringComparer.Ordinal)
                : presets.ToDictionary(entry => entry.Name, entry => entry.Json, StringComparer.Ordinal);
        }

        internal void RefreshFromDisk()
        {
            Refresh();
        }

        private void Refresh()
        {
            if (TryLoadFromJsonFile(out var jsonEntries))
            {
                ApplyEntries(jsonEntries);
                return;
            }

            if (TryLoadFromLegacySerializedFile(out var legacyEntries) ||
                TryLoadFromLegacyYaml(out legacyEntries))
            {
                ApplyEntries(legacyEntries);
                SaveJsonFile();
                return;
            }

            presetMap = new Dictionary<string, string>(StringComparer.Ordinal);
        }

        private void Save()
        {
            SaveJsonFile();
        }

        private void SaveJsonFile()
        {
            var absolutePath = GetJsonAbsoluteFilePath();
            var directory = Path.GetDirectoryName(absolutePath);
            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            var envelope = new PresetFileEnvelope
            {
                Presets = CreateOrderedEntries(),
            };
            File.WriteAllText(absolutePath, JsonUtility.ToJson(envelope, true));
        }

        private static string GetLegacySerializedAbsoluteFilePath()
        {
            return Path.Combine(InternalEditorUtility.unityPreferencesFolder, LegacySerializedFilePath);
        }

        private static string GetJsonAbsoluteFilePath()
        {
            return Path.Combine(InternalEditorUtility.unityPreferencesFolder, JsonFilePath);
        }

        private void ApplyEntries(IEnumerable<PresetEntry> entries)
        {
            presetMap = entries == null
                ? new Dictionary<string, string>(StringComparer.Ordinal)
                : entries.ToDictionary(entry => entry.Name, entry => entry.Json, StringComparer.Ordinal);
        }

        private PresetEntry[] CreateOrderedEntries()
        {
            return presetMap
                .OrderBy(pair => pair.Key, StringComparer.Ordinal)
                .Select(pair => new PresetEntry
                {
                    Name = pair.Key,
                    Json = pair.Value,
                })
                .ToArray();
        }

        private static bool TryLoadFromJsonFile(out PresetEntry[] entries)
        {
            entries = Array.Empty<PresetEntry>();
            var absolutePath = GetJsonAbsoluteFilePath();
            if (!File.Exists(absolutePath))
            {
                return false;
            }

            var json = File.ReadAllText(absolutePath);
            if (string.IsNullOrWhiteSpace(json))
            {
                return false;
            }

            var envelope = JsonUtility.FromJson<PresetFileEnvelope>(json);
            if (envelope == null)
            {
                return false;
            }

            entries = envelope.Presets ?? Array.Empty<PresetEntry>();
            return true;
        }

        private static bool TryLoadFromLegacySerializedFile(out PresetEntry[] entries)
        {
            entries = Array.Empty<PresetEntry>();
            var loaded = InternalEditorUtility.LoadSerializedFileAndForget(GetLegacySerializedAbsoluteFilePath())
                ?.FirstOrDefault() as PoiLightChangerGlobalPresetStore;
            if (loaded == null)
            {
                return false;
            }

            entries = loaded.presets ?? Array.Empty<PresetEntry>();
            DestroyImmediate(loaded);
            return true;
        }

        private static bool TryLoadFromLegacyYaml(out PresetEntry[] entries)
        {
            entries = Array.Empty<PresetEntry>();
            var absolutePath = GetLegacySerializedAbsoluteFilePath();
            if (!File.Exists(absolutePath))
            {
                return false;
            }

            var yaml = File.ReadAllText(absolutePath);
            if (string.IsNullOrWhiteSpace(yaml))
            {
                return false;
            }

            var matches = Regex.Matches(
                yaml,
                @"^\s*-\s+Name:\s*(?<name>.+?)\r?\n\s+Json:\s*'(?<json>.*)'$",
                RegexOptions.Multiline);
            if (matches.Count == 0)
            {
                return false;
            }

            entries = matches
                .Cast<Match>()
                .Select(match => new PresetEntry
                {
                    Name = match.Groups["name"].Value.Trim(),
                    Json = match.Groups["json"].Value.Replace("''", "'"),
                })
                .ToArray();
            return true;
        }

        [Serializable]
        private struct PresetEntry
        {
            public string Name;
            public string Json;
        }
    }
}
