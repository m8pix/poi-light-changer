using System;
using System.Collections.Generic;
using nadena.dev.ndmf;
using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    internal sealed class PoiLightChangerParameterSlot
    {
        public string Name { get; set; }

        public AnimatorControllerParameterType ParameterType { get; set; }

        public bool Synced { get; set; }

        public bool Saved { get; set; }

        public bool IsHidden { get; set; }

        public float DefaultValue { get; set; }

        public PoiLightChangerParameterSlot Clone()
        {
            return (PoiLightChangerParameterSlot)MemberwiseClone();
        }
    }

    internal static class PoiLightChangerParameterLayout
    {
        public static IReadOnlyList<PoiLightChangerParameterSlot> GetDirectParameterLayout(
            PoiLightChangerComponent instance,
            PoiLightChangerLicenseSnapshot licenseSnapshot = null)
        {
            if (instance == null)
            {
                return Array.Empty<PoiLightChangerParameterSlot>();
            }

            instance.EnsureInitialized();
            licenseSnapshot ??= PoiLightChangerLicenseService.GetCurrentSnapshot();

            if (!PoiLightChangerLicenseFeatureGate.IsFeatureAvailable(PoiLightChangerLicensedFeatureId.Parameters, licenseSnapshot))
            {
                return Array.Empty<PoiLightChangerParameterSlot>();
            }

            var slots = new List<PoiLightChangerParameterSlot>();
            var emittedNames = new HashSet<string>(StringComparer.Ordinal);
            foreach (var binding in PoiLightChangerControlBindingResolver.GetImplementedBindings(instance, licenseSnapshot))
            {
                if (binding.Definition == null ||
                    !binding.Definition.ImplementedInCurrentBuild ||
                    !binding.SectionEnabled ||
                    binding.IsSecondaryComponent)
                {
                    continue;
                }

                var control = binding.Control;
                if (control is not { Enable: true, Animation: true })
                {
                    continue;
                }

                var slotName = binding.OverrideParameterName
                    ?? PoiLightChangerControlRegistry.ComposeAnimatorParameterName(instance, binding.Definition);
                if (!emittedNames.Add(slotName))
                {
                    continue;
                }

                var slot = CreateSlot(
                    slotName,
                    binding.Definition.ParameterType,
                    control.Synced,
                    control.Saved,
                    PoiLightChangerControlBindingUtility.ResolveDefaultValue(control));

                if (PoiLightChangerPseudoToggleUtility.ShouldUseLocalOnlyPseudoToggle(instance, binding.Definition.Id))
                {
                    slot.Synced = false;
                }

                slots.Add(slot);
            }

            AppendPseudoToggleStoredSlots(instance, slots);

            return slots;
        }

        private static PoiLightChangerParameterSlot CreateSlot(
            string name,
            AnimatorControllerParameterType parameterType,
            bool synced,
            bool saved,
            float defaultValue)
        {
            return new PoiLightChangerParameterSlot
            {
                Name = name,
                ParameterType = parameterType,
                Synced = synced,
                Saved = saved,
                DefaultValue = defaultValue,
            };
        }

        private static void AppendPseudoToggleStoredSlots(PoiLightChangerComponent instance, ICollection<PoiLightChangerParameterSlot> slots)
        {
            if (slots == null)
            {
                return;
            }

            if (PoiLightChangerPseudoToggleUtility.UsesMergedBacklightSync(instance))
            {
                slots.Add(CreateHiddenLocalOnlySlot(
                    PoiLightChangerPseudoToggleUtility.GetStoredValueParameterName(PoiLightChangerControlId.BacklightBorder),
                    PoiLightChangerControlBindingUtility.NormalizeFloatControlValue(instance.Poiyomi.BacklightBorder),
                    instance.Poiyomi.BacklightBorder.Saved));
            }

            if (PoiLightChangerPseudoToggleUtility.UsesMergedOutlineSync(instance))
            {
                slots.Add(CreateHiddenLocalOnlySlot(
                    PoiLightChangerPseudoToggleUtility.GetStoredValueParameterName(PoiLightChangerControlId.OutlineLineWidth),
                    PoiLightChangerControlBindingUtility.NormalizeFloatControlValue(instance.Poiyomi.OutlineLineWidth),
                    instance.Poiyomi.OutlineLineWidth.Saved));
            }
        }

        private static PoiLightChangerParameterSlot CreateHiddenLocalOnlySlot(string name, float defaultValue, bool saved)
        {
            return new PoiLightChangerParameterSlot
            {
                Name = name,
                ParameterType = AnimatorControllerParameterType.Float,
                Synced = false,
                Saved = saved,
                IsHidden = true,
                DefaultValue = defaultValue,
            };
        }

    }

    [ParameterProviderFor(typeof(PoiLightChangerComponent))]
    internal sealed class PoiLightChangerParameterProvider : IParameterProvider
    {
        public PoiLightChangerParameterProvider(PoiLightChangerComponent instance)
        {
            Instance = instance;
        }

        public PoiLightChangerComponent Instance { get; }

        public IEnumerable<ProvidedParameter> GetSuppliedParameters(BuildContext context = null)
        {
            if (Instance == null)
            {
                yield break;
            }

            var licenseSnapshot = PoiLightChangerLicenseService.GetCurrentSnapshot();
            var directLayout = GetDirectParameterLayout(Instance, licenseSnapshot);
            var compressionPlan = Instance.Sync.UseParameterCompression
                ? PoiLightChangerParameterCompression.BuildPlanFromSlots(directLayout, Instance.Sync.CompressionChannelCount)
                : null;

            foreach (var slot in PoiLightChangerParameterCompression.RewriteSlots(directLayout, compressionPlan))
            {
                yield return new ProvidedParameter(
                    slot.Name,
                    ParameterNamespace.Animator,
                    Instance,
                    PoiLightChangerPlugin.Instance,
                    slot.ParameterType)
                {
                    WantSynced = slot.Synced,
                    IsHidden = slot.IsHidden,
                    DefaultValue = slot.DefaultValue,
                };
            }
        }

        internal static IReadOnlyList<PoiLightChangerParameterSlot> GetDirectParameterLayout(
            PoiLightChangerComponent instance,
            PoiLightChangerLicenseSnapshot licenseSnapshot = null)
        {
            return PoiLightChangerParameterLayout.GetDirectParameterLayout(instance, licenseSnapshot);
        }
    }
}
