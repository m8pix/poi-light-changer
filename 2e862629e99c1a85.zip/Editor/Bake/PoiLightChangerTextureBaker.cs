using System;
using System.Collections.Generic;
using Unity.Collections;
using nadena.dev.ndmf;
using UnityEditor;
using UnityEditor.AssetImporters;
using UnityEngine;
using UnityEngine.Rendering;

namespace io.github.m8pix.poi_light_changer
{
    internal sealed class PoiLightChangerTextureBakeException : Exception
    {
        public PoiLightChangerTextureBakeException(string message)
            : base(message)
        {
        }

        public PoiLightChangerTextureBakeException(string message, Exception innerException)
            : base(message, innerException)
        {
        }
    }

    internal sealed class PoiLightChangerTextureBaker
    {
        private readonly Dictionary<int, Texture2D> _cache = new();
        private readonly HashSet<int> _finalizedTextureIds = new();

        private readonly BuildContext _context;
        private readonly ErrorReport _errorReport;

        public PoiLightChangerTextureBaker(BuildContext context)
        {
            _context     = context;
            _errorReport = context.ErrorReport;
        }

        public Texture2D BakeOrGetCached(Texture source, Material bakeMat)
        {
            if (source == null)
                return null;

            var prepared = PrepareBake(source, bakeMat);

            if (_cache.TryGetValue(prepared.CacheKey, out var cached) && cached != null)
                return cached;

            var result = Bake(source, bakeMat, prepared.Settings);
            result.name = BuildBakedTextureName(source);
            _cache[prepared.CacheKey] = result;
            return result;
        }

        public Texture2D BakeOrGetCached(Texture cacheKey, Texture blitSource, Material bakeMat)
        {
            if (cacheKey == null || blitSource == null)
                return null;

            var prepared = PrepareBake(cacheKey, blitSource, bakeMat);

            if (_cache.TryGetValue(prepared.CacheKey, out var cached) && cached != null)
                return cached;

            var result = Bake(blitSource, bakeMat, prepared.Settings);
            result.name = BuildBakedTextureName(cacheKey);
            _cache[prepared.CacheKey] = result;
            return result;
        }

        public void FinalizeBakedTexture(Texture source, Texture2D baked)
        {
            if (source == null || baked == null)
                return;

            if (!_finalizedTextureIds.Add(baked.GetInstanceID()))
                return;

            if (!IsBuiltinTexture(source))
                ObjectRegistry.RegisterReplacedObject(source, baked);

            _context.AssetSaver.SaveAsset(baked);
        }

        private PreparedBake PrepareBake(Texture settingsSource, Material bakeMat)
        {
            var resolvedSource = PoiLightChangerTextureUtils.ResolveSourceTexture(settingsSource, _errorReport) ?? settingsSource;
            var settings = PoiLightChangerTextureUtils.BuildGenerationSettings(resolvedSource, _errorReport);
            var settingsHash = PoiLightChangerTextureUtils.TryGetSourceAssetStateHash(resolvedSource, out var assetStateHash)
                ? assetStateHash
                : PoiLightChangerTextureUtils.ComputeGenerationSettingsHash(resolvedSource, settings);
            var cacheKey = HashCode.Combine(settingsHash, bakeMat.ComputeCRC());

            return new PreparedBake(cacheKey, settings);
        }

        private PreparedBake PrepareBake(Texture settingsSource, Texture blitSource, Material bakeMat)
        {
            var prepared = PrepareBake(settingsSource, bakeMat);
            var resolvedBlitSource = PoiLightChangerTextureUtils.ResolveSourceTexture(blitSource, _errorReport) ?? blitSource;
            var blitIdentity = PoiLightChangerTextureUtils.TryGetSourceAssetStateHash(resolvedBlitSource, out var blitAssetStateHash)
                ? blitAssetStateHash
                : resolvedBlitSource?.GetInstanceID() ?? 0;
            var cacheKey = HashCode.Combine(prepared.CacheKey, blitIdentity);

            return new PreparedBake(cacheKey, prepared.Settings);
        }

        private Texture2D Bake(Texture blitSource, Material bakeMat, TextureGenerationSettings settings)
        {
            var rt   = RenderTexture.GetTemporary(blitSource.width, blitSource.height, 0, RenderTextureFormat.ARGB32);
            var prev = RenderTexture.active;
            try
            {
                Graphics.Blit(blitSource, rt, bakeMat);

                var updateMipmaps = settings.textureImporterSettings.mipmapEnabled;

                var output = GenerateTextureFromRenderTarget(rt, settings);
                output.Apply(updateMipmaps: updateMipmaps, makeNoLongerReadable: true);
                return output;
            }
            finally
            {
                RenderTexture.active = prev;
                RenderTexture.ReleaseTemporary(rt);
            }
        }

        public static bool ReplaceAllTextureReferences(Material material, Texture from, Texture to)
        {
            using var so      = new SerializedObject(material);
            var       changed = false;
            var       prop    = so.GetIterator();

            while (prop.Next(true))
            {
                if (prop.propertyType == SerializedPropertyType.ObjectReference
                    && prop.objectReferenceValue == from)
                {
                    prop.objectReferenceValue = to;
                    changed = true;
                }
            }

            if (changed)
                so.ApplyModifiedPropertiesWithoutUndo();

            return changed;
        }

        private static bool IsBuiltinTexture(Texture tex)
        {
            return tex == Texture2D.whiteTexture
                || tex == Texture2D.blackTexture
                || tex == Texture2D.grayTexture
                || tex == Texture2D.linearGrayTexture
                || tex == Texture2D.redTexture
                || tex == Texture2D.normalTexture;
        }

        private static Texture2D GenerateTextureFromRenderTarget(RenderTexture rt, TextureGenerationSettings settings)
        {
            if (SystemInfo.supportsAsyncGPUReadback)
            {
                var request = AsyncGPUReadback.Request(rt, 0, TextureFormat.RGBA32);
                request.WaitForCompletion();
                if (!request.hasError)
                {
                    using var data = request.GetData<Color32>();
                    return GenerateTexture(settings, data);
                }
            }

            return GenerateTextureWithReadPixels(rt, settings);
        }

        private static Texture2D GenerateTextureWithReadPixels(RenderTexture rt, TextureGenerationSettings settings)
        {
            var readbackTexture = new Texture2D(rt.width, rt.height, TextureFormat.RGBA32, false);
            var previous = RenderTexture.active;
            try
            {
                RenderTexture.active = rt;
                readbackTexture.ReadPixels(new Rect(0, 0, rt.width, rt.height), 0, 0, false);
                readbackTexture.Apply(updateMipmaps: false, makeNoLongerReadable: false);

                using var pixelData = new NativeArray<Color32>(readbackTexture.GetPixels32(), Allocator.Temp);
                return GenerateTexture(settings, pixelData);
            }
            catch (Exception ex)
            {
                throw new PoiLightChangerTextureBakeException(
                    "Fallback ReadPixels bake failed while reading pixels from the render target.",
                    ex);
            }
            finally
            {
                RenderTexture.active = previous;
                UnityEngine.Object.DestroyImmediate(readbackTexture);
            }
        }

        private static Texture2D GenerateTexture(TextureGenerationSettings settings, NativeArray<Color32> pixelData)
        {
            try
            {
                var generated = TextureGenerator.GenerateTexture(settings, pixelData);
                if (generated.output is not Texture2D texture)
                {
                    throw new PoiLightChangerTextureBakeException(
                        "TextureGenerator did not return a Texture2D output.");
                }

                return texture;
            }
            catch (PoiLightChangerTextureBakeException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new PoiLightChangerTextureBakeException(
                    "Texture generation failed while creating the baked texture asset.",
                    ex);
            }
        }

        private static string BuildBakedTextureName(Texture source)
        {
            return $"{(source != null ? source.name : "texture")}_plc_color";
        }

        private readonly struct PreparedBake
        {
            public PreparedBake(int cacheKey, TextureGenerationSettings settings)
            {
                CacheKey = cacheKey;
                Settings = settings;
            }

            public int CacheKey { get; }

            public TextureGenerationSettings Settings { get; }
        }
    }
}
