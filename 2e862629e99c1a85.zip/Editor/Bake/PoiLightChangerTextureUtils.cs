using System;
using System.Reflection;
using nadena.dev.ndmf;
using UnityEditor;
using UnityEditor.AssetImporters;
using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    internal static class PoiLightChangerTextureUtils
    {
        private static MethodInfo _getSourceTextureInfoMethod;

        internal static Texture ResolveSourceTexture(Texture texture, ErrorReport errorReport)
        {
            if (texture == null)
                return null;

            var source = texture;
            if (ObjectRegistry.GetReference(texture).TryResolve(errorReport, out var resolved)
                && resolved is Texture resolvedTexture)
            {
                source = resolvedTexture;
            }

            return source;
        }

        public static TextureGenerationSettings BuildGenerationSettings(Texture texture, ErrorReport errorReport)
        {
            var source = ResolveSourceTexture(texture, errorReport);
            var path = AssetDatabase.GetAssetPath(source);

            var importer = string.IsNullOrEmpty(path)
                ? null
                : AssetImporter.GetAtPath(path) as TextureImporter;

            var settings = new TextureGenerationSettings(importer?.textureType ?? TextureImporterType.Default);

            if (importer != null)
            {
                importer.ReadTextureSettings(settings.textureImporterSettings);
                CopyPreferredPlatformTextureSettings(importer, settings);

                var info = InvokeGetSourceTextureInformation(importer);
                settings.sourceTextureInformation.width          = source.width;
                settings.sourceTextureInformation.height         = source.height;
                settings.sourceTextureInformation.hdr            = info?.hdr ?? false;
                settings.sourceTextureInformation.containsAlpha  = info?.containsAlpha ?? false;
            }
            else
            {
                settings.textureImporterSettings.aniso       = texture.anisoLevel;
                settings.textureImporterSettings.filterMode  = texture.filterMode;
                settings.textureImporterSettings.sRGBTexture = texture.isDataSRGB;

                settings.sourceTextureInformation.width  = source.width;
                settings.sourceTextureInformation.height = source.height;

                if (source is Texture2D tex2d)
                {
                    settings.sourceTextureInformation.hdr =
                        tex2d.format is TextureFormat.RGBAFloat or TextureFormat.RGBAHalf;
                    settings.sourceTextureInformation.containsAlpha = tex2d.alphaIsTransparency;
                }
            }

            settings.enablePostProcessor       = false;
            settings.textureImporterSettings.readable = true;

            return settings;
        }

        internal static int ComputeGenerationSettingsHash(
            Texture source,
            TextureGenerationSettings settings)
        {
            if (TryGetSourceAssetStateHash(source, out var assetStateHash))
                return assetStateHash;

            var hash = new HashCode();

            var path = AssetDatabase.GetAssetPath(source);
            if (!string.IsNullOrEmpty(path))
            {
                hash.Add(path, StringComparer.Ordinal);
            }
            else if (source != null)
            {
                hash.Add(source.GetInstanceID());
            }

            var importer = string.IsNullOrEmpty(path)
                ? null
                : AssetImporter.GetAtPath(path) as TextureImporter;
            hash.Add((int)(importer?.textureType ?? TextureImporterType.Default));

            hash.Add(settings.textureImporterSettings.mipmapEnabled);
            hash.Add(settings.textureImporterSettings.streamingMipmaps);
            hash.Add((int)settings.textureImporterSettings.filterMode);
            hash.Add(settings.textureImporterSettings.aniso);
            hash.Add(settings.textureImporterSettings.sRGBTexture);
            hash.Add(settings.textureImporterSettings.alphaIsTransparency);
            hash.Add((int)settings.textureImporterSettings.wrapMode);
            hash.Add((int)settings.textureImporterSettings.wrapModeU);
            hash.Add((int)settings.textureImporterSettings.wrapModeV);
            hash.Add((int)settings.textureImporterSettings.wrapModeW);
            hash.Add((int)settings.textureImporterSettings.npotScale);

            var preferredPlatformSettings = importer != null
                ? GetPreferredPlatformTextureSettings(importer)
                : null;
            hash.Add(preferredPlatformSettings?.maxTextureSize ?? settings.platformSettings.maxTextureSize);
            hash.Add((int)(preferredPlatformSettings?.format ?? TextureImporterFormat.Automatic));
            hash.Add((int)(preferredPlatformSettings?.textureCompression ?? settings.platformSettings.textureCompression));
            hash.Add(preferredPlatformSettings?.compressionQuality ?? settings.platformSettings.compressionQuality);
            hash.Add(preferredPlatformSettings?.crunchedCompression ?? settings.platformSettings.crunchedCompression);

            hash.Add(settings.sourceTextureInformation.width);
            hash.Add(settings.sourceTextureInformation.height);
            hash.Add(settings.sourceTextureInformation.hdr);
            hash.Add(settings.sourceTextureInformation.containsAlpha);

            return hash.ToHashCode();
        }

        internal static bool TryGetSourceAssetStateHash(Texture source, out int hash)
        {
            hash = default;

            if (source == null)
                return false;

            var path = AssetDatabase.GetAssetPath(source);
            if (string.IsNullOrEmpty(path))
                return false;

            var dependencyHash = AssetDatabase.GetAssetDependencyHash(path);
            hash = HashCode.Combine(
                StringComparer.Ordinal.GetHashCode(path),
                dependencyHash.GetHashCode());
            return true;
        }

        private static void CopyPreferredPlatformTextureSettings(
            TextureImporter importer,
            TextureGenerationSettings settings)
        {
            GetPreferredPlatformTextureSettings(importer).CopyTo(settings.platformSettings);
        }

        private static TextureImporterPlatformSettings GetPreferredPlatformTextureSettings(TextureImporter importer)
        {
            // PLC is currently VRChat PC only, so prefer the Windows/Mac/Linux override.
            var standalone = importer.GetPlatformTextureSettings("Standalone");
            return standalone != null && standalone.overridden
                ? standalone
                : importer.GetDefaultPlatformTextureSettings();
        }

        private static SourceTextureInformation InvokeGetSourceTextureInformation(TextureImporter importer)
        {
            try
            {
                _getSourceTextureInfoMethod ??= typeof(TextureImporter).GetMethod(
                    "GetSourceTextureInformation",
                    BindingFlags.NonPublic | BindingFlags.Instance);

                return _getSourceTextureInfoMethod?.Invoke(importer, null) as SourceTextureInformation;
            }
            catch (Exception)
            {
                return null;
            }
        }
    }
}
