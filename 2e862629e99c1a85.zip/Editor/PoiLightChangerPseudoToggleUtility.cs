namespace io.github.m8pix.poi_light_changer
{
    internal static class PoiLightChangerPseudoToggleUtility
    {
        private const string SystemPrefix = PoiLightChangerGeneralSettings.DefaultParameterPrefix + "/System/PseudoToggle";

        public static bool UsesMergedBacklightSync(PoiLightChangerComponent component)
        {
            return false;
        }

        public static bool UsesMergedOutlineSync(PoiLightChangerComponent component)
        {
            return false;
        }

        public static bool ShouldUseLocalOnlyPseudoToggle(PoiLightChangerComponent component, PoiLightChangerControlId definitionId)
        {
            return definitionId switch
            {
                PoiLightChangerControlId.BacklightToggle => UsesMergedBacklightSync(component),
                PoiLightChangerControlId.OutlineToggle => UsesMergedOutlineSync(component),
                _ => false,
            };
        }

        public static string GetStoredValueParameterName(PoiLightChangerControlId definitionId)
        {
            return definitionId switch
            {
                PoiLightChangerControlId.BacklightBorder => $"{SystemPrefix}/BacklightBorderStored",
                PoiLightChangerControlId.OutlineLineWidth => $"{SystemPrefix}/OutlineLineWidthStored",
                _ => null,
            };
        }
    }
}
