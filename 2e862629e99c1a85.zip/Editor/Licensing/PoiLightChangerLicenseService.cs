using System;

namespace io.github.m8pix.poi_light_changer
{
    internal static class PoiLightChangerLicenseService
    {
        private static readonly object SyncRoot = new();
        private static PoiLightChangerLicenseSnapshot cachedSnapshot;
        private static bool snapshotInitialized;

        public static PoiLightChangerLicenseSnapshot GetCurrentSnapshot()
        {
            lock (SyncRoot)
            {
                cachedSnapshot ??= EvaluateStoredState();
                snapshotInitialized = true;
                return cachedSnapshot;
            }
        }

        public static PoiLightChangerLicenseSnapshot ValidateAndActivate(string licenseCode, bool allowNetwork)
        {
            lock (SyncRoot)
            {
                if (!PoiLightChangerSignatureVerifier.TryVerifyLicenseCode(
                        licenseCode,
                        out var licensePayload,
                        out var licensePayloadBase64Url,
                        out var errorMessageJapanese,
                        out var errorMessageEnglish))
                {
                    cachedSnapshot = CreateSnapshot(
                        PoiLightChangerLicenseValidationState.SignatureInvalid,
                        false,
                        false,
                        null,
                        null,
                        null,
                        null,
                        errorMessageJapanese,
                        errorMessageEnglish);
                    snapshotInitialized = true;
                    return cachedSnapshot;
                }

                var currentCache = PoiLightChangerLicenseStore.Load();
                var previousValidatedAtUtc = TryGetStoredUtc(currentCache.lastValidatedAtUtc);
                PoiLightChangerPolicyPayload policyPayload = null;
                string policyEnvelopeJson = currentCache.policyEnvelopeJson ?? string.Empty;
                string policyPayloadBase64Url = currentCache.policyPayloadBase64Url ?? string.Empty;
                DateTimeOffset? fetchedAtUtc = TryGetStoredUtc(currentCache.lastFetchedAtUtc);
                DateTimeOffset? validatedAtUtc = null;
                DateTimeOffset? offlineGraceUntilUtc = null;
                var state = PoiLightChangerLicenseValidationState.PolicyInvalid;
                var isLicensed = false;
                var usesCachedPolicy = false;

                if (allowNetwork)
                {
                    var fetchResult = new PoiLightChangerPolicyClient().Fetch(PoiLightChangerLicenseDefaults.PolicyFetchTimeoutSeconds);
                    if (fetchResult.Success)
                    {
                        if (!ShouldReplacePolicy(currentCache.policyVersion, fetchResult.Payload.policyVersion))
                        {
                            return UseCachedPolicy(currentCache, licenseCode, licensePayload, licensePayloadBase64Url);
                        }

                        policyPayload = fetchResult.Payload;
                        policyEnvelopeJson = fetchResult.EnvelopeJson;
                        policyPayloadBase64Url = fetchResult.PayloadBase64Url;
                        fetchedAtUtc = fetchResult.FetchedAtUtc;
                        if (IsLicenseTimeWindowValid(licensePayload, out errorMessageJapanese, out errorMessageEnglish) &&
                            TryValidateAgainstPolicy(licensePayload, policyPayload, out errorMessageJapanese, out errorMessageEnglish))
                        {
                            validatedAtUtc = DateTimeOffset.UtcNow;
                            offlineGraceUntilUtc = validatedAtUtc.Value.AddDays(policyPayload.offlineGraceDays);
                            state = PoiLightChangerLicenseValidationState.Licensed;
                            isLicensed = true;
                        }
                    }
                    else
                    {
                        return UseCachedPolicy(currentCache, licenseCode, licensePayload, licensePayloadBase64Url, fetchResult.ErrorMessageJapanese, fetchResult.ErrorMessageEnglish);
                    }
                }
                else
                {
                    return UseCachedPolicy(currentCache, licenseCode, licensePayload, licensePayloadBase64Url);
                }

                if (!isLicensed)
                {
                    PoiLightChangerLicenseStore.Save(new PoiLightChangerCachedLicenseState
                    {
                        storedLicenseCode = licenseCode.Trim(),
                        licensePayloadBase64Url = licensePayloadBase64Url,
                        policyEnvelopeJson = policyEnvelopeJson,
                        policyPayloadBase64Url = policyPayloadBase64Url,
                        lastFetchedAtUtc = fetchedAtUtc?.ToString("O"),
                        lastValidatedAtUtc = previousValidatedAtUtc?.ToString("O"),
                        offlineGraceUntilUtc = null,
                        policyVersion = policyPayload?.policyVersion ?? currentCache.policyVersion,
                    });

                    cachedSnapshot = CreateSnapshot(
                        state,
                        false,
                        false,
                        licensePayload,
                        policyPayload,
                        previousValidatedAtUtc,
                        null,
                        errorMessageJapanese,
                        errorMessageEnglish);
                    snapshotInitialized = true;
                    return cachedSnapshot;
                }

                PoiLightChangerLicenseStore.Save(new PoiLightChangerCachedLicenseState
                {
                    storedLicenseCode = licenseCode.Trim(),
                    licensePayloadBase64Url = licensePayloadBase64Url,
                    policyEnvelopeJson = policyEnvelopeJson,
                    policyPayloadBase64Url = policyPayloadBase64Url,
                    lastFetchedAtUtc = fetchedAtUtc?.ToString("O"),
                    lastValidatedAtUtc = validatedAtUtc?.ToString("O"),
                    offlineGraceUntilUtc = offlineGraceUntilUtc?.ToString("O"),
                    policyVersion = policyPayload?.policyVersion ?? 0,
                });

                cachedSnapshot = CreateSnapshot(
                    state,
                    true,
                    usesCachedPolicy,
                    licensePayload,
                    policyPayload,
                    validatedAtUtc,
                    offlineGraceUntilUtc,
                    "ライセンスを認証しました。",
                    "The license has been validated.");
                snapshotInitialized = true;
                return cachedSnapshot;
            }
        }

        public static PoiLightChangerLicenseSnapshot RefreshPolicyIfNeeded(bool force)
        {
            lock (SyncRoot)
            {
                var cache = PoiLightChangerLicenseStore.Load();
                if (string.IsNullOrWhiteSpace(cache.storedLicenseCode))
                {
                    cachedSnapshot = EvaluateStoredState();
                    snapshotInitialized = true;
                    return cachedSnapshot;
                }

                if (!force && !ShouldRefresh(cache))
                {
                    cachedSnapshot = EvaluateStoredState();
                    snapshotInitialized = true;
                    return cachedSnapshot;
                }

                cachedSnapshot = ValidateAndActivate(cache.storedLicenseCode, allowNetwork: true);
                snapshotInitialized = true;
                return cachedSnapshot;
            }
        }

        public static PoiLightChangerLicenseSnapshot RefreshPolicyWithResult(string licenseCode, PoiLightChangerPolicyFetchResult fetchResult)
        {
            lock (SyncRoot)
            {
                if (string.IsNullOrWhiteSpace(licenseCode))
                {
                    cachedSnapshot = EvaluateStoredState();
                    snapshotInitialized = true;
                    return cachedSnapshot;
                }

                if (fetchResult == null)
                {
                    cachedSnapshot = EvaluateStoredState();
                    snapshotInitialized = true;
                    return cachedSnapshot;
                }

                if (!PoiLightChangerSignatureVerifier.TryVerifyLicenseCode(
                        licenseCode,
                        out var licensePayload,
                        out var licensePayloadBase64Url,
                        out var errorMessageJapanese,
                        out var errorMessageEnglish))
                {
                    cachedSnapshot = CreateSnapshot(
                        PoiLightChangerLicenseValidationState.SignatureInvalid,
                        false,
                        false,
                        null,
                        null,
                        null,
                        null,
                        errorMessageJapanese,
                        errorMessageEnglish);
                    snapshotInitialized = true;
                    return cachedSnapshot;
                }

                var currentCache = PoiLightChangerLicenseStore.Load();
                var previousValidatedAtUtc = TryGetStoredUtc(currentCache.lastValidatedAtUtc);
                if (!fetchResult.Success)
                {
                    cachedSnapshot = UseCachedPolicy(
                        currentCache,
                        licenseCode,
                        licensePayload,
                        licensePayloadBase64Url,
                        fetchResult.ErrorMessageJapanese,
                        fetchResult.ErrorMessageEnglish);
                    snapshotInitialized = true;
                    return cachedSnapshot;
                }

                var policyPayload = fetchResult.Payload;
                var policyEnvelopeJson = fetchResult.EnvelopeJson ?? string.Empty;
                var policyPayloadBase64Url = fetchResult.PayloadBase64Url ?? string.Empty;
                var fetchedAtUtc = fetchResult.FetchedAtUtc;

                if (!IsLicenseTimeWindowValid(licensePayload, out errorMessageJapanese, out errorMessageEnglish))
                {
                    cachedSnapshot = CreateSnapshot(
                        PoiLightChangerLicenseValidationState.LicenseExpired,
                        false,
                        false,
                        licensePayload,
                        policyPayload,
                        previousValidatedAtUtc,
                        null,
                        errorMessageJapanese,
                        errorMessageEnglish);
                    snapshotInitialized = true;
                    return cachedSnapshot;
                }

                if (!TryValidateAgainstPolicy(licensePayload, policyPayload, out errorMessageJapanese, out errorMessageEnglish))
                {
                    PoiLightChangerLicenseStore.Save(new PoiLightChangerCachedLicenseState
                    {
                        storedLicenseCode = licenseCode.Trim(),
                        licensePayloadBase64Url = licensePayloadBase64Url,
                        policyEnvelopeJson = policyEnvelopeJson,
                        policyPayloadBase64Url = policyPayloadBase64Url,
                        lastFetchedAtUtc = fetchedAtUtc.ToString("O"),
                        lastValidatedAtUtc = previousValidatedAtUtc?.ToString("O"),
                        offlineGraceUntilUtc = null,
                        policyVersion = policyPayload?.policyVersion ?? currentCache.policyVersion,
                    });

                    cachedSnapshot = CreateSnapshot(
                        PoiLightChangerLicenseValidationState.PolicyInvalid,
                        false,
                        false,
                        licensePayload,
                        policyPayload,
                        previousValidatedAtUtc,
                        null,
                        errorMessageJapanese,
                        errorMessageEnglish);
                    snapshotInitialized = true;
                    return cachedSnapshot;
                }

                var validatedAtUtc = DateTimeOffset.UtcNow;
                var offlineGraceUntilUtc = validatedAtUtc.AddDays(policyPayload.offlineGraceDays);
                PoiLightChangerLicenseStore.Save(new PoiLightChangerCachedLicenseState
                {
                    storedLicenseCode = licenseCode.Trim(),
                    licensePayloadBase64Url = licensePayloadBase64Url,
                    policyEnvelopeJson = policyEnvelopeJson,
                    policyPayloadBase64Url = policyPayloadBase64Url,
                    lastFetchedAtUtc = fetchedAtUtc.ToString("O"),
                    lastValidatedAtUtc = validatedAtUtc.ToString("O"),
                    offlineGraceUntilUtc = offlineGraceUntilUtc.ToString("O"),
                    policyVersion = policyPayload?.policyVersion ?? 0,
                });

                cachedSnapshot = CreateSnapshot(
                    PoiLightChangerLicenseValidationState.Licensed,
                    true,
                    false,
                    licensePayload,
                    policyPayload,
                    validatedAtUtc,
                    offlineGraceUntilUtc,
                    "ライセンスを認証しました。",
                    "The license has been validated.");
                snapshotInitialized = true;
                return cachedSnapshot;
            }
        }

        public static void ClearStoredLicense()
        {
            lock (SyncRoot)
            {
                PoiLightChangerLicenseStore.Clear();
                cachedSnapshot = CreateSnapshot(
                    PoiLightChangerLicenseValidationState.Unlicensed,
                    false,
                    false,
                    null,
                    null,
                    null,
                    null,
                    "ライセンスを削除しました。",
                    "The stored license has been cleared.");
                snapshotInitialized = true;
            }
        }

        private static PoiLightChangerLicenseSnapshot EvaluateStoredState()
        {
            var cache = PoiLightChangerLicenseStore.Load();
            if (string.IsNullOrWhiteSpace(cache.storedLicenseCode))
            {
                return CreateSnapshot(
                    PoiLightChangerLicenseValidationState.Unlicensed,
                    false,
                    false,
                    null,
                    null,
                    TryGetStoredUtc(cache.lastValidatedAtUtc),
                    TryGetStoredUtc(cache.offlineGraceUntilUtc),
                    "ライセンスは登録されていません。",
                    "No license has been registered.");
            }

            if (!PoiLightChangerSignatureVerifier.TryVerifyLicenseCode(
                    cache.storedLicenseCode,
                    out var licensePayload,
                    out _,
                    out var errorMessageJapanese,
                    out var errorMessageEnglish))
            {
                return CreateSnapshot(
                    PoiLightChangerLicenseValidationState.SignatureInvalid,
                    false,
                    false,
                    null,
                    null,
                    TryGetStoredUtc(cache.lastValidatedAtUtc),
                    TryGetStoredUtc(cache.offlineGraceUntilUtc),
                    errorMessageJapanese,
                    errorMessageEnglish);
            }

            if (!TryLoadCachedPolicy(cache, out var policyPayload, out errorMessageJapanese, out errorMessageEnglish))
            {
                return CreateSnapshot(
                    PoiLightChangerLicenseValidationState.PolicyInvalid,
                    false,
                    false,
                    licensePayload,
                    null,
                    TryGetStoredUtc(cache.lastValidatedAtUtc),
                    TryGetStoredUtc(cache.offlineGraceUntilUtc),
                    errorMessageJapanese,
                    errorMessageEnglish);
            }

            if (!IsLicenseTimeWindowValid(licensePayload, out var nowWindowMessageJapanese, out var nowWindowMessageEnglish))
            {
                return CreateSnapshot(
                    PoiLightChangerLicenseValidationState.LicenseExpired,
                    false,
                    false,
                    licensePayload,
                    policyPayload,
                    TryGetStoredUtc(cache.lastValidatedAtUtc),
                    TryGetStoredUtc(cache.offlineGraceUntilUtc),
                    nowWindowMessageJapanese,
                    nowWindowMessageEnglish);
            }

            if (!TryValidateAgainstPolicy(licensePayload, policyPayload, out errorMessageJapanese, out errorMessageEnglish))
            {
                return CreateSnapshot(
                    PoiLightChangerLicenseValidationState.PolicyInvalid,
                    false,
                    false,
                    licensePayload,
                    policyPayload,
                    TryGetStoredUtc(cache.lastValidatedAtUtc),
                    TryGetStoredUtc(cache.offlineGraceUntilUtc),
                    errorMessageJapanese,
                    errorMessageEnglish);
            }

            var offlineGraceUntilUtc = TryGetStoredUtc(cache.offlineGraceUntilUtc);
            var lastValidatedAtUtc = TryGetStoredUtc(cache.lastValidatedAtUtc);
            if (offlineGraceUntilUtc.HasValue && offlineGraceUntilUtc.Value >= DateTimeOffset.UtcNow)
            {
                return CreateSnapshot(
                    PoiLightChangerLicenseValidationState.LicensedUsingCache,
                    true,
                    true,
                    licensePayload,
                    policyPayload,
                    lastValidatedAtUtc,
                    offlineGraceUntilUtc,
                    "前回成功した認証キャッシュを使用してライセンスを有効化しています。",
                    "The license is active using the last successful policy cache.");
            }

            return CreateSnapshot(
                PoiLightChangerLicenseValidationState.PolicyExpired,
                false,
                false,
                licensePayload,
                policyPayload,
                lastValidatedAtUtc,
                offlineGraceUntilUtc,
                "オフライン猶予が切れたため、ライセンスの再認証が必要です。",
                "The offline grace period has expired and the policy must be refreshed.");
        }

        private static PoiLightChangerLicenseSnapshot UseCachedPolicy(
            PoiLightChangerCachedLicenseState currentCache,
            string licenseCode,
            PoiLightChangerLicensePayload licensePayload,
            string licensePayloadBase64Url,
            string fetchErrorMessageJapanese = null,
            string fetchErrorMessageEnglish = null)
        {
            if (!TryLoadCachedPolicy(currentCache, out var cachedPolicy, out var policyErrorMessageJapanese, out var policyErrorMessageEnglish))
            {
                cachedSnapshot = CreateSnapshot(
                    PoiLightChangerLicenseValidationState.PolicyInvalid,
                    false,
                    false,
                    licensePayload,
                    null,
                    TryGetStoredUtc(currentCache.lastValidatedAtUtc),
                    TryGetStoredUtc(currentCache.offlineGraceUntilUtc),
                    policyErrorMessageJapanese,
                    policyErrorMessageEnglish);
                snapshotInitialized = true;
                return cachedSnapshot;
            }

            if (!IsLicenseTimeWindowValid(licensePayload, out var windowErrorMessageJapanese, out var windowErrorMessageEnglish))
            {
                cachedSnapshot = CreateSnapshot(
                    PoiLightChangerLicenseValidationState.LicenseExpired,
                    false,
                    false,
                    licensePayload,
                    cachedPolicy,
                    TryGetStoredUtc(currentCache.lastValidatedAtUtc),
                    TryGetStoredUtc(currentCache.offlineGraceUntilUtc),
                    windowErrorMessageJapanese,
                    windowErrorMessageEnglish);
                snapshotInitialized = true;
                return cachedSnapshot;
            }

            if (!TryValidateAgainstPolicy(licensePayload, cachedPolicy, out policyErrorMessageJapanese, out policyErrorMessageEnglish))
            {
                cachedSnapshot = CreateSnapshot(
                    PoiLightChangerLicenseValidationState.PolicyInvalid,
                    false,
                    false,
                    licensePayload,
                    cachedPolicy,
                    TryGetStoredUtc(currentCache.lastValidatedAtUtc),
                    TryGetStoredUtc(currentCache.offlineGraceUntilUtc),
                    policyErrorMessageJapanese,
                    policyErrorMessageEnglish);
                snapshotInitialized = true;
                return cachedSnapshot;
            }

            var offlineGraceUntilUtc = TryGetStoredUtc(currentCache.offlineGraceUntilUtc);
            var lastValidatedAtUtc = TryGetStoredUtc(currentCache.lastValidatedAtUtc);
            var now = DateTimeOffset.UtcNow;
            if (offlineGraceUntilUtc.HasValue && offlineGraceUntilUtc.Value >= now)
            {
                currentCache.storedLicenseCode = licenseCode.Trim();
                currentCache.licensePayloadBase64Url = licensePayloadBase64Url;
                PoiLightChangerLicenseStore.Save(currentCache);
                cachedSnapshot = CreateSnapshot(
                    string.IsNullOrWhiteSpace(fetchErrorMessageJapanese)
                        ? PoiLightChangerLicenseValidationState.LicensedUsingCache
                        : PoiLightChangerLicenseValidationState.PolicyFetchFailedWithinGrace,
                    true,
                    true,
                    licensePayload,
                    cachedPolicy,
                    lastValidatedAtUtc,
                    offlineGraceUntilUtc,
                    string.IsNullOrWhiteSpace(fetchErrorMessageJapanese)
                        ? "前回成功した認証キャッシュを使用してライセンスを有効化しています。"
                        : "ライセンスの再認証に失敗したため、猶予期間中はキャッシュを使って継続します。",
                    string.IsNullOrWhiteSpace(fetchErrorMessageEnglish)
                        ? "The license is active using the last successful policy cache."
                        : "Policy refresh failed, so the cached policy will be used during the grace period.");
                snapshotInitialized = true;
                return cachedSnapshot;
            }

            cachedSnapshot = CreateSnapshot(
                PoiLightChangerLicenseValidationState.PolicyExpired,
                false,
                false,
                licensePayload,
                cachedPolicy,
                lastValidatedAtUtc,
                offlineGraceUntilUtc,
                string.IsNullOrWhiteSpace(fetchErrorMessageJapanese)
                    ? "オフライン猶予が切れたため、ライセンスの再認証が必要です。"
                    : "ライセンスの再認証に失敗し、オフライン猶予も切れています。",
                string.IsNullOrWhiteSpace(fetchErrorMessageEnglish)
                    ? "The offline grace period has expired and the policy must be refreshed."
                    : "Policy refresh failed and the offline grace period has also expired.");
            snapshotInitialized = true;
            return cachedSnapshot;
        }

        private static bool TryLoadCachedPolicy(
            PoiLightChangerCachedLicenseState cache,
            out PoiLightChangerPolicyPayload policyPayload,
            out string errorMessageJapanese,
            out string errorMessageEnglish)
        {
            policyPayload = null;
            errorMessageJapanese = string.Empty;
            errorMessageEnglish = string.Empty;

            if (string.IsNullOrWhiteSpace(cache.policyEnvelopeJson))
            {
                errorMessageJapanese = "保存された認証キャッシュが古いため、ライセンスの再認証が必要です。";
                errorMessageEnglish = "The stored policy cache is outdated and the policy must be refreshed.";
                return false;
            }

            if (!PoiLightChangerSignatureVerifier.TryVerifyPolicyEnvelope(
                    cache.policyEnvelopeJson,
                    out policyPayload,
                    out _,
                    out errorMessageJapanese,
                    out errorMessageEnglish))
            {
                return false;
            }

            if (!string.Equals(policyPayload.product, PoiLightChangerLicenseDefaults.Product, StringComparison.Ordinal))
            {
                errorMessageJapanese = "保存された認証キャッシュのproductが一致しません。";
                errorMessageEnglish = "The stored policy cache product does not match.";
                policyPayload = null;
                return false;
            }

            return true;
        }

        private static bool TryValidateAgainstPolicy(
            PoiLightChangerLicensePayload licensePayload,
            PoiLightChangerPolicyPayload policyPayload,
            out string errorMessageJapanese,
            out string errorMessageEnglish)
        {
            errorMessageJapanese = string.Empty;
            errorMessageEnglish = string.Empty;

            if (policyPayload == null)
            {
                errorMessageJapanese = "ライセンスの認証情報が読み込まれていません。";
                errorMessageEnglish = "No policy has been loaded.";
                return false;
            }

            if (licensePayload.sv < policyPayload.minimumLicensePayloadSchema)
            {
                errorMessageJapanese = "ライセンスpayloadのversionが古いため使用できません。";
                errorMessageEnglish = "The license payload version is too old to use.";
                return false;
            }

            if (policyPayload.allowedMajors == null || Array.IndexOf(policyPayload.allowedMajors, licensePayload.major) < 0)
            {
                errorMessageJapanese = "このライセンスコードは現在のmajorでは使用できません。";
                errorMessageEnglish = "This license code cannot be used with the current major.";
                return false;
            }

            if (policyPayload.revokedCohorts != null && Array.IndexOf(policyPayload.revokedCohorts, licensePayload.cohort) >= 0)
            {
                errorMessageJapanese = "このcohortのライセンスコードは失効しています。";
                errorMessageEnglish = "This cohort license code has been revoked.";
                return false;
            }

            if (policyPayload.revokedKids != null && Array.IndexOf(policyPayload.revokedKids, licensePayload.kid) >= 0)
            {
                errorMessageJapanese = "この署名鍵のライセンスコードは失効しています。";
                errorMessageEnglish = "This signing key has been revoked.";
                return false;
            }

            return true;
        }

        private static bool IsLicenseTimeWindowValid(
            PoiLightChangerLicensePayload payload,
            out string errorMessageJapanese,
            out string errorMessageEnglish)
        {
            errorMessageJapanese = string.Empty;
            errorMessageEnglish = string.Empty;
            var now = DateTimeOffset.UtcNow;

            if (!string.IsNullOrWhiteSpace(payload.notBefore) &&
                PoiLightChangerSignatureVerifier.TryParseUtc(payload.notBefore, out var notBeforeUtc) &&
                now < notBeforeUtc)
            {
                errorMessageJapanese = "ライセンスコードはまだ有効期間前です。";
                errorMessageEnglish = "The license code is not active yet.";
                return false;
            }

            if (!string.IsNullOrWhiteSpace(payload.expiresAt) &&
                PoiLightChangerSignatureVerifier.TryParseUtc(payload.expiresAt, out var expiresAtUtc) &&
                now >= expiresAtUtc)
            {
                errorMessageJapanese = "ライセンスコードの有効期限が切れています。";
                errorMessageEnglish = "The license code has expired.";
                return false;
            }

            return true;
        }

        private static bool ShouldReplacePolicy(int cachedPolicyVersion, int fetchedPolicyVersion)
        {
            return fetchedPolicyVersion >= cachedPolicyVersion;
        }

        private static bool ShouldRefresh(PoiLightChangerCachedLicenseState cache)
        {
            var lastFetchedAtUtc = TryGetStoredUtc(cache.lastFetchedAtUtc);
            if (!lastFetchedAtUtc.HasValue)
            {
                return true;
            }

            var refreshIntervalHours = PoiLightChangerLicenseDefaults.RefreshIntervalHours;
            if (TryLoadCachedPolicy(cache, out var cachedPolicy, out _, out _))
            {
                refreshIntervalHours = cachedPolicy.refreshIntervalHours is >= 1 and <= 168
                    ? cachedPolicy.refreshIntervalHours
                    : PoiLightChangerLicenseDefaults.RefreshIntervalHours;
            }

            return DateTimeOffset.UtcNow >= lastFetchedAtUtc.Value.AddHours(refreshIntervalHours);
        }

        private static DateTimeOffset? TryGetStoredUtc(string value)
        {
            return PoiLightChangerSignatureVerifier.TryParseUtc(value, out var timestamp)
                ? timestamp
                : null;
        }

        private static PoiLightChangerLicenseSnapshot CreateSnapshot(
            PoiLightChangerLicenseValidationState state,
            bool isLicensed,
            bool usesCachedPolicy,
            PoiLightChangerLicensePayload licensePayload,
            PoiLightChangerPolicyPayload policyPayload,
            DateTimeOffset? lastValidatedAtUtc,
            DateTimeOffset? offlineGraceUntilUtc,
            string statusMessageJapanese,
            string statusMessageEnglish)
        {
            return new PoiLightChangerLicenseSnapshot
            {
                ValidationState = state,
                IsLicensed = isLicensed,
                UsesCachedPolicy = usesCachedPolicy,
                LicensePayload = licensePayload,
                PolicyPayload = policyPayload,
                LastValidatedAtUtc = lastValidatedAtUtc,
                OfflineGraceUntilUtc = offlineGraceUntilUtc,
                StatusMessageJapanese = statusMessageJapanese ?? string.Empty,
                StatusMessageEnglish = statusMessageEnglish ?? string.Empty,
            };
        }
    }
}
