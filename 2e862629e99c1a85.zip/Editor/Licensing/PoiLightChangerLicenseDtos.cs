using System;

namespace io.github.m8pix.poi_light_changer
{
    [Serializable]
    internal sealed class PoiLightChangerLicensePayload
    {
        public int sv;
        public string product;
        public string licenseType;
        public int major;
        public string cohort;
        public string issuedAt;
        public string notBefore;
        public string expiresAt;
        public string kid;
        public string nonce;
    }

    [Serializable]
    internal sealed class PoiLightChangerPolicyEnvelope
    {
        public string format;
        public string payload;
        public string signature;
    }

    [Serializable]
    internal sealed class PoiLightChangerPolicyPayload
    {
        public int sv;
        public string product;
        public int policyVersion;
        public string publishedAt;
        public string kid;
        public int[] allowedMajors;
        public string[] revokedCohorts;
        public string[] revokedKids;
        public int minimumLicensePayloadSchema;
        public int offlineGraceDays;
        public int refreshIntervalHours;
        public string message;
    }

    [Serializable]
    internal sealed class PoiLightChangerCachedLicenseState
    {
        public string storedLicenseCode;
        public string licensePayloadBase64Url;
        public string policyEnvelopeJson;
        public string policyPayloadBase64Url;
        public string lastFetchedAtUtc;
        public string lastValidatedAtUtc;
        public string offlineGraceUntilUtc;
        public int policyVersion;
    }
}
