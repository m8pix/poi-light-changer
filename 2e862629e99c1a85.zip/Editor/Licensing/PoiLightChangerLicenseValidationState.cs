namespace io.github.m8pix.poi_light_changer
{
    internal enum PoiLightChangerLicenseValidationState
    {
        Unlicensed = 0,
        Licensed = 1,
        LicensedUsingCache = 2,
        PolicyFetchFailedWithinGrace = 3,
        PolicyExpired = 4,
        LicenseExpired = 5,
        SignatureInvalid = 6,
        PolicyInvalid = 7,
    }
}
