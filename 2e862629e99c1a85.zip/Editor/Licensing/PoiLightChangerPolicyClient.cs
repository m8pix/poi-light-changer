using System;
using System.Threading;
using UnityEngine.Networking;

namespace io.github.m8pix.poi_light_changer
{
    internal sealed class PoiLightChangerPolicyFetchResult
    {
        public bool Success { get; set; }

        public PoiLightChangerPolicyPayload Payload { get; set; }

        public string PayloadBase64Url { get; set; } = string.Empty;

        public string EnvelopeJson { get; set; } = string.Empty;

        public DateTimeOffset FetchedAtUtc { get; set; }

        public string ErrorMessageJapanese { get; set; } = string.Empty;

        public string ErrorMessageEnglish { get; set; } = string.Empty;
    }

    internal sealed class PoiLightChangerPolicyFetchOperation : IDisposable
    {
        private readonly UnityWebRequest request;
        private readonly UnityWebRequestAsyncOperation operation;
        private readonly DateTimeOffset startedAtUtc;
        private readonly int timeoutSeconds;
        private bool completed;

        public PoiLightChangerPolicyFetchOperation(UnityWebRequest request, UnityWebRequestAsyncOperation operation, int timeoutSeconds)
        {
            this.request = request;
            this.operation = operation;
            this.timeoutSeconds = Math.Max(1, timeoutSeconds);
            startedAtUtc = DateTimeOffset.UtcNow;
        }

        public bool TryGetResult(out PoiLightChangerPolicyFetchResult result)
        {
            result = null;
            if (completed)
            {
                return false;
            }

            if (!operation.isDone)
            {
                var elapsed = DateTimeOffset.UtcNow - startedAtUtc;
                if (elapsed.TotalSeconds < timeoutSeconds)
                {
                    return false;
                }

                request.Abort();
                result = PoiLightChangerPolicyClient.CreateTimeoutResult();
                completed = true;
                Dispose();
                return true;
            }

            result = PoiLightChangerPolicyClient.CreateResultFromRequest(request);
            completed = true;
            Dispose();
            return true;
        }

        public void Dispose()
        {
            request?.Dispose();
        }
    }

    internal sealed class PoiLightChangerPolicyClient
    {
        public PoiLightChangerPolicyFetchOperation BeginFetch(int timeoutSeconds = PoiLightChangerLicenseDefaults.PolicyFetchTimeoutSeconds)
        {
            if (!Uri.TryCreate(PoiLightChangerLicenseDefaults.PolicyUrl, UriKind.Absolute, out var uri))
            {
                return null;
            }

            var request = UnityWebRequest.Get(uri);
            request.timeout = Math.Max(1, timeoutSeconds);
            var operation = request.SendWebRequest();
            return new PoiLightChangerPolicyFetchOperation(request, operation, timeoutSeconds);
        }

        public PoiLightChangerPolicyFetchResult Fetch(int timeoutSeconds = PoiLightChangerLicenseDefaults.PolicyFetchTimeoutSeconds)
        {
            if (!Uri.TryCreate(PoiLightChangerLicenseDefaults.PolicyUrl, UriKind.Absolute, out _))
            {
                return new PoiLightChangerPolicyFetchResult
                {
                    FetchedAtUtc = DateTimeOffset.UtcNow,
                    ErrorMessageJapanese = "policy URL が不正です。",
                    ErrorMessageEnglish = "The policy URL is invalid.",
                };
            }

            using var operation = BeginFetch(timeoutSeconds);
            if (operation == null)
            {
                return new PoiLightChangerPolicyFetchResult
                {
                    FetchedAtUtc = DateTimeOffset.UtcNow,
                    ErrorMessageJapanese = "policy URL が不正です。",
                    ErrorMessageEnglish = "The policy URL is invalid.",
                };
            }

            PoiLightChangerPolicyFetchResult result;
            while (!operation.TryGetResult(out result))
            {
                Thread.Sleep(10);
            }

            return result;
        }

        internal static PoiLightChangerPolicyFetchResult CreateTimeoutResult()
        {
            return new PoiLightChangerPolicyFetchResult
            {
                FetchedAtUtc = DateTimeOffset.UtcNow,
                ErrorMessageJapanese = "policy.json の取得がタイムアウトしたため、保存済み cache へフォールバックします。",
                ErrorMessageEnglish = "Fetching policy.json timed out, so PLC will fall back to the cached policy.",
            };
        }

        internal static PoiLightChangerPolicyFetchResult CreateResultFromRequest(UnityWebRequest request)
        {
            var result = new PoiLightChangerPolicyFetchResult
            {
                FetchedAtUtc = DateTimeOffset.UtcNow,
            };

            if (request == null)
            {
                result.ErrorMessageJapanese = "policy.json の取得に失敗しました。";
                result.ErrorMessageEnglish = "Failed to fetch policy.json.";
                return result;
            }

            if (request.result != UnityWebRequest.Result.Success)
            {
                result.ErrorMessageJapanese = "policy.json の取得に失敗しました。";
                result.ErrorMessageEnglish = "Failed to fetch policy.json.";
                return result;
            }

            if (!PoiLightChangerSignatureVerifier.TryVerifyPolicyEnvelope(
                    request.downloadHandler.text,
                    out var payload,
                    out var payloadBase64Url,
                    out var errorMessageJapanese,
                    out var errorMessageEnglish))
            {
                result.ErrorMessageJapanese = errorMessageJapanese;
                result.ErrorMessageEnglish = errorMessageEnglish;
                return result;
            }

            payload.offlineGraceDays = Math.Clamp(payload.offlineGraceDays, 1, 30);
            payload.refreshIntervalHours = payload.refreshIntervalHours is >= 1 and <= 168
                ? payload.refreshIntervalHours
                : PoiLightChangerLicenseDefaults.RefreshIntervalHours;

            result.Success = true;
            result.Payload = payload;
            result.PayloadBase64Url = payloadBase64Url;
            result.EnvelopeJson = request.downloadHandler.text ?? string.Empty;
            return result;
        }
    }
}
