using System.IO;
using UnityEditorInternal;
using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    internal static class PoiLightChangerLicenseStore
    {
        private const string JsonFilePath = "PoiLightChanger/LicenseState.json";

        public static PoiLightChangerCachedLicenseState Load()
        {
            var path = GetAbsoluteFilePath();
            if (!File.Exists(path))
            {
                return new PoiLightChangerCachedLicenseState();
            }

            try
            {
                var json = File.ReadAllText(path);
                if (string.IsNullOrWhiteSpace(json))
                {
                    return new PoiLightChangerCachedLicenseState();
                }

                return JsonUtility.FromJson<PoiLightChangerCachedLicenseState>(json) ?? new PoiLightChangerCachedLicenseState();
            }
            catch (System.Exception exception)
            {
                Debug.LogWarning(
                    $"[Poi Light Changer] Failed to load the stored license state. {exception.GetType().Name}: {exception.Message}");
                return new PoiLightChangerCachedLicenseState();
            }
        }

        public static void Save(PoiLightChangerCachedLicenseState state)
        {
            state ??= new PoiLightChangerCachedLicenseState();
            try
            {
                var path = GetAbsoluteFilePath();
                var directory = Path.GetDirectoryName(path);
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                File.WriteAllText(path, JsonUtility.ToJson(state, true));
            }
            catch (System.Exception exception)
            {
                Debug.LogWarning(
                    $"[Poi Light Changer] Failed to save the license state. {exception.GetType().Name}: {exception.Message}");
            }
        }

        public static void Clear()
        {
            try
            {
                var path = GetAbsoluteFilePath();
                if (File.Exists(path))
                {
                    File.Delete(path);
                }
            }
            catch (System.Exception exception)
            {
                Debug.LogWarning(
                    $"[Poi Light Changer] Failed to clear the stored license state. {exception.GetType().Name}: {exception.Message}");
            }
        }

        private static string GetAbsoluteFilePath()
        {
            return Path.Combine(InternalEditorUtility.unityPreferencesFolder, JsonFilePath);
        }
    }
}
