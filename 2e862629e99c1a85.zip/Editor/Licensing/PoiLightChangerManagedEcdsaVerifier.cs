using System;
using System.Numerics;
using System.Security.Cryptography;

namespace io.github.m8pix.poi_light_changer
{
    internal static class PoiLightChangerManagedEcdsaVerifier
    {
        private static readonly BigInteger Prime = FromHex("FFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF");
        private static readonly BigInteger CurveA = FromHex("FFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFC");
        private static readonly BigInteger CurveB = FromHex("5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B");
        private static readonly BigInteger CurveOrder = FromHex("FFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551");
        private static readonly AffinePoint Generator = new(
            FromHex("6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296"),
            FromHex("4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5"));

        public static bool VerifySha256(byte[] publicKeyX, byte[] publicKeyY, byte[] payloadBytes, byte[] p1363SignatureBytes)
        {
            if (publicKeyX == null || publicKeyX.Length != 32 ||
                publicKeyY == null || publicKeyY.Length != 32 ||
                payloadBytes == null || payloadBytes.Length == 0 ||
                p1363SignatureBytes == null || p1363SignatureBytes.Length != 64)
            {
                return false;
            }

            using var sha256 = SHA256.Create();
            var hashBytes = sha256.ComputeHash(payloadBytes);
            var hashValue = FromBigEndian(hashBytes);
            var r = FromBigEndian(p1363SignatureBytes, 0, 32);
            var s = FromBigEndian(p1363SignatureBytes, 32, 32);

            if (r.Sign <= 0 || s.Sign <= 0 || r >= CurveOrder || s >= CurveOrder)
            {
                return false;
            }

            var publicKeyPoint = new AffinePoint(
                FromBigEndian(publicKeyX),
                FromBigEndian(publicKeyY));
            if (!IsPointOnCurve(publicKeyPoint))
            {
                return false;
            }

            var w = ModInverse(s, CurveOrder);
            var u1 = Mod(hashValue * w, CurveOrder);
            var u2 = Mod(r * w, CurveOrder);
            var resultPoint = AddPoints(
                MultiplyPoint(Generator, u1),
                MultiplyPoint(publicKeyPoint, u2));
            if (resultPoint.IsInfinity)
            {
                return false;
            }

            var x = Mod(resultPoint.X, CurveOrder);
            return x == r;
        }

        private static bool IsPointOnCurve(AffinePoint point)
        {
            if (point.IsInfinity ||
                point.X.Sign < 0 || point.X >= Prime ||
                point.Y.Sign < 0 || point.Y >= Prime)
            {
                return false;
            }

            var left = Mod(point.Y * point.Y, Prime);
            var right = Mod((point.X * point.X * point.X) + (CurveA * point.X) + CurveB, Prime);
            return left == right;
        }

        private static AffinePoint MultiplyPoint(AffinePoint point, BigInteger scalar)
        {
            var result = AffinePoint.Infinity;
            var addend = point;
            var k = scalar;
            while (k > 0)
            {
                if (!k.IsEven)
                {
                    result = AddPoints(result, addend);
                }

                addend = DoublePoint(addend);
                k >>= 1;
            }

            return result;
        }

        private static AffinePoint AddPoints(AffinePoint left, AffinePoint right)
        {
            if (left.IsInfinity)
            {
                return right;
            }

            if (right.IsInfinity)
            {
                return left;
            }

            if (left.X == right.X)
            {
                if (Mod(left.Y + right.Y, Prime).IsZero)
                {
                    return AffinePoint.Infinity;
                }

                return DoublePoint(left);
            }

            var slope = Mod(
                (right.Y - left.Y) * ModInverse(right.X - left.X, Prime),
                Prime);
            var x = Mod((slope * slope) - left.X - right.X, Prime);
            var y = Mod((slope * (left.X - x)) - left.Y, Prime);
            return new AffinePoint(x, y);
        }

        private static AffinePoint DoublePoint(AffinePoint point)
        {
            if (point.IsInfinity || point.Y.IsZero)
            {
                return AffinePoint.Infinity;
            }

            var slope = Mod(
                ((3 * point.X * point.X) + CurveA) * ModInverse(2 * point.Y, Prime),
                Prime);
            var x = Mod((slope * slope) - (2 * point.X), Prime);
            var y = Mod((slope * (point.X - x)) - point.Y, Prime);
            return new AffinePoint(x, y);
        }

        private static BigInteger ModInverse(BigInteger value, BigInteger modulus)
        {
            return BigInteger.ModPow(Mod(value, modulus), modulus - 2, modulus);
        }

        private static BigInteger Mod(BigInteger value, BigInteger modulus)
        {
            var result = value % modulus;
            return result.Sign < 0 ? result + modulus : result;
        }

        private static BigInteger FromHex(string hex)
        {
            var byteCount = hex.Length / 2;
            var bytes = new byte[byteCount];
            for (var index = 0; index < byteCount; index++)
            {
                bytes[index] = Convert.ToByte(hex.Substring(index * 2, 2), 16);
            }

            return FromBigEndian(bytes);
        }

        private static BigInteger FromBigEndian(byte[] bytes)
        {
            return FromBigEndian(bytes, 0, bytes.Length);
        }

        private static BigInteger FromBigEndian(byte[] bytes, int offset, int length)
        {
            var littleEndian = new byte[length + 1];
            for (var index = 0; index < length; index++)
            {
                littleEndian[index] = bytes[offset + length - 1 - index];
            }

            return new BigInteger(littleEndian);
        }

        private readonly struct AffinePoint
        {
            public static readonly AffinePoint Infinity = new(true);

            public AffinePoint(BigInteger x, BigInteger y)
            {
                X = x;
                Y = y;
                IsInfinity = false;
            }

            private AffinePoint(bool isInfinity)
            {
                X = BigInteger.Zero;
                Y = BigInteger.Zero;
                IsInfinity = isInfinity;
            }

            public BigInteger X { get; }

            public BigInteger Y { get; }

            public bool IsInfinity { get; }
        }
    }
}
