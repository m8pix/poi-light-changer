using System;

namespace io.github.m8pix.poi_light_changer
{
    internal static class PoiLightChangerBase64Url
    {
        public static bool TryDecode(string text, out byte[] bytes)
        {
            bytes = Array.Empty<byte>();
            if (string.IsNullOrWhiteSpace(text))
            {
                return false;
            }

            var normalized = text.Replace('-', '+').Replace('_', '/');
            var remainder = normalized.Length % 4;
            if (remainder != 0)
            {
                normalized = normalized.PadRight(normalized.Length + (4 - remainder), '=');
            }

            try
            {
                bytes = Convert.FromBase64String(normalized);
                return true;
            }
            catch
            {
                bytes = Array.Empty<byte>();
                return false;
            }
        }

        public static string Encode(byte[] bytes)
        {
            if (bytes == null || bytes.Length == 0)
            {
                return string.Empty;
            }

            return Convert.ToBase64String(bytes)
                .TrimEnd('=')
                .Replace('+', '-')
                .Replace('/', '_');
        }
    }
}
