using System;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    internal static class PoiLightChangerSignatureVerifier
    {
        public static bool TryVerifyLicenseCode(
            string licenseCode,
            out PoiLightChangerLicensePayload payload,
            out string payloadBase64Url,
            out string errorMessageJapanese,
            out string errorMessageEnglish)
        {
            payload = null;
            payloadBase64Url = string.Empty;
            errorMessageJapanese = "ライセンスコードの署名検証に失敗しました。";
            errorMessageEnglish = "Failed to verify the license code signature.";

            if (string.IsNullOrWhiteSpace(licenseCode))
            {
                errorMessageJapanese = "ライセンスコードが入力されていません。";
                errorMessageEnglish = "No license code has been entered.";
                return false;
            }

            var segments = licenseCode.Trim().Split('.');
            if (segments.Length != 3 || !string.Equals(segments[0], PoiLightChangerLicenseDefaults.LicenseCodePrefix, StringComparison.Ordinal))
            {
                errorMessageJapanese = "ライセンスコードの形式が不正です。";
                errorMessageEnglish = "The license code format is invalid.";
                return false;
            }

            payloadBase64Url = segments[1];
            if (!PoiLightChangerBase64Url.TryDecode(segments[1], out var payloadBytes) ||
                !PoiLightChangerBase64Url.TryDecode(segments[2], out var signatureBytes))
            {
                errorMessageJapanese = "ライセンスコードの形式が不正です。";
                errorMessageEnglish = "The license code format is invalid.";
                return false;
            }

            var payloadJson = Encoding.UTF8.GetString(payloadBytes);
            payload = JsonUtility.FromJson<PoiLightChangerLicensePayload>(payloadJson);
            if (payload == null)
            {
                errorMessageJapanese = "ライセンスpayloadを解析できませんでした。";
                errorMessageEnglish = "Failed to parse the license payload.";
                return false;
            }

            if (!VerifyPayloadSignature(payload.kid, payloadBytes, signatureBytes))
            {
                errorMessageJapanese = "ライセンスコードの署名が一致しません。";
                errorMessageEnglish = "The license code signature does not match.";
                payload = null;
                payloadBase64Url = string.Empty;
                return false;
            }

            if (!ValidateLicensePayload(payload, out errorMessageJapanese, out errorMessageEnglish))
            {
                payload = null;
                payloadBase64Url = string.Empty;
                return false;
            }

            return true;
        }

        public static bool TryVerifyPolicyEnvelope(
            string envelopeJson,
            out PoiLightChangerPolicyPayload payload,
            out string payloadBase64Url,
            out string errorMessageJapanese,
            out string errorMessageEnglish)
        {
            payload = null;
            payloadBase64Url = string.Empty;
            errorMessageJapanese = "認証の署名検証に失敗しました。";
            errorMessageEnglish = "Failed to verify the policy.json signature.";

            if (string.IsNullOrWhiteSpace(envelopeJson))
            {
                errorMessageJapanese = "ライセンスの認証情報が空です。";
                errorMessageEnglish = "policy.json is empty.";
                return false;
            }

            var envelope = JsonUtility.FromJson<PoiLightChangerPolicyEnvelope>(envelopeJson);
            if (envelope == null || !string.Equals(envelope.format, PoiLightChangerLicenseDefaults.PolicyFormat, StringComparison.Ordinal))
            {
                errorMessageJapanese = "ライセンスの認証情報の形式が不正です。";
                errorMessageEnglish = "The policy.json format is invalid.";
                return false;
            }

            payloadBase64Url = envelope.payload ?? string.Empty;
            if (!PoiLightChangerBase64Url.TryDecode(envelope.payload, out var payloadBytes) ||
                !PoiLightChangerBase64Url.TryDecode(envelope.signature, out var signatureBytes))
            {
                errorMessageJapanese = "ライセンスの認証情報の形式が不正です。";
                errorMessageEnglish = "The policy.json format is invalid.";
                return false;
            }

            var payloadJson = Encoding.UTF8.GetString(payloadBytes);
            payload = JsonUtility.FromJson<PoiLightChangerPolicyPayload>(payloadJson);
            if (payload == null)
            {
                errorMessageJapanese = "ライセンスの認証情報payloadを解析できませんでした。";
                errorMessageEnglish = "Failed to parse the policy payload.";
                return false;
            }

            if (!VerifyPayloadSignature(payload.kid, payloadBytes, signatureBytes))
            {
                errorMessageJapanese = "ライセンスの認証情報の署名が一致しません。";
                errorMessageEnglish = "The policy.json signature does not match.";
                payload = null;
                payloadBase64Url = string.Empty;
                return false;
            }

            if (!ValidatePolicyPayload(payload, out errorMessageJapanese, out errorMessageEnglish))
            {
                payload = null;
                payloadBase64Url = string.Empty;
                return false;
            }

            return true;
        }

        private static bool VerifyPayloadSignature(
            string keyId,
            byte[] payloadBytes,
            byte[] signatureBytes)
        {
            if (payloadBytes == null || payloadBytes.Length == 0 || signatureBytes == null || signatureBytes.Length == 0)
            {
                return false;
            }

            var keys = PoiLightChangerLicenseDefaults.GetTrustedPublicKeys();
            if (string.IsNullOrWhiteSpace(keyId) ||
                keys == null ||
                !keys.TryGetValue(keyId, out var publicKey) ||
                publicKey == null ||
                string.IsNullOrWhiteSpace(publicKey.XBase64) ||
                string.IsNullOrWhiteSpace(publicKey.YBase64))
            {
                return false;
            }

            var publicKeyX = Convert.FromBase64String(publicKey.XBase64);
            var publicKeyY = Convert.FromBase64String(publicKey.YBase64);

            try
            {
                using var ecdsa = ECDsa.Create();
                ecdsa.ImportParameters(new ECParameters
                {
                    Curve = ECCurve.NamedCurves.nistP256,
                    Q = new ECPoint
                    {
                        X = publicKeyX,
                        Y = publicKeyY,
                    },
                });

                if (TryVerifySignatureWithCompatibility(ecdsa, payloadBytes, signatureBytes))
                {
                    return true;
                }

                if (TryConvertP1363ToDer(signatureBytes, 32, out var derSignature) &&
                    TryVerifySignatureWithCompatibility(ecdsa, payloadBytes, derSignature))
                {
                    return true;
                }

                if (TryConvertDerToP1363(signatureBytes, 32, out var p1363Signature) &&
                    TryVerifySignatureWithCompatibility(ecdsa, payloadBytes, p1363Signature))
                {
                    return true;
                }
            }
            catch
            {
                // Fall back to the managed verifier below when the backend implementation fails.
            }

            if (signatureBytes.Length == 64)
            {
                if (PoiLightChangerManagedEcdsaVerifier.VerifySha256(publicKeyX, publicKeyY, payloadBytes, signatureBytes))
                {
                    return true;
                }
            }

            if (TryConvertDerToP1363(signatureBytes, 32, out var managedP1363Signature) &&
                PoiLightChangerManagedEcdsaVerifier.VerifySha256(publicKeyX, publicKeyY, payloadBytes, managedP1363Signature))
            {
                return true;
            }

            return false;
        }

        private static bool TryVerifySignatureWithCompatibility(ECDsa ecdsa, byte[] payloadBytes, byte[] signatureBytes)
        {
            byte[] hashBytes;
            using (var sha256 = SHA256.Create())
            {
                hashBytes = sha256.ComputeHash(payloadBytes);
            }

            try
            {
                if (ecdsa.VerifyHash(hashBytes, signatureBytes))
                {
                    return true;
                }
            }
            catch
            {
                // Fall through to explicit signature format checks.
            }

            try
            {
                if (ecdsa.VerifyData(payloadBytes, signatureBytes, HashAlgorithmName.SHA256))
                {
                    return true;
                }
            }
            catch
            {
                // Ignore backend-specific signature format failures.
            }

            return false;
        }

        private static bool TryConvertDerToP1363(byte[] derSignature, int fieldSize, out byte[] p1363Signature)
        {
            p1363Signature = Array.Empty<byte>();
            if (derSignature == null || derSignature.Length == 0 || fieldSize <= 0)
            {
                return false;
            }

            var offset = 0;
            if (!TryReadAsn1TagAndLength(derSignature, ref offset, 0x30, out var sequenceLength))
            {
                return false;
            }

            if (offset + sequenceLength != derSignature.Length)
            {
                return false;
            }

            if (!TryReadAsn1Integer(derSignature, ref offset, fieldSize, out var r) ||
                !TryReadAsn1Integer(derSignature, ref offset, fieldSize, out var s))
            {
                return false;
            }

            if (offset != derSignature.Length)
            {
                return false;
            }

            p1363Signature = new byte[fieldSize * 2];
            Buffer.BlockCopy(r, 0, p1363Signature, 0, fieldSize);
            Buffer.BlockCopy(s, 0, p1363Signature, fieldSize, fieldSize);
            return true;
        }

        private static bool TryConvertP1363ToDer(byte[] p1363Signature, int fieldSize, out byte[] derSignature)
        {
            derSignature = Array.Empty<byte>();
            if (p1363Signature == null || p1363Signature.Length != fieldSize * 2 || fieldSize <= 0)
            {
                return false;
            }

            var r = EncodeAsn1Integer(p1363Signature, 0, fieldSize);
            var s = EncodeAsn1Integer(p1363Signature, fieldSize, fieldSize);
            var sequenceBodyLength = r.Length + s.Length;
            var sequenceHeader = EncodeAsn1TagAndLength(0x30, sequenceBodyLength);
            derSignature = new byte[sequenceHeader.Length + sequenceBodyLength];
            Buffer.BlockCopy(sequenceHeader, 0, derSignature, 0, sequenceHeader.Length);
            Buffer.BlockCopy(r, 0, derSignature, sequenceHeader.Length, r.Length);
            Buffer.BlockCopy(s, 0, derSignature, sequenceHeader.Length + r.Length, s.Length);
            return true;
        }

        private static bool TryReadAsn1Integer(byte[] buffer, ref int offset, int fieldSize, out byte[] value)
        {
            value = Array.Empty<byte>();
            if (!TryReadAsn1TagAndLength(buffer, ref offset, 0x02, out var integerLength))
            {
                return false;
            }

            if (integerLength <= 0 || offset + integerLength > buffer.Length)
            {
                return false;
            }

            var integerBytes = new byte[integerLength];
            Buffer.BlockCopy(buffer, offset, integerBytes, 0, integerLength);
            offset += integerLength;

            var trimOffset = 0;
            while (trimOffset < integerBytes.Length - 1 && integerBytes[trimOffset] == 0)
            {
                trimOffset++;
            }

            var trimmedLength = integerBytes.Length - trimOffset;
            if (trimmedLength > fieldSize)
            {
                return false;
            }

            value = new byte[fieldSize];
            Buffer.BlockCopy(integerBytes, trimOffset, value, fieldSize - trimmedLength, trimmedLength);
            return true;
        }

        private static byte[] EncodeAsn1Integer(byte[] buffer, int offset, int length)
        {
            var trimOffset = offset;
            while (trimOffset < offset + length - 1 && buffer[trimOffset] == 0)
            {
                trimOffset++;
            }

            var trimmedLength = (offset + length) - trimOffset;
            var requiresLeadingZero = (buffer[trimOffset] & 0x80) != 0;
            var encodedLength = trimmedLength + (requiresLeadingZero ? 1 : 0);
            var header = EncodeAsn1TagAndLength(0x02, encodedLength);
            var encoded = new byte[header.Length + encodedLength];
            Buffer.BlockCopy(header, 0, encoded, 0, header.Length);

            var writeOffset = header.Length;
            if (requiresLeadingZero)
            {
                encoded[writeOffset++] = 0;
            }

            Buffer.BlockCopy(buffer, trimOffset, encoded, writeOffset, trimmedLength);
            return encoded;
        }

        private static bool TryReadAsn1TagAndLength(byte[] buffer, ref int offset, byte expectedTag, out int length)
        {
            length = 0;
            if (buffer == null || offset >= buffer.Length || buffer[offset++] != expectedTag || offset >= buffer.Length)
            {
                return false;
            }

            var firstLengthByte = buffer[offset++];
            if ((firstLengthByte & 0x80) == 0)
            {
                length = firstLengthByte;
                return true;
            }

            var byteCount = firstLengthByte & 0x7F;
            if (byteCount <= 0 || byteCount > 4 || offset + byteCount > buffer.Length)
            {
                return false;
            }

            for (var index = 0; index < byteCount; index++)
            {
                length = (length << 8) | buffer[offset++];
            }

            return true;
        }

        private static byte[] EncodeAsn1TagAndLength(byte tag, int length)
        {
            if (length < 0x80)
            {
                return new[] { tag, (byte)length };
            }

            if (length <= 0xFF)
            {
                return new[] { tag, (byte)0x81, (byte)length };
            }

            return new[]
            {
                tag,
                (byte)0x82,
                (byte)(length >> 8),
                (byte)(length & 0xFF),
            };
        }

        private static bool ValidateLicensePayload(
            PoiLightChangerLicensePayload payload,
            out string errorMessageJapanese,
            out string errorMessageEnglish)
        {
            errorMessageJapanese = string.Empty;
            errorMessageEnglish = string.Empty;

            if (payload.sv != 1)
            {
                errorMessageJapanese = "対応していないライセンスpayloadversionです。";
                errorMessageEnglish = "Unsupported license payload version.";
                return false;
            }

            if (!string.Equals(payload.product, PoiLightChangerLicenseDefaults.Product, StringComparison.Ordinal) ||
                !string.Equals(payload.licenseType, PoiLightChangerLicenseDefaults.FullLicenseType, StringComparison.Ordinal) ||
                payload.major <= 0 ||
                string.IsNullOrWhiteSpace(payload.cohort) ||
                string.IsNullOrWhiteSpace(payload.kid) ||
                string.IsNullOrWhiteSpace(payload.nonce))
            {
                errorMessageJapanese = "ライセンスpayloadの内容が不正です。";
                errorMessageEnglish = "The license payload contents are invalid.";
                return false;
            }

            if (!TryParseUtc(payload.issuedAt, out _))
            {
                errorMessageJapanese = "ライセンスpayloadの日時を解釈できません。";
                errorMessageEnglish = "Failed to parse the license payload timestamp.";
                return false;
            }

            if (!string.IsNullOrWhiteSpace(payload.notBefore) && !TryParseUtc(payload.notBefore, out _))
            {
                errorMessageJapanese = "ライセンスpayloadの有効開始日時を解釈できません。";
                errorMessageEnglish = "Failed to parse the license payload notBefore timestamp.";
                return false;
            }

            if (!string.IsNullOrWhiteSpace(payload.expiresAt) && !TryParseUtc(payload.expiresAt, out _))
            {
                errorMessageJapanese = "ライセンスpayloadの期限日時を解釈できません。";
                errorMessageEnglish = "Failed to parse the license payload expiry timestamp.";
                return false;
            }

            return true;
        }

        private static bool ValidatePolicyPayload(
            PoiLightChangerPolicyPayload payload,
            out string errorMessageJapanese,
            out string errorMessageEnglish)
        {
            errorMessageJapanese = string.Empty;
            errorMessageEnglish = string.Empty;

            if (payload.sv != 1 ||
                !string.Equals(payload.product, PoiLightChangerLicenseDefaults.Product, StringComparison.Ordinal) ||
                payload.policyVersion <= 0 ||
                payload.minimumLicensePayloadSchema <= 0 ||
                string.IsNullOrWhiteSpace(payload.kid))
            {
                errorMessageJapanese = "ライセンスの認証情報payloadの内容が不正です。";
                errorMessageEnglish = "The policy payload contents are invalid.";
                return false;
            }

            if (!TryParseUtc(payload.publishedAt, out _))
            {
                errorMessageJapanese = "ライセンスの認証情報payloadの公開日時を解釈できません。";
                errorMessageEnglish = "Failed to parse the policy payload publishedAt timestamp.";
                return false;
            }

            return true;
        }

        internal static bool TryParseUtc(string value, out DateTimeOffset timestamp)
        {
            return DateTimeOffset.TryParse(
                value,
                CultureInfo.InvariantCulture,
                DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal,
                out timestamp);
        }
    }
}
