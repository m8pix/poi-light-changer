using System;

namespace io.github.m8pix.poi_light_changer
{
    internal sealed class PoiLightChangerLicenseSnapshot
    {
        public PoiLightChangerLicenseValidationState ValidationState { get; set; } = PoiLightChangerLicenseValidationState.Unlicensed;

        public bool IsLicensed { get; set; }

        public bool UsesCachedPolicy { get; set; }

        public PoiLightChangerLicensePayload LicensePayload { get; set; }

        public PoiLightChangerPolicyPayload PolicyPayload { get; set; }

        public DateTimeOffset? LastValidatedAtUtc { get; set; }

        public DateTimeOffset? OfflineGraceUntilUtc { get; set; }

        public string StatusMessageJapanese { get; set; } = string.Empty;

        public string StatusMessageEnglish { get; set; } = string.Empty;
    }
}
