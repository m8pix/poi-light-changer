using System;
using System.Collections.Generic;
using System.Linq;
using nadena.dev.ndmf;
using nadena.dev.ndmf.animator;
using UnityEngine;
using VRC.SDK3.Avatars.Components;

[assembly: ExportsPlugin(typeof(io.github.m8pix.poi_light_changer.PoiLightChangerPlugin))]

namespace io.github.m8pix.poi_light_changer
{
    internal static class PoiLightChangerBuildFeatureOverrides
    {
        // Build only: keep the inspector's saved values, but force restricted features off when unlicensed.
        public static bool ShouldUseParameterCompression(
            PoiLightChangerComponent component,
            PoiLightChangerLicenseSnapshot licenseSnapshot)
        {
            return component?.Sync is { UseParameterCompression: true } &&
                   PoiLightChangerLicenseFeatureGate.IsFeatureAvailable(
                       PoiLightChangerLicensedFeatureId.Parameters,
                       licenseSnapshot);
        }

        public static bool ShouldUseTextureBake(
            PoiLightChangerComponent component,
            PoiLightChangerLicenseSnapshot licenseSnapshot)
        {
            return component?.Bake is { EnableColorBake: true } &&
                   PoiLightChangerLicenseFeatureGate.IsFeatureAvailable(
                       PoiLightChangerLicensedFeatureId.TextureBake,
                       licenseSnapshot);
        }
    }

    public sealed class PoiLightChangerPlugin : Plugin<PoiLightChangerPlugin>
    {
        internal const string Title = "Poi Light Changer";
        private const string ModularAvatarQualifiedName = "nadena.dev.modular-avatar";

        public override string QualifiedName => "io.github.m8pix.poi-light-changer";

        public override string DisplayName => Title;

        public override Color? ThemeColor => new Color(0.91f, 0.55f, 0.15f);

        protected override void Configure()
        {
            InPhase(BuildPhase.Transforming)
                .BeforePlugin(ModularAvatarQualifiedName)
                .Run($"{DisplayName} Validate", context =>
                {
                    context.GetState(PoiLightChangerBuildState.Create).Validate();
                });

            InPhase(BuildPhase.Transforming)
                .BeforePlugin(ModularAvatarQualifiedName)
                .WithRequiredExtensions(new[] { typeof(AnimatorServicesContext) }, sequence =>
                {
                    sequence.Run($"{DisplayName} Process Materials And Controls", context =>
                    {
                        context.GetState(PoiLightChangerBuildState.Create).ProcessBeforeModularAvatar();
                    });
                });

            InPhase(BuildPhase.Transforming)
                .AfterPlugin(ModularAvatarQualifiedName)
                .Run($"{DisplayName} Parameter Compression", context =>
                {
                    context.GetState(PoiLightChangerBuildState.Create).ApplyParameterCompression();
                });

            InPhase(BuildPhase.Transforming)
                .AfterPlugin(ModularAvatarQualifiedName)
                .Run($"{DisplayName} Cleanup", context =>
                {
                    context.GetState(PoiLightChangerBuildState.Create).Cleanup();
                });
        }
    }

    internal sealed class PoiLightChangerBuildState
    {
        private readonly BuildContext context;
        private readonly IReadOnlyList<PoiLightChangerComponent> components;
        private readonly PoiLightChangerComponent primaryComponent;
        private readonly PoiLightChangerBuildProcessor processor;
        private readonly IReadOnlyList<PoiLightChangerDiagnosticEntry> componentDiagnostics;
        private readonly PoiLightChangerLicenseSnapshot licenseSnapshot;
        private readonly bool useParameterCompression;
        private bool hasBlockingDiagnostic;

        private PoiLightChangerBuildState(BuildContext context)
        {
            this.context = context;
            components = context.AvatarRootObject.GetComponentsInChildren<PoiLightChangerComponent>(true);
            primaryComponent = components.FirstOrDefault(component => component != null);
            licenseSnapshot = PoiLightChangerLicenseService.RefreshPolicyIfNeeded(force: false);
            if (primaryComponent != null)
            {
                primaryComponent.EnsureInitialized();
                processor = new PoiLightChangerBuildProcessor(context, primaryComponent, licenseSnapshot);
                componentDiagnostics = PoiLightChangerDiagnostics.CollectComponentDiagnostics(primaryComponent, context.AvatarRootObject, licenseSnapshot);
                useParameterCompression = PoiLightChangerBuildFeatureOverrides.ShouldUseParameterCompression(primaryComponent, licenseSnapshot);
            }
            else
            {
                componentDiagnostics = Array.Empty<PoiLightChangerDiagnosticEntry>();
            }
        }

        public static PoiLightChangerBuildState Create(BuildContext context) => new(context);

        public void Validate()
        {
            if (components.Count == 0)
            {
                return;
            }

            PoiLightChangerDiagnostics.ReportNdmfDiagnostics(componentDiagnostics);
            hasBlockingDiagnostic = PoiLightChangerDiagnostics.HasBlockingBuildDiagnostic(componentDiagnostics);

            foreach (var component in components.Where(component => component != null))
            {
                component.EnsureInitialized();

                if (PoiLightChangerBuildFeatureOverrides.ShouldUseParameterCompression(component, licenseSnapshot))
                {
                    var directLayout = PoiLightChangerParameterProvider.GetDirectParameterLayout(component, licenseSnapshot);
                    var compressionPlan = PoiLightChangerParameterCompression.BuildPlanFromSlots(
                        directLayout,
                        component.Sync.CompressionChannelCount);
                    if (!compressionPlan.IsEffective)
                    {
                        var diagnostic = PoiLightChangerDiagnostics.CreateProcessorDiagnostic(
                            PoiLightChangerDiagnosticId.ParameterCompressionIneffective,
                            "現在の構成では圧縮してもパラメーター数が減らないため、このbuildでは通常レイアウトを使います。",
                            "Compression will not run because the number of parameters enabled in PLC is less than the number of parameters used for compression.",
                            "[Poi Light Changer] Compression will not run because the number of parameters enabled in PLC is less than the number of parameters used for compression.",
                            ErrorSeverity.Information,
                            false,
                            component);
                        PoiLightChangerDiagnostics.ReportNdmfDiagnostic(diagnostic);
                    }
                }

                var unimplementedEnabledControls = PoiLightChangerControlRegistry.V1Controls
                    .Where(definition => !definition.ImplementedInCurrentBuild)
                    .Where(definition => definition.GetControl(component) is { Enable: true, Animation: true })
                    .Select(definition => definition.MenuPath)
                    .ToArray();

                if (unimplementedEnabledControls.Length > 0)
                {
                    var diagnostic = PoiLightChangerDiagnostics.CreateProcessorDiagnostic(
                        PoiLightChangerDiagnosticId.UnimplementedEnabledControls,
                        string.Empty,
                        string.Empty,
                        $"[Poi Light Changer] These controls are declared but not wired end-to-end yet: {string.Join(", ", unimplementedEnabledControls)}",
                        ErrorSeverity.NonFatal,
                        false,
                        component);
                    PoiLightChangerDiagnostics.ReportNdmfDiagnostic(diagnostic);
                }
            }
        }

        public void ProcessBeforeModularAvatar()
        {
            if (processor == null || hasBlockingDiagnostic)
            {
                return;
            }

            processor.CloneTargetMaterials();
            processor.ReportCollectedMaterialDiagnostics();
            try
            {
                processor.BeginMaterialEditSession();
                processor.BakeColorAdjustments();
                processor.ApplyAnimatedStaticMaterialValues();
                processor.ApplyCommonMaterialOverrides();
                processor.ApplyNonAnimatedStaticMaterialValues();
                processor.GenerateImplementedControls();
            }
            catch (Exception exception)
            {
                var diagnostic = PoiLightChangerDiagnostics.CreateProcessorDiagnostic(
                    PoiLightChangerDiagnosticId.BuildException,
                    string.Empty,
                    string.Empty,
                    $"[Poi Light Changer] PLC build failed. See Console for the stack trace. {exception.GetType().Name}: {exception.Message}",
                    ErrorSeverity.NonFatal,
                    true,
                    context.AvatarRootObject);
                PoiLightChangerDiagnostics.ReportNdmfDiagnostic(diagnostic);
                throw;
            }
            finally
            {
                processor.EndMaterialEditSession();
            }
        }

        public void Cleanup()
        {
            foreach (var component in components)
            {
                if (component != null && component.gameObject != null)
                {
                    UnityEngine.Object.DestroyImmediate(component.gameObject);
                }
            }
        }

        public void ApplyParameterCompression()
        {
            if (!useParameterCompression || hasBlockingDiagnostic)
            {
                return;
            }

            if (!context.AvatarRootObject.TryGetComponent<VRCAvatarDescriptor>(out var descriptor))
            {
                return;
            }

            var expressionParameters = descriptor.expressionParameters;
            if (expressionParameters == null)
            {
                return;
            }

            var directLayout = PoiLightChangerParameterProvider.GetDirectParameterLayout(primaryComponent, licenseSnapshot);
            var compressionPlan = PoiLightChangerParameterCompression.BuildPlanFromSlots(
                directLayout,
                primaryComponent.Sync.CompressionChannelCount);
            if (!compressionPlan.IsEffective)
            {
                return;
            }

            PoiLightChangerParameterCompression.ApplyToExpressionParameters(expressionParameters, compressionPlan);
        }
    }
}
