using System;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace io.github.m8pix.poi_light_changer
{
    internal static class PoiLightChangerInspectorClipboard
    {
        private const string ClipboardSessionKey = "PoiLightChanger.InspectorClipboard";
        private const int CurrentVersion = 1;

        [Serializable]
        private sealed class ClipboardEnvelope
        {
            public int Version = CurrentVersion;
            public string[] PropertyPaths;
            public string ComponentJson;
        }

        public static bool TryCopy(SerializedObject source, IReadOnlyList<string> propertyPaths)
        {
            if (source == null || !TryCreateEnvelope(source, propertyPaths, out var envelope))
            {
                return false;
            }

            SessionState.SetString(ClipboardSessionKey, JsonUtility.ToJson(envelope));
            return true;
        }

        public static bool CanPaste(IReadOnlyList<string> propertyPaths)
        {
            return TryLoadCompatibleEnvelope(propertyPaths, out _);
        }

        public static bool TryPaste(SerializedObject destination, IReadOnlyList<string> propertyPaths, string undoLabel)
        {
            if (destination == null || !TryLoadCompatibleEnvelope(propertyPaths, out var envelope))
            {
                return false;
            }

            var temporaryObject = new GameObject
            {
                hideFlags = HideFlags.HideInHierarchy | HideFlags.DontSave,
            };

            try
            {
                var temporaryComponent = temporaryObject.AddComponent<PoiLightChangerComponent>();
                temporaryComponent.EnsureInitialized();
                JsonUtility.FromJsonOverwrite(envelope.ComponentJson, temporaryComponent);
                temporaryComponent.EnsureInitialized();

                using var temporarySerializedObject = new SerializedObject(temporaryComponent);
                Undo.RecordObject(destination.targetObject, undoLabel);

                foreach (var propertyPath in envelope.PropertyPaths)
                {
                    var sourceProperty = temporarySerializedObject.FindProperty(propertyPath);
                    if (sourceProperty == null)
                    {
                        return false;
                    }

                    destination.CopyFromSerializedPropertyIfDifferent(sourceProperty);
                }

                destination.ApplyModifiedProperties();
                EditorUtility.SetDirty(destination.targetObject);
                return true;
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(temporaryObject);
            }
        }

        private static bool TryCreateEnvelope(
            SerializedObject source,
            IReadOnlyList<string> propertyPaths,
            out ClipboardEnvelope envelope)
        {
            envelope = null;
            var normalizedPaths = NormalizePropertyPaths(propertyPaths);
            if (normalizedPaths.Length == 0)
            {
                return false;
            }

            var temporaryObject = new GameObject
            {
                hideFlags = HideFlags.HideInHierarchy | HideFlags.DontSave,
            };

            try
            {
                var temporaryComponent = temporaryObject.AddComponent<PoiLightChangerComponent>();
                temporaryComponent.EnsureInitialized();

                using var temporarySerializedObject = new SerializedObject(temporaryComponent);
                foreach (var propertyPath in normalizedPaths)
                {
                    var sourceProperty = source.FindProperty(propertyPath);
                    if (sourceProperty == null)
                    {
                        return false;
                    }

                    temporarySerializedObject.CopyFromSerializedPropertyIfDifferent(sourceProperty);
                }

                temporarySerializedObject.ApplyModifiedProperties();
                envelope = new ClipboardEnvelope
                {
                    PropertyPaths = normalizedPaths,
                    ComponentJson = JsonUtility.ToJson(temporaryComponent),
                };
                return true;
            }
            finally
            {
                UnityEngine.Object.DestroyImmediate(temporaryObject);
            }
        }

        private static bool TryLoadCompatibleEnvelope(
            IReadOnlyList<string> propertyPaths,
            out ClipboardEnvelope envelope)
        {
            envelope = null;
            var raw = SessionState.GetString(ClipboardSessionKey, string.Empty);
            if (string.IsNullOrWhiteSpace(raw))
            {
                return false;
            }

            var parsed = JsonUtility.FromJson<ClipboardEnvelope>(raw);
            if (parsed == null ||
                parsed.Version != CurrentVersion ||
                string.IsNullOrWhiteSpace(parsed.ComponentJson))
            {
                return false;
            }

            var expectedPaths = NormalizePropertyPaths(propertyPaths);
            var actualPaths = NormalizePropertyPaths(parsed.PropertyPaths);
            if (expectedPaths.Length == 0 || !expectedPaths.SequenceEqual(actualPaths, StringComparer.Ordinal))
            {
                return false;
            }

            envelope = parsed;
            return true;
        }

        private static string[] NormalizePropertyPaths(IReadOnlyList<string> propertyPaths)
        {
            if (propertyPaths == null)
            {
                return Array.Empty<string>();
            }

            return propertyPaths
                .Where(path => !string.IsNullOrWhiteSpace(path))
                .Distinct(StringComparer.Ordinal)
                .ToArray();
        }
    }
}
